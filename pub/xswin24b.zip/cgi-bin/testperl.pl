#! perl
print <<".";
<P>Hello World!
.
