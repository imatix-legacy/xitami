/*---------------------------------------------------------------------------
 *  xiadm08.h - HTML form definition
 *
 *  Generated 1998/11/15, 18:12:18 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM08__
#define __FORM_XIADM08__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM08_MESSAGE_TO_USER             0
#define XIADM08_MAIN_CONFIG                 1
#define XIADM08_L_LOGFILE                   2
#define XIADM08_L_ENABLED                   3
#define XIADM08_L_CYCLE                     4
#define XIADM08_L_LOCAL                     5
#define XIADM08_LOGTYPE_1                   6
#define XIADM08_LOGFILE_1                   7
#define XIADM08_ENABLED_1                   8
#define XIADM08_CYCLE_1                     9
#define XIADM08_LOCAL_1                     10
#define XIADM08_LOGTYPE_2                   11
#define XIADM08_LOGFILE_2                   12
#define XIADM08_ENABLED_2                   13
#define XIADM08_CYCLE_2                     14
#define XIADM08_LOCAL_2                     15
#define XIADM08_LOGTYPE_3                   16
#define XIADM08_LOGFILE_3                   17
#define XIADM08_ENABLED_3                   18
#define XIADM08_CYCLE_3                     19
#define XIADM08_LOCAL_3                     20
#define XIADM08_L_LOG_DIR                   21
#define XIADM08_LOG_DIR                     22

/*  This table contains each block in the form                               */

static byte xiadm08_blocks [] = {
    /*  <HTML>                                                               */
    0, 8, 0, '<', 'H', 'T', 'M', 'L', '>', 10,
    /*  <HEAD><TITLE>Xitami Web-Base ... tration Pages</TITLE></HEAD>        */
    0, 67, 0, '<', 'H', 'E', 'A', 'D', '>', '<', 'T', 'I', 'T', 'L',
    'E', '>', 'X', 'i', 't', 'a', 'm', 'i', 32, 'W', 'e', 'b', 45, 'B',
    'a', 's', 'e', 'd', 32, 'A', 'd', 'm', 'i', 'n', 'i', 's', 't', 'r',
    'a', 't', 'i', 'o', 'n', 32, 'P', 'a', 'g', 'e', 's', '<', '/', 'T',
    'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A', 'D', '>', 10,
    /*  <BODY BGCOLOR="#87CEFA" onLoad="focus()">                            */
    0, 43, 0, '<', 'B', 'O', 'D', 'Y', 32, 'B', 'G', 'C', 'O', 'L', 'O',
    'R', '=', '"', '#', '8', '7', 'C', 'E', 'F', 'A', '"', 32, 'o', 'n',
    'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u', 's', '(', ')',
    '"', '>', 10,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 48, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 21, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>', 10,
    /*  <IMG SRC="/admin/left.gif" BORDER=0>                                 */
    0, 37, 0, '<', 'I', 'M', 'G', 32, 'S', 'R', 'C', '=', '"', '/', 'a',
    'd', 'm', 'i', 'n', '/', 'l', 'e', 'f', 't', '.', 'g', 'i', 'f',
    '"', 32, 'B', 'O', 'R', 'D', 'E', 'R', '=', '0', '>',
    /*  !--ACTION back  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) back_event / 256), (byte) ((word)
    back_event & 255), 0, 0, 0, 0, 23, 0, 24, 'b', 'a', 'c', 'k', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'b', 'a', 'c', 'k', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION save  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) save_event / 256), (byte) ((word)
    save_event & 255), 0, 1, 0, 0, 23, 0, 24, 's', 'a', 'v', 'e', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 's', 'a', 'v', 'e', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION defaults  LABEL="/ ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 40, 20, 2, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 2, 0, 0, 23, 0, 24, 'd', 'e', 'f', 'a',
    'u', 'l', 't', 's', 0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'd', 'e',
    'f', 'a', 'u', 'l', 't', 's', '.', 'g', 'i', 'f', 0,
    /*  !--ACTION undo  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 23, 0, 24, 'u', 'n', 'd', 'o', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'u', 'n', 'd', 'o', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION help  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) help_event / 256), (byte) ((word)
    help_event & 255), 0, 4, 0, 0, 23, 0, 24, 'h', 'e', 'l', 'p', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'h', 'e', 'l', 'p', '.', 'g',
    'i', 'f', 0,
    /*  <IMG SRC="/admin/right.gif" BORDER=0>                                */
    0, 39, 0, '<', 'I', 'M', 'G', 32, 'S', 'R', 'C', '=', '"', '/', 'a',
    'd', 'm', 'i', 'n', '/', 'r', 'i', 'g', 'h', 't', '.', 'g', 'i',
    'f', '"', 32, 'B', 'O', 'R', 'D', 'E', 'R', '=', '0', '>', 10,
    /*  <TD ALIGN=CENTER><FONT SIZE=+1>#(config) - Log Files </FONT>         */
    0, 62, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '+', '1', '>', '#', '(', 'c', 'o', 'n', 'f', 'i', 'g',
    ')', 32, 45, 32, 'L', 'o', 'g', 32, 'F', 'i', 'l', 'e', 's', 32,
    '<', '/', 'F', 'O', 'N', 'T', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  <IMG SRC="/admin/left.gif" BORDER=0>                                 */
    0, 4, 1, 0, 1, 25,
    /*  !--ACTION console  LABEL="/a ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 38, 20, 2, (byte) ((word) console_event / 256), (byte) ((word)
    console_event & 255), 0, 5, 0, 0, 23, 0, 24, 'c', 'o', 'n', 's',
    'o', 'l', 'e', 0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'c', 'o', 'n',
    's', 'o', 'l', 'e', '.', 'g', 'i', 'f', 0,
    /*  !--ACTION restart  LABEL="/a ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 38, 20, 2, (byte) ((word) restart_event / 256), (byte) ((word)
    restart_event & 255), 0, 6, 0, 0, 23, 0, 24, 'r', 'e', 's', 't',
    'a', 'r', 't', 0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'r', 'e', 's',
    't', 'a', 'r', 't', '.', 'g', 'i', 'f', 0,
    /*  !--ACTION halt  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) halt_event / 256), (byte) ((word)
    halt_event & 255), 0, 7, 0, 0, 23, 0, 24, 'h', 'a', 'l', 't', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'h', 'a', 'l', 't', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION exit  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) exit_event / 256), (byte) ((word)
    exit_event & 255), 0, 8, 0, 0, 23, 0, 24, 'e', 'x', 'i', 't', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'e', 'x', 'i', 't', '.', 'g',
    'i', 'f', 0,
    /*  <IMG SRC="/admin/right.gif" BORDER=0>                                */
    0, 4, 1, 0, 1, 242,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD ALIGN=LEFT>                                */
    0, 39, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D', 32,
    'A', 'L', 'I', 'G', 'N', '=', 'L', 'E', 'F', 'T', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <FONT COLOR="#E00000" SIZE=+1><EM>                                   */
    0, 36, 0, '<', 'F', 'O', 'N', 'T', 32, 'C', 'O', 'L', 'O', 'R', '=',
    '"', '#', 'E', '0', '0', '0', '0', '0', '"', 32, 'S', 'I', 'Z', 'E',
    '=', '+', '1', '>', '<', 'E', 'M', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  </EM></FONT>                                                         */
    0, 14, 0, '<', '/', 'E', 'M', '>', '<', '/', 'F', 'O', 'N', 'T',
    '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 2, '[',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 15,
    /*  !--FIELD NUMERIC main_config SIZE=4 VALUE=1                          */
    0, 27, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'm', 'a', 'i', 'n',
    '_', 'c', 'o', 'n', 'f', 'i', 'g', 0, '1', 0,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 52, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD ALIGN=LEFT><FONT SIZE=-1>                                        */
    0, 31, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    45, '1', '>', 10,
    /*  <TD ALIGN=RIGHT><FONT SIZE=-1>                                       */
    0, 32, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E',
    '=', 45, '1', '>', 10,
    /*  !--ACTION server  LABEL="Ser ... ENT=server_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 9, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  !--ACTION aliases  LABEL="Al ... NT=aliases_event TYPE=PLAIN         */
    0, 27, 20, 1, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 10, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  !--ACTION vhosts  LABEL="Vho ... ENT=vhosts_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 11, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 12, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... T=security_event TYPE=PLAIN         */
    0, 29, 20, 1, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 13, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u',
    'r', 'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  <EM>Logging</EM>                                                     */
    0, 18, 0, '<', 'E', 'M', '>', 'L', 'o', 'g', 'g', 'i', 'n', 'g',
    '<', '/', 'E', 'M', '>', 10,
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 14, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=PLAIN            */
    0, 21, 20, 1, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 15, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0,
    'M', 'I', 'M', 'E', 0,
    /*  </FONT></TABLE><HR>                                                  */
    0, 21, 0, '<', '/', 'F', 'O', 'N', 'T', '>', '<', '/', 'T', 'A',
    'B', 'L', 'E', '>', '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH= >                                                      */
    0, 17, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', 32, '>', 10,
    /*  <TR>                                                                 */
    0, 6, 0, '<', 'T', 'R', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 35, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f127 NAME=L_logfile VALUE="Filename:"               */
    0, 23, 10, 6, 1, 0, 0, 9, 0, 9, 'f', '1', '2', '7', 0, 'F', 'i',
    'l', 'e', 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 7, 0, '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 92,
    /*  !--FIELD TEXTUAL f128 NAME=L_enabled VALUE="On:"                     */
    0, 17, 10, 6, 1, 0, 0, 3, 0, 3, 'f', '1', '2', '8', 0, 'O', 'n',
    ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 5, 149,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 92,
    /*  !--FIELD TEXTUAL f129 NAME=L_cycle VALUE="Cycle:"                    */
    0, 20, 10, 6, 1, 0, 0, 6, 0, 6, 'f', '1', '2', '9', 0, 'C', 'y',
    'c', 'l', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 5, 149,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 92,
    /*  !--FIELD TEXTUAL f130 NAME=L ... ="Include local addresses:"         */
    0, 38, 10, 6, 1, 0, 0, 24, 0, 24, 'f', '1', '3', '0', 0, 'I', 'n',
    'c', 'l', 'u', 'd', 'e', 32, 'l', 'o', 'c', 'a', 'l', 32, 'a', 'd',
    'd', 'r', 'e', 's', 's', 'e', 's', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 5, 149,
    /*  </TR>                                                                */
    0, 7, 0, '<', '/', 'T', 'R', '>', 10,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 5, '/',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 28, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    10,
    /*  !--FIELD TEXTUAL f131 NAME=l ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 7, 1, 0, 0, 15, 0, 15, 'f', '1', '3', '1', 0, 0,
    /*  </TD>                                                                */
    0, 7, 0, '<', '/', 'T', 'D', '>', 10,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f132 NAME=l ... =40 MAX=80 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, 'P', 'f', '1', '3', '2', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD BOOLEAN f133 NAME=e ... 1 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 1, 'f', '1', '3', '3', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD SELECT f134 NAME=cy ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 16, 0, 1, 1, 5, 'f', '1', '3', '4', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD BOOLEAN f135 NAME=local_1 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 1, 'f', '1', '3', '5', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  </TR>                                                                */
    0, 4, 1, 0, 6, 19,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 5, '/',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 6, '"',
    /*  !--FIELD TEXTUAL f136 NAME=l ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 7, 1, 0, 0, 15, 0, 15, 'f', '1', '3', '6', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD TEXTUAL f137 NAME=l ... =40 MAX=80 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, 'P', 'f', '1', '3', '7', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD BOOLEAN f138 NAME=e ... 2 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 1, 'f', '1', '3', '8', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD SELECT f139 NAME=cy ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 16, 0, 1, 1, 5, 'f', '1', '3', '9', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD BOOLEAN f140 NAME=local_2 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 1, 'f', '1', '4', '0', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  </TR>                                                                */
    0, 4, 1, 0, 6, 19,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 5, '/',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 6, '"',
    /*  !--FIELD TEXTUAL f141 NAME=l ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 7, 1, 0, 0, 15, 0, 15, 'f', '1', '4', '1', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD TEXTUAL f142 NAME=l ... =40 MAX=80 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, 'P', 'f', '1', '4', '2', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD BOOLEAN f143 NAME=e ... 3 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 1, 'f', '1', '4', '3', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD SELECT f144 NAME=cy ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 16, 0, 1, 1, 5, 'f', '1', '4', '4', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 6, 'Y',
    /*  !--FIELD BOOLEAN f145 NAME=local_3 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 1, 'f', '1', '4', '5', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 6, 'P',
    /*  </TR>                                                                */
    0, 4, 1, 0, 6, 19,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 15,
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f146 NAME=L ... ile directory:&nbsp;&nbsp;"         */
    0, 45, 10, 6, 1, 0, 0, 31, 0, 31, 'f', '1', '4', '6', 0, 'L', 'o',
    'g', 32, 'f', 'i', 'l', 'e', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o',
    'r', 'y', ':', '&', 'n', 'b', 's', 'p', ';', '&', 'n', 'b', 's',
    'p', ';', 0,
    /*  </TD><TD ALIGN=LEFT WIDTH="80%">                                     */
    0, 34, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'W', 'I', 'D', 'T', 'H', '=',
    '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD TEXTUAL f147 NAME=l ... E=50 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '2', 0, '2', 'f', '1', '4', '7', 0, 0,
    /*  May be blank                                                         */
    0, 14, 0, 'M', 'a', 'y', 32, 'b', 'e', 32, 'b', 'l', 'a', 'n', 'k',
    10,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 15,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR>                                               */
    0, 24, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD><IMG SRC="/admin/im0096c.gif"                                    */
    0, 35, 0, '<', 'T', 'D', '>', '<', 'I', 'M', 'G', 32, 'S', 'R', 'C',
    '=', '"', '/', 'a', 'd', 'm', 'i', 'n', '/', 'i', 'm', '0', '0',
    '9', '6', 'c', '.', 'g', 'i', 'f', '"', 10,
    /*  WIDTH=96 HEIGHT=36>                                                  */
    0, 21, 0, 'W', 'I', 'D', 'T', 'H', '=', '9', '6', 32, 'H', 'E', 'I',
    'G', 'H', 'T', '=', '3', '6', '>', 10,
    /*  <TD ALIGN=CENTER><FONT SIZE= ... 9 1996-98 iMatix Corporation        */
    0, 75, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', 45, '1', '>', 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't',
    32, '&', '#', '1', '6', '9', 32, '1', '9', '9', '6', 45, '9', '8',
    32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'C', 'o', 'r', 'p', 'o', 'r',
    'a', 't', 'i', 'o', 'n', 10,
    /*  <BR>Powered by iMatix Studio 1.0                                     */
    0, 34, 0, '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32,
    'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd',
    'i', 'o', 32, '1', '.', '0', 10,
    /*  <TD ALIGN=RIGHT><FONT SIZE=-1>#(date) #(time)                        */
    0, 47, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E',
    '=', 45, '1', '>', '#', '(', 'd', 'a', 't', 'e', ')', 32, '#', '(',
    't', 'i', 'm', 'e', ')', 10,
    /*  <BR>Xitami Webserver v2.4b                                           */
    0, 28, 0, '<', 'B', 'R', '>', 'X', 'i', 't', 'a', 'm', 'i', 32, 'W',
    'e', 'b', 's', 'e', 'r', 'v', 'e', 'r', 32, 'v', '2', '.', '4', 'b',
    10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 15,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm08_fields [] = {
    { 0, 881, 80 },                     /*  message_to_user                 */
    { 82, 936, 4 },                     /*  main_config                     */
    { 88, 1404, 9 },                    /*  l_logfile                       */
    { 99, 1444, 3 },                    /*  l_enabled                       */
    { 104, 1475, 6 },                   /*  l_cycle                         */
    { 112, 1509, 24 },                  /*  l_local                         */
    { 138, 1600, 15 },                  /*  logtype_1                       */
    { 155, 1657, 80 },                  /*  logfile_1                       */
    { 237, 1685, 1 },                   /*  enabled_1                       */
    { 240, 1716, 3 },                   /*  cycle_1                         */
    { 245, 1787, 1 },                   /*  local_1                         */
    { 248, 1830, 15 },                  /*  logtype_2                       */
    { 265, 1858, 80 },                  /*  logfile_2                       */
    { 347, 1886, 1 },                   /*  enabled_2                       */
    { 350, 1917, 3 },                   /*  cycle_2                         */
    { 355, 1988, 1 },                   /*  local_2                         */
    { 358, 2031, 15 },                  /*  logtype_3                       */
    { 375, 2059, 80 },                  /*  logfile_3                       */
    { 457, 2087, 1 },                   /*  enabled_3                       */
    { 460, 2118, 3 },                   /*  cycle_3                         */
    { 465, 2189, 1 },                   /*  local_3                         */
    { 468, 2296, 31 },                  /*  l_log_dir                       */
    { 501, 2379, 50 },                  /*  log_dir                         */
    { 553, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   main_config_a        ;
    char   main_config          [4 + 1];
    byte   l_logfile_a          ;
    char   l_logfile            [9 + 1];
    byte   l_enabled_a          ;
    char   l_enabled            [3 + 1];
    byte   l_cycle_a            ;
    char   l_cycle              [6 + 1];
    byte   l_local_a            ;
    char   l_local              [24 + 1];
    byte   logtype_1_a          ;
    char   logtype_1            [15 + 1];
    byte   logfile_1_a          ;
    char   logfile_1            [80 + 1];
    byte   enabled_1_a          ;
    char   enabled_1            [1 + 1];
    byte   cycle_1_a            ;
    char   cycle_1              [3 + 1];
    byte   local_1_a            ;
    char   local_1              [1 + 1];
    byte   logtype_2_a          ;
    char   logtype_2            [15 + 1];
    byte   logfile_2_a          ;
    char   logfile_2            [80 + 1];
    byte   enabled_2_a          ;
    char   enabled_2            [1 + 1];
    byte   cycle_2_a            ;
    char   cycle_2              [3 + 1];
    byte   local_2_a            ;
    char   local_2              [1 + 1];
    byte   logtype_3_a          ;
    char   logtype_3            [15 + 1];
    byte   logfile_3_a          ;
    char   logfile_3            [80 + 1];
    byte   enabled_3_a          ;
    char   enabled_3            [1 + 1];
    byte   cycle_3_a            ;
    char   cycle_3              [3 + 1];
    byte   local_3_a            ;
    char   local_3              [1 + 1];
    byte   l_log_dir_a          ;
    char   l_log_dir            [31 + 1];
    byte   log_dir_a            ;
    char   log_dir              [50 + 1];
    byte   back_a;
    byte   save_a;
    byte   defaults_a;
    byte   undo_a;
    byte   help_a;
    byte   console_a;
    byte   restart_a;
    byte   halt_a;
    byte   exit_a;
    byte   server_a;
    byte   aliases_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   ftp_a;
    byte   mime_a;
    } XIADM08_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm08 = {
    xiadm08_blocks,
    xiadm08_fields,
    134,                                /*  Number of blocks in form        */
    23,                                 /*  Number of fields in form        */
    16,                                 /*  Number of actions in form       */
    553,                                /*  Size of fields                  */
    "xiadm08",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
