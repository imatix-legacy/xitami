/*---------------------------------------------------------------------------
 *  xiadm17.h - HTML form definition
 *
 *  Generated 1998/11/15, 18:12:18 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM17__
#define __FORM_XIADM17__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define FTP_USER_LIST_MAX                   10
#define XIADM17_MESSAGE_TO_USER             0
#define XIADM17_L_USER_NAME                 1
#define XIADM17_L_PASSWORD                  2
#define XIADM17_L_ROOTDIR                   3
#define XIADM17_L_ALIASES                   4
#define XIADM17_L_ACCESS_GET                5
#define XIADM17_L_ACCESS_PUT                6
#define XIADM17_L_ACCESS_DEL                7
#define XIADM17_L_ACCESS_MKDIR              8
#define XIADM17_L_ACCESS_RMDIR              9
#define XIADM17_KEY                         10
#define XIADM17_USER_NAME                   11
#define XIADM17_PASSWORD                    12
#define XIADM17_ROOTDIR                     13
#define XIADM17_ALIASES                     14
#define XIADM17_ACCESS_GET                  15
#define XIADM17_ACCESS_PUT                  16
#define XIADM17_ACCESS_DEL                  17
#define XIADM17_ACCESS_MKDIR                18
#define XIADM17_ACCESS_RMDIR                19
#define XIADM17_FTP_USER_LIST               20

/*  This table contains each block in the form                               */

static byte xiadm17_blocks [] = {
    /*  <HTML>                                                               */
    0, 8, 0, '<', 'H', 'T', 'M', 'L', '>', 10,
    /*  <HEAD><TITLE>Xitami Web-Base ... tration Pages</TITLE></HEAD>        */
    0, 67, 0, '<', 'H', 'E', 'A', 'D', '>', '<', 'T', 'I', 'T', 'L',
    'E', '>', 'X', 'i', 't', 'a', 'm', 'i', 32, 'W', 'e', 'b', 45, 'B',
    'a', 's', 'e', 'd', 32, 'A', 'd', 'm', 'i', 'n', 'i', 's', 't', 'r',
    'a', 't', 'i', 'o', 'n', 32, 'P', 'a', 'g', 'e', 's', '<', '/', 'T',
    'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A', 'D', '>', 10,
    /*  <BODY BGCOLOR="#87CEFA" onLoad="focus()">                            */
    0, 43, 0, '<', 'B', 'O', 'D', 'Y', 32, 'B', 'G', 'C', 'O', 'L', 'O',
    'R', '=', '"', '#', '8', '7', 'C', 'E', 'F', 'A', '"', 32, 'o', 'n',
    'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u', 's', '(', ')',
    '"', '>', 10,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 48, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 21, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>', 10,
    /*  <IMG SRC="/admin/left.gif" BORDER=0>                                 */
    0, 37, 0, '<', 'I', 'M', 'G', 32, 'S', 'R', 'C', '=', '"', '/', 'a',
    'd', 'm', 'i', 'n', '/', 'l', 'e', 'f', 't', '.', 'g', 'i', 'f',
    '"', 32, 'B', 'O', 'R', 'D', 'E', 'R', '=', '0', '>',
    /*  !--ACTION back  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) back_event / 256), (byte) ((word)
    back_event & 255), 0, 0, 0, 0, 23, 0, 24, 'b', 'a', 'c', 'k', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'b', 'a', 'c', 'k', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION save  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) save_event / 256), (byte) ((word)
    save_event & 255), 0, 1, 0, 0, 23, 0, 24, 's', 'a', 'v', 'e', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 's', 'a', 'v', 'e', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION clear  LABEL="/adm ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 34, 20, 2, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 2, 0, 0, 23, 0, 24, 'c', 'l', 'e', 'a', 'r',
    0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'c', 'l', 'e', 'a', 'r', '.',
    'g', 'i', 'f', 0,
    /*  !--ACTION undo  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 23, 0, 24, 'u', 'n', 'd', 'o', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'u', 'n', 'd', 'o', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION first  LABEL="/adm ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 34, 20, 2, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 4, 0, 0, 23, 0, 24, 'f', 'i', 'r', 's', 't',
    0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'f', 'i', 'r', 's', 't', '.',
    'g', 'i', 'f', 0,
    /*  !--ACTION next  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) next_event / 256), (byte) ((word)
    next_event & 255), 0, 5, 0, 0, 23, 0, 24, 'n', 'e', 'x', 't', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'n', 'e', 'x', 't', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION help  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) help_event / 256), (byte) ((word)
    help_event & 255), 0, 6, 0, 0, 23, 0, 24, 'h', 'e', 'l', 'p', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'h', 'e', 'l', 'p', '.', 'g',
    'i', 'f', 0,
    /*  <IMG SRC="/admin/right.gif" BORDER=0>                                */
    0, 39, 0, '<', 'I', 'M', 'G', 32, 'S', 'R', 'C', '=', '"', '/', 'a',
    'd', 'm', 'i', 'n', '/', 'r', 'i', 'g', 'h', 't', '.', 'g', 'i',
    'f', '"', 32, 'B', 'O', 'R', 'D', 'E', 'R', '=', '0', '>', 10,
    /*  <TD ALIGN=CENTER><FONT SIZE= ... g) - FTP user access </FONT>        */
    0, 68, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '+', '1', '>', '#', '(', 'c', 'o', 'n', 'f', 'i', 'g',
    ')', 32, 45, 32, 'F', 'T', 'P', 32, 'u', 's', 'e', 'r', 32, 'a',
    'c', 'c', 'e', 's', 's', 32, '<', '/', 'F', 'O', 'N', 'T', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  <IMG SRC="/admin/left.gif" BORDER=0>                                 */
    0, 4, 1, 0, 1, 25,
    /*  !--ACTION console  LABEL="/a ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 38, 20, 2, (byte) ((word) console_event / 256), (byte) ((word)
    console_event & 255), 0, 7, 0, 0, 23, 0, 24, 'c', 'o', 'n', 's',
    'o', 'l', 'e', 0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'c', 'o', 'n',
    's', 'o', 'l', 'e', '.', 'g', 'i', 'f', 0,
    /*  !--ACTION restart  LABEL="/a ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 38, 20, 2, (byte) ((word) restart_event / 256), (byte) ((word)
    restart_event & 255), 0, 8, 0, 0, 23, 0, 24, 'r', 'e', 's', 't',
    'a', 'r', 't', 0, '/', 'a', 'd', 'm', 'i', 'n', '/', 'r', 'e', 's',
    't', 'a', 'r', 't', '.', 'g', 'i', 'f', 0,
    /*  !--ACTION halt  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) halt_event / 256), (byte) ((word)
    halt_event & 255), 0, 9, 0, 0, 23, 0, 24, 'h', 'a', 'l', 't', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'h', 'a', 'l', 't', '.', 'g',
    'i', 'f', 0,
    /*  !--ACTION exit  LABEL="/admi ... PE=IMAGE HEIGHT=23 WIDTH=24         */
    0, 32, 20, 2, (byte) ((word) exit_event / 256), (byte) ((word)
    exit_event & 255), 0, 10, 0, 0, 23, 0, 24, 'e', 'x', 'i', 't', 0,
    '/', 'a', 'd', 'm', 'i', 'n', '/', 'e', 'x', 'i', 't', '.', 'g',
    'i', 'f', 0,
    /*  <IMG SRC="/admin/right.gif" BORDER=0>                                */
    0, 4, 1, 0, 2, '2',
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD ALIGN=LEFT>                                */
    0, 39, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D', 32,
    'A', 'L', 'I', 'G', 'N', '=', 'L', 'E', 'F', 'T', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <FONT COLOR="#E00000" SIZE=+1><EM>                                   */
    0, 36, 0, '<', 'F', 'O', 'N', 'T', 32, 'C', 'O', 'L', 'O', 'R', '=',
    '"', '#', 'E', '0', '0', '0', '0', '0', '"', 32, 'S', 'I', 'Z', 'E',
    '=', '+', '1', '>', '<', 'E', 'M', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  </EM></FONT>                                                         */
    0, 14, 0, '<', '/', 'E', 'M', '>', '<', '/', 'F', 'O', 'N', 'T',
    '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 2, 161,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 'U',
    /*  <TABLE WIDTH=90% >                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '9', '0', '%', 32, '>', 10,
    /*  <TR>                                                                 */
    0, 6, 0, '<', 'T', 'R', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 35, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f260 NAME=L_user-name VALUE="User name:"            */
    0, 24, 10, 6, 1, 0, 0, 10, 0, 10, 'f', '2', '6', '0', 0, 'U', 's',
    'e', 'r', 32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 7, 0, '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f261 NAME=L_password VALUE="Password:"              */
    0, 23, 10, 6, 1, 0, 0, 9, 0, 9, 'f', '2', '6', '1', 0, 'P', 'a',
    's', 's', 'w', 'o', 'r', 'd', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f262 NAME=L_rootdir VALUE="Directory:"              */
    0, 24, 10, 6, 1, 0, 0, 10, 0, 10, 'f', '2', '6', '2', 0, 'D', 'i',
    'r', 'e', 'c', 't', 'o', 'r', 'y', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f263 NAME=L_aliases VALUE="Aliases?"                */
    0, 22, 10, 6, 1, 0, 0, 8, 0, 8, 'f', '2', '6', '3', 0, 'A', 'l',
    'i', 'a', 's', 'e', 's', '?', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f264 NAME=L_access-get VALUE="Get"                  */
    0, 17, 10, 6, 1, 0, 0, 3, 0, 3, 'f', '2', '6', '4', 0, 'G', 'e',
    't', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f265 NAME=L_access-put VALUE="Put"                  */
    0, 17, 10, 6, 1, 0, 0, 3, 0, 3, 'f', '2', '6', '5', 0, 'P', 'u',
    't', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f266 NAME=L_access-del VALUE="Del"                  */
    0, 17, 10, 6, 1, 0, 0, 3, 0, 3, 'f', '2', '6', '6', 0, 'D', 'e',
    'l', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f267 NAME=L_access-mkdir VALUE="Mkdir"              */
    0, 19, 10, 6, 1, 0, 0, 5, 0, 5, 'f', '2', '6', '7', 0, 'M', 'k',
    'd', 'i', 'r', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, '1',
    /*  !--FIELD TEXTUAL f268 NAME=L_access-rmdir VALUE="Rmdir"              */
    0, 19, 10, 6, 1, 0, 0, 5, 0, 5, 'f', '2', '6', '8', 0, 'R', 'm',
    'd', 'i', 'r', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 4, 'k',
    /*  !--REPEAT ftp_user_list  ROWS=10                                     */
    0, 7, 4, 0, 20, 0, '!', 0, 10,
    /*  </TR>                                                                */
    0, 7, 0, '<', '/', 'T', 'R', '>', 10,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 4, 4,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f269 NAME=key SIZE=20 MAX=? UPPER=0 VALUE=""        */
    0, 14, 10, 4, 10, 0, 0, 20, 0, 20, 'f', '2', '6', '9', 0, 0,
    /*  </TD>                                                                */
    0, 7, 0, '<', '/', 'T', 'D', '>', 10,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 28, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    10,
    /*  !--FIELD TEXTUAL f270 NAME=u ... E=20 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 10, 0, 0, 20, 0, 20, 'f', '2', '7', '0', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 5, 211,
    /*  !--FIELD TEXTUAL f271 NAME=p ... =12 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 10, 0, 0, 12, 0, '(', 'f', '2', '7', '1', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 5, 211,
    /*  !--FIELD TEXTUAL f272 NAME=r ... 20 MAX=100 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 10, 0, 0, 20, 0, 'd', 'f', '2', '7', '2', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 154,
    /*  !--FIELD BOOLEAN f273 NAME=aliases TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 10, 'f', '2', '7', '3', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 154,
    /*  !--FIELD BOOLEAN f274 NAME=a ... t TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 10, 'f', '2', '7', '4', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 154,
    /*  !--FIELD BOOLEAN f275 NAME=a ... t TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 10, 'f', '2', '7', '5', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 154,
    /*  !--FIELD BOOLEAN f276 NAME=a ... l TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 10, 'f', '2', '7', '6', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 154,
    /*  !--FIELD BOOLEAN f277 NAME=a ... r TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 10, 'f', '2', '7', '7', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 5, 154,
    /*  !--FIELD BOOLEAN f278 NAME=a ... r TRUE=yes FALSE=no VALUE=0         */
    0, 17, 15, 0, 10, 'f', '2', '7', '8', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 5, 202,
    /*  </TR>                                                                */
    0, 4, 1, 0, 5, 139,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 'U',
    /*  <P>Blank password means none ...  "-" means account disabled;        */
    0, 68, 0, '<', 'P', '>', 'B', 'l', 'a', 'n', 'k', 32, 'p', 'a', 's',
    's', 'w', 'o', 'r', 'd', 32, 'm', 'e', 'a', 'n', 's', 32, 'n', 'o',
    'n', 'e', 32, 'r', 'e', 'q', 'u', 'i', 'r', 'e', 'd', ';', 32, '"',
    45, '"', 32, 'm', 'e', 'a', 'n', 's', 32, 'a', 'c', 'c', 'o', 'u',
    'n', 't', 32, 'd', 'i', 's', 'a', 'b', 'l', 'e', 'd', ';', 10,
    /*  "*" means any password is ac ... en to mean the the FTP root.        */
    0, 108, 0, '"', '*', '"', 32, 'm', 'e', 'a', 'n', 's', 32, 'a', 'n',
    'y', 32, 'p', 'a', 's', 's', 'w', 'o', 'r', 'd', 32, 'i', 's', 32,
    'a', 'c', 'c', 'e', 'p', 't', 'e', 'd', 32, '(', 'a', 'n', 'o', 'n',
    'y', 'm', 'o', 'u', 's', 32, 'l', 'o', 'g', 'i', 'n', ')', '.', 32,
    32, 'A', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o', 'r', 'y', 10, 10,
    '"', '/', '"', 32, 'i', 's', 32, 't', 'a', 'k', 'e', 'n', 32, 't',
    'o', 32, 'm', 'e', 'a', 'n', 32, 't', 'h', 'e', 32, 't', 'h', 'e',
    32, 'F', 'T', 'P', 32, 'r', 'o', 'o', 't', '.', 10,
    /*  !--FIELD NUMERIC ftp_user_list SIZE=4 VALUE=10                       */
    0, 30, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'f', 't', 'p', '_',
    'u', 's', 'e', 'r', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR>                                               */
    0, 24, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD><IMG SRC="/admin/im0096c.gif"                                    */
    0, 35, 0, '<', 'T', 'D', '>', '<', 'I', 'M', 'G', 32, 'S', 'R', 'C',
    '=', '"', '/', 'a', 'd', 'm', 'i', 'n', '/', 'i', 'm', '0', '0',
    '9', '6', 'c', '.', 'g', 'i', 'f', '"', 10,
    /*  WIDTH=96 HEIGHT=36>                                                  */
    0, 21, 0, 'W', 'I', 'D', 'T', 'H', '=', '9', '6', 32, 'H', 'E', 'I',
    'G', 'H', 'T', '=', '3', '6', '>', 10,
    /*  <TD ALIGN=CENTER><FONT SIZE= ... 9 1996-98 iMatix Corporation        */
    0, 75, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', 45, '1', '>', 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't',
    32, '&', '#', '1', '6', '9', 32, '1', '9', '9', '6', 45, '9', '8',
    32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'C', 'o', 'r', 'p', 'o', 'r',
    'a', 't', 'i', 'o', 'n', 10,
    /*  <BR>Powered by iMatix Studio 1.0                                     */
    0, 34, 0, '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32,
    'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd',
    'i', 'o', 32, '1', '.', '0', 10,
    /*  <TD ALIGN=RIGHT><FONT SIZE=-1>#(date) #(time)                        */
    0, 47, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E',
    '=', 45, '1', '>', '#', '(', 'd', 'a', 't', 'e', ')', 32, '#', '(',
    't', 'i', 'm', 'e', ')', 10,
    /*  <BR>Xitami Webserver v2.4b                                           */
    0, 28, 0, '<', 'B', 'R', '>', 'X', 'i', 't', 'a', 'm', 'i', 32, 'W',
    'e', 'b', 's', 'e', 'r', 'v', 'e', 'r', 32, 'v', '2', '.', '4', 'b',
    10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 3, 'U',
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm17_fields [] = {
    { 0, 951, 80 },                     /*  message_to_user                 */
    { 82, 1105, 10 },                   /*  l_user_name                     */
    { 94, 1146, 9 },                    /*  l_password                      */
    { 105, 1183, 10 },                  /*  l_rootdir                       */
    { 117, 1221, 8 },                   /*  l_aliases                       */
    { 127, 1257, 3 },                   /*  l_access_get                    */
    { 132, 1288, 3 },                   /*  l_access_put                    */
    { 137, 1319, 3 },                   /*  l_access_del                    */
    { 142, 1350, 5 },                   /*  l_access_mkdir                  */
    { 149, 1383, 5 },                   /*  l_access_rmdir                  */
    { 156, 1466, 20 },                  /*  key                             */
    { 376, 1521, 20 },                  /*  user_name                       */
    { 596, 1549, 40 },                  /*  password                        */
    { 1016, 1577, 100 },                /*  rootdir                         */
    { 2036, 1605, 1 },                  /*  aliases                         */
    { 2066, 1636, 1 },                  /*  access_get                      */
    { 2096, 1667, 1 },                  /*  access_put                      */
    { 2126, 1698, 1 },                  /*  access_del                      */
    { 2156, 1729, 1 },                  /*  access_mkdir                    */
    { 2186, 1760, 1 },                  /*  access_rmdir                    */
    { 2216, 1977, 4 },                  /*  ftp_user_list                   */
    { 2222, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_user_name_a        ;
    char   l_user_name          [10 + 1];
    byte   l_password_a         ;
    char   l_password           [9 + 1];
    byte   l_rootdir_a          ;
    char   l_rootdir            [10 + 1];
    byte   l_aliases_a          ;
    char   l_aliases            [8 + 1];
    byte   l_access_get_a       ;
    char   l_access_get         [3 + 1];
    byte   l_access_put_a       ;
    char   l_access_put         [3 + 1];
    byte   l_access_del_a       ;
    char   l_access_del         [3 + 1];
    byte   l_access_mkdir_a     ;
    char   l_access_mkdir       [5 + 1];
    byte   l_access_rmdir_a     ;
    char   l_access_rmdir       [5 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [20 + 1];
    byte   user_name_a          [10] ;
    char   user_name            [10] [20 + 1];
    byte   password_a           [10] ;
    char   password             [10] [40 + 1];
    byte   rootdir_a            [10] ;
    char   rootdir              [10] [100 + 1];
    byte   aliases_a            [10] ;
    char   aliases              [10] [1 + 1];
    byte   access_get_a         [10] ;
    char   access_get           [10] [1 + 1];
    byte   access_put_a         [10] ;
    char   access_put           [10] [1 + 1];
    byte   access_del_a         [10] ;
    char   access_del           [10] [1 + 1];
    byte   access_mkdir_a       [10] ;
    char   access_mkdir         [10] [1 + 1];
    byte   access_rmdir_a       [10] ;
    char   access_rmdir         [10] [1 + 1];
    byte   ftp_user_list_a      ;
    char   ftp_user_list        [4 + 1];
    byte   back_a;
    byte   save_a;
    byte   clear_a;
    byte   undo_a;
    byte   first_a;
    byte   next_a;
    byte   help_a;
    byte   console_a;
    byte   restart_a;
    byte   halt_a;
    byte   exit_a;
    } XIADM17_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm17 = {
    xiadm17_blocks,
    xiadm17_fields,
    114,                                /*  Number of blocks in form        */
    21,                                 /*  Number of fields in form        */
    11,                                 /*  Number of actions in form       */
    2222,                               /*  Size of fields                  */
    "xiadm17",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
