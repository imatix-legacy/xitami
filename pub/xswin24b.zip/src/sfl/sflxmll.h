/*===========================================================================*
 *                                                                           *
 *  sflxmll.h   XML loading and saving functions                             *
 *                                                                           *
 *  Written:    98/03/30  iMatix SFL project team <sfl@imatix.com>           *
 *  Revised:    98/04/01                                                     *
 *                                                                           *
 *  XML file loader.  Copyright (c) 1998 iMatix.                             *
 *                                                                           *
 *  This program is free software; you can redistribute it and/or modify     *
 *  it under the terms of the GNU General Public License as published by     *
 *  the Free Software Foundation; either version 2 of the License, or        *
 *  (at your option) any later version.                                      *
 *                                                                           *
 *  This program is distributed in the hope that it will be useful,          *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 *  GNU General Public License for more details.                             *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License        *
 *  along with this program; if not, write to the Free Software              *
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                *
 *                                                                           *
 *===========================================================================*/

#ifndef SLFXMLL_INCLUDED               /*  Allow multiple inclusions        */
#define SLFXMLL_INCLUDED

/*- Function prototypes ---------------------------------------------------- */

#ifdef __cplusplus
extern "C" {
#endif

XML_ITEM *xml_load  (const char *path, const char *filename);
int       xml_save  (XML_ITEM   *item, const char *filename);
char     *xml_error (void);

#ifdef __cplusplus
}
#endif

#endif                                  /*  Included                         */
