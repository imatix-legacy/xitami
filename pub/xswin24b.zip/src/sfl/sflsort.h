/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflsort.h
    Title:      Sorting functions
    Package:    Standard Function Library (SFL)

    Written:    98/07/07  iMatix SFL project team <sfl@imatix.com>
    Revised:    98/07/07

    Synopsis:   Provides functions to sort lists defined using stuctures of
                sfllist.

    Copyright:  Copyright (c) 1991-98 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef SFLSORT_INCLUDED               /*  Allow multiple inclusions        */
#define SFLSORT_INCLUDED

/*- Function type for comparison function used for sorting ------------------*/

typedef int (LIST_COMPARE) (LIST *t1, LIST *t2);


/*- Function prototypes -----------------------------------------------------*/

void comb_sort (void *list, LIST_COMPARE *comp);


#endif



