/*---------------------------------------------------------------------------
 *  xiadm01.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM01__
#define __FORM_XIADM01__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM01_MESSAGE_TO_USER             0

/*  This table contains each block in the form                               */

static byte xiadm01_blocks [] = {
    /*  <HTML><HEAD><TITLE>Xitami Administration</TITLE></HEAD><BODY>        */
    0, 62, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'X', 'i', 't', 'a', 'm',
    'i', 32, 'A', 'd', 'm', 'i', 'n', 'i', 's', 't', 'r', 'a', 't', 'i',
    'o', 'n', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', '<', '/', 'H',
    'E', 'A', 'D', '>', '<', 'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><EM>Main</EM> | ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 136, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'E', 'M', '>', 'M', 'a', 'i', 'n', '<', '/', 'E',
    'M', '>', 32, '|', 32, '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '&', '~', 'L', 'c', 'o', 'n', 's',
    'o', 'l', 'e', '=', '1', '"', '>', 'C', 'o', 'n', 's', 'o', 'l',
    'e', '<', '/', 'A', '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R',
    'G', 'E', 'T', '=', '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E',
    'F', '=', '"', 'x', 'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd',
    'e', 'x', '4', '.', 'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p',
    '<', '/', 'A', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E',
    '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  Xitami Administration                                                */
    0, 22, 0, 'X', 'i', 't', 'a', 'm', 'i', 32, 'A', 'd', 'm', 'i', 'n',
    'i', 's', 't', 'r', 'a', 't', 'i', 'o', 'n',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <HR><H2><A NAME="TOC1">Xitami Administration</A></H2>                */
    0, 54, 0, '<', 'H', 'R', '>', '<', 'H', '2', '>', '<', 'A', 32, 'N',
    'A', 'M', 'E', '=', '"', 'T', 'O', 'C', '1', '"', '>', 'X', 'i',
    't', 'a', 'm', 'i', 32, 'A', 'd', 'm', 'i', 'n', 'i', 's', 't', 'r',
    'a', 't', 'i', 'o', 'n', '<', '/', 'A', '>', '<', '/', 'H', '2',
    '>',
    /*  <UL>                                                                 */
    0, 5, 0, '<', 'U', 'L', '>',
    /*  <P><LI><A HREF="#(uri)&~Lbasic=1">Normal Configuration</A>           */
    0, 59, 0, '<', 'P', '>', '<', 'L', 'I', '>', '<', 'A', 32, 'H', 'R',
    'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&', '~', 'L',
    'b', 'a', 's', 'i', 'c', '=', '1', '"', '>', 'N', 'o', 'r', 'm',
    'a', 'l', 32, 'C', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't', 'i',
    'o', 'n', '<', '/', 'A', '>',
    /*  <BR>Define HTTP and FTP prop ... a normal single-host server.        */
    0, 69, 0, '<', 'B', 'R', '>', 'D', 'e', 'f', 'i', 'n', 'e', 32, 'H',
    'T', 'T', 'P', 32, 'a', 'n', 'd', 32, 'F', 'T', 'P', 32, 'p', 'r',
    'o', 'p', 'e', 'r', 't', 'i', 'e', 's', ',', 32, 'f', 'o', 'r', 32,
    'a', 32, 'n', 'o', 'r', 'm', 'a', 'l', 32, 's', 'i', 'n', 'g', 'l',
    'e', 45, 'h', 'o', 's', 't', 32, 's', 'e', 'r', 'v', 'e', 'r', '.',
    /*  Use the Console to restart the server after you make changes.        */
    0, 62, 0, 'U', 's', 'e', 32, 't', 'h', 'e', 32, 'C', 'o', 'n', 's',
    'o', 'l', 'e', 32, 't', 'o', 32, 'r', 'e', 's', 't', 'a', 'r', 't',
    32, 't', 'h', 'e', 32, 's', 'e', 'r', 'v', 'e', 'r', 32, 'a', 'f',
    't', 'e', 'r', 32, 'y', 'o', 'u', 32, 'm', 'a', 'k', 'e', 32, 'c',
    'h', 'a', 'n', 'g', 'e', 's', '.',
    /*  <P><LI><A HREF="#(uri)&~Ladv ... ">Advanced Configuration</A>        */
    0, 64, 0, '<', 'P', '>', '<', 'L', 'I', '>', '<', 'A', 32, 'H', 'R',
    'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&', '~', 'L',
    'a', 'd', 'v', 'a', 'n', 'c', 'e', 'd', '=', '1', '"', '>', 'A',
    'd', 'v', 'a', 'n', 'c', 'e', 'd', 32, 'C', 'o', 'n', 'f', 'i', 'g',
    'u', 'r', 'a', 't', 'i', 'o', 'n', '<', '/', 'A', '>',
    /*  <BR>Work with multiple confi ... s for a virtual-host server.        */
    0, 72, 0, '<', 'B', 'R', '>', 'W', 'o', 'r', 'k', 32, 'w', 'i', 't',
    'h', 32, 'm', 'u', 'l', 't', 'i', 'p', 'l', 'e', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 'u', 'r', 'a', 't', 'i', 'o', 'n', 32, 's', 'c', 'h',
    'e', 'm', 'a', 's', 32, 'f', 'o', 'r', 32, 'a', 32, 'v', 'i', 'r',
    't', 'u', 'a', 'l', 45, 'h', 'o', 's', 't', 32, 's', 'e', 'r', 'v',
    'e', 'r', '.',
    /*  <P><LI><A HREF="#(uri)&~Lwizard=1">Virtual host wizard</A>           */
    0, 59, 0, '<', 'P', '>', '<', 'L', 'I', '>', '<', 'A', 32, 'H', 'R',
    'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&', '~', 'L',
    'w', 'i', 'z', 'a', 'r', 'd', '=', '1', '"', '>', 'V', 'i', 'r',
    't', 'u', 'a', 'l', 32, 'h', 'o', 's', 't', 32, 'w', 'i', 'z', 'a',
    'r', 'd', '<', '/', 'A', '>',
    /*  <BR>A quick way to add a new virtual host.                           */
    0, 43, 0, '<', 'B', 'R', '>', 'A', 32, 'q', 'u', 'i', 'c', 'k', 32,
    'w', 'a', 'y', 32, 't', 'o', 32, 'a', 'd', 'd', 32, 'a', 32, 'n',
    'e', 'w', 32, 'v', 'i', 'r', 't', 'u', 'a', 'l', 32, 'h', 'o', 's',
    't', '.',
    /*  <P><LI><A HREF="#(uri)&~Lconsole=1">Server Console Panel</A>         */
    0, 61, 0, '<', 'P', '>', '<', 'L', 'I', '>', '<', 'A', 32, 'H', 'R',
    'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&', '~', 'L',
    'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>', 'S', 'e',
    'r', 'v', 'e', 'r', 32, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'P',
    'a', 'n', 'e', 'l', '<', '/', 'A', '>',
    /*  <BR>Show current connections ... og; stop/restart the server.        */
    0, 68, 0, '<', 'B', 'R', '>', 'S', 'h', 'o', 'w', 32, 'c', 'u', 'r',
    'r', 'e', 'n', 't', 32, 'c', 'o', 'n', 'n', 'e', 'c', 't', 'i', 'o',
    'n', 's', ',', 32, 'c', 'o', 'n', 's', 'o', 'l', 'e', 32, 'l', 'o',
    'g', ';', 32, 's', 't', 'o', 'p', '/', 'r', 'e', 's', 't', 'a', 'r',
    't', 32, 't', 'h', 'e', 32, 's', 'e', 'r', 'v', 'e', 'r', '.',
    /*  </UL><P>                                                             */
    0, 9, 0, '<', '/', 'U', 'L', '>', '<', 'P', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 152, 0, 13,
    /*  To navigate between these sc ... ill redisplay this mainpage.        */
    1, 34, 0, 'T', 'o', 32, 'n', 'a', 'v', 'i', 'g', 'a', 't', 'e', 32,
    'b', 'e', 't', 'w', 'e', 'e', 'n', 32, 't', 'h', 'e', 's', 'e', 32,
    's', 'c', 'r', 'e', 'e', 'n', 's', ',', 32, 'u', 's', 'e', 32, 'o',
    'n', 'l', 'y', 32, 't', 'h', 'e', 32, 'b', 'u', 't', 't', 'o', 'n',
    's', 32, 'o', 'r', 32, 'h', 'y', 'p', 'e', 'r', 'l', 'i', 'n', 'k',
    's', '.', 10, 'D', 'o', 32, 'n', 'o', 't', 32, 't', 'r', 'y', 32,
    't', 'o', 32, 'u', 's', 'e', 32, 't', 'h', 'e', 32, 'b', 'r', 'o',
    'w', 's', 'e', 'r', 32, 39, 'B', 'a', 'c', 'k', 39, 32, 'b', 'u',
    't', 't', 'o', 'n', '.', 32, 32, 'I', 'f', 32, 'y', 'o', 'u', 32,
    'a', 'r', 'e', 32, 'a', 'c', 'c', 'e', 's', 's', 'i', 'n', 'g', 32,
    't', 'h', 'e', 's', 'e', 10, 'p', 'a', 'g', 'e', 's', 32, 't', 'h',
    'r', 'o', 'u', 'g', 'h', 32, 'a', 32, 'p', 'r', 'o', 'x', 'y', 32,
    's', 'e', 'r', 'v', 'e', 'r', ',', 32, 'd', 'i', 's', 'a', 'b', 'l',
    'e', 32, 'p', 'r', 'o', 'x', 'y', 32, 'a', 'c', 'c', 'e', 's', 's',
    32, 't', 'o', 32, 't', 'h', 'i', 's', 32, 'U', 'R', 'L', '.', 32,
    32, 'W', 'h', 'e', 'n', 10, 'X', 'i', 't', 'a', 'm', 'i', 32, 'c',
    'a', 'n', 'n', 'o', 't', 32, 'c', 'o', 'n', 't', 'i', 'n', 'u', 'e',
    32, 'a', 32, 'p', 'r', 'e', 'v', 'i', 'o', 'u', 's', 32, 's', 'e',
    's', 's', 'i', 'o', 'n', 32, 'i', 't', 32, 'w', 'i', 'l', 'l', 32,
    'r', 'e', 'd', 'i', 's', 'p', 'l', 'a', 'y', 32, 't', 'h', 'i', 's',
    32, 'm', 'a', 'i', 'n', 10, 'p', 'a', 'g', 'e', '.',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 't',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, '{',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 152, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '"',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 152, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'M',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm01_fields [] = {
    { 0, 90, 80 },                      /*  message_to_user                 */
    { 82, 0, 0 },                       /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    } XIADM01_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm01 = {
    xiadm01_blocks,
    xiadm01_fields,
    33,                                 /*  Number of blocks in form        */
    1,                                  /*  Number of fields in form        */
    0,                                  /*  Number of actions in form       */
    82,                                 /*  Size of fields                  */
    "xiadm01",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
