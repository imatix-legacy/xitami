/*---------------------------------------------------------------------------
 *  xiadm13.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM13__
#define __FORM_XIADM13__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define USER_LIST_MAX                       10
#define XIADM13_MESSAGE_TO_USER             0
#define XIADM13_L_USER_NAME                 1
#define XIADM13_L_PASSWORD                  2
#define XIADM13_KEY                         3
#define XIADM13_USER_NAME                   4
#define XIADM13_PASSWORD                    5
#define XIADM13_L_NONAME11                  6
#define XIADM13_USER_LIST                   7

/*  This table contains each block in the form                               */

static byte xiadm13_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) ... for URI</TITLE></HEAD><BODY>        */
    0, 70, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'U', 's', 'e', 'r', 32, 'l', 'i',
    's', 't', 32, 'f', 'o', 'r', 32, 'U', 'R', 'I', '<', '/', 'T', 'I',
    'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B',
    'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - User list for URI                                        */
    0, 30, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'U', 's', 'e', 'r', 32, 'l', 'i', 's', 't', 32, 'f', 'o', 'r', 32,
    'U', 'R', 'I',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 47, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>',
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 20, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, '?', 0, 28,
    /*  !--FIELD TEXTUAL 182 NAME=L_user-name VALUE="User name:"             */
    0, 22, 10, 6, 1, 0, 10, 0, 10, '1', '8', '2', 0, 'U', 's', 'e', 'r',
    32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, '?', 0, 28,
    /*  !--FIELD TEXTUAL 183 NAME=L_password VALUE="Password:"               */
    0, 21, 10, 6, 1, 0, 9, 0, 9, '1', '8', '3', 0, 'P', 'a', 's', 's',
    'w', 'o', 'r', 'd', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 131,
    /*  !--REPEAT user_list  ROWS=10                                         */
    0, 7, 4, 0, 7, 0, 12, 0, 10,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, '8',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 184 NAME=key SIZE=20 MAX=? VALUE=""                 */
    0, 12, 10, 4, 10, 0, 20, 0, 20, '1', '8', '4', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL 185 NAME=user-name SIZE=20 MAX=? VALUE=""           */
    0, 12, 10, 0, 10, 0, 20, 0, 20, '1', '8', '5', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 2, 244,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 2, 252,
    /*  !--FIELD TEXTUAL 186 NAME=password SIZE=20 MAX=? VALUE=""            */
    0, 12, 10, 0, 10, 0, 20, 0, 20, '1', '8', '6', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 2, 244,
    /*  </TR>                                                                */
    0, 4, 1, 0, 2, 185,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 187 NAME=L_ ... UE="Actions for this page:"         */
    0, 34, 10, 6, 1, 0, 22, 0, 22, '1', '8', '7', 0, 'A', 'c', 't', 'i',
    'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32, 'p',
    'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 2, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 4, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 5, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't', 0,
    'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  !--FIELD NUMERIC user_list SIZE=4 VALUE=10                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'u', 's', 'e', 'r',
    '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, '|',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 131,
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 160, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '?',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 160, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm13_fields [] = {
    { 0, 98, 80 },                      /*  message_to_user                 */
    { 82, 619, 10 },                    /*  L_user-name                     */
    { 94, 659, 9 },                     /*  L_password                      */
    { 105, 742, 20 },                   /*  key                             */
    { 325, 793, 20 },                   /*  user-name                       */
    { 545, 819, 20 },                   /*  password                        */
    { 765, 917, 22 },                   /*  L_noname11                      */
    { 789, 1113, 4 },                   /*  user_list                       */
    { 795, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_user_name_a        ;
    char   l_user_name          [10 + 1];
    byte   l_password_a         ;
    char   l_password           [9 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [20 + 1];
    byte   user_name_a          [10] ;
    char   user_name            [10] [20 + 1];
    byte   password_a           [10] ;
    char   password             [10] [20 + 1];
    byte   l_noname11_a         ;
    char   l_noname11           [22 + 1];
    byte   user_list_a          ;
    char   user_list            [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM13_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm13 = {
    xiadm13_blocks,
    xiadm13_fields,
    61,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    6,                                  /*  Number of actions in form       */
    795,                                /*  Size of fields                  */
    "xiadm13",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
