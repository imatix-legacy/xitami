/*---------------------------------------------------------------------------
 *  xiadm03.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM03__
#define __FORM_XIADM03__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM03_MESSAGE_TO_USER             0
#define XIADM03_MAIN_CONFIG                 1
#define XIADM03_ON_UNIX                     2
#define XIADM03_ON_WINDOWS_32               3
#define XIADM03_L_IPADDRESS                 4
#define XIADM03_IPADDRESS                   5
#define XIADM03_L_PORTBASE                  6
#define XIADM03_PORTBASE                    7
#define XIADM03_L_PORTBASE1                 8
#define XIADM03_PORTBASE1                   9
#define XIADM03_PORTBASE2                   10
#define XIADM03_PORTBASE3                   11
#define XIADM03_PORTBASE4                   12
#define XIADM03_PORTBASE5                   13
#define XIADM03_L_BASE_HOST                 14
#define XIADM03_BASE_HOST                   15
#define XIADM03_L_WEBPAGES                  16
#define XIADM03_WEBPAGES                    17
#define XIADM03_L_CGI_BIN                   18
#define XIADM03_CGI_BIN                     19
#define XIADM03_L_CGI_URL                   20
#define XIADM03_CGI_URL                     21
#define XIADM03_L_REFRESH                   22
#define XIADM03_REFRESH                     23
#define XIADM03_L_DEBUG                     24
#define XIADM03_DEBUG                       25
#define XIADM03_L_LIMIT                     26
#define XIADM03_LIMIT                       27
#define XIADM03_L_BACKGROUND                28
#define XIADM03_BACKGROUND                  29
#define XIADM03_L_AUTOSTART                 30
#define XIADM03_AUTOSTART                   31
#define XIADM03_L_TRANSLATE                 32
#define XIADM03_TRANSLATE                   33
#define XIADM03_L_HOSTNAME                  34
#define XIADM03_HOSTNAME                    35
#define XIADM03_L_KEEP_ALIVE                36
#define XIADM03_KEEP_ALIVE                  37
#define XIADM03_L_KEEP_ALIVE_MAX            38
#define XIADM03_KEEP_ALIVE_MAX              39
#define XIADM03_L_TIMEOUT                   40
#define XIADM03_TIMEOUT                     41
#define XIADM03_L_DEFAULT1                  42
#define XIADM03_DEFAULT1                    43
#define XIADM03_L_DEFAULT2                  44
#define XIADM03_DEFAULT2                    45
#define XIADM03_DEFAULT3                    46
#define XIADM03_DEFAULT4                    47
#define XIADM03_L_NONAME1                   48
#define XIADM03_L_TEST_URI                  49
#define XIADM03_TEST_URI                    50
#define XIADM03_L_MAPPED_URI                51
#define XIADM03_MAPPED_URI                  52

/*  This table contains each block in the form                               */

static byte xiadm03_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) ... perties</TITLE></HEAD><BODY>        */
    0, 70, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'S', 'e', 'r', 'v', 'e', 'r', 32,
    'P', 'r', 'o', 'p', 'e', 'r', 't', 'i', 'e', 's', '<', '/', 'T',
    'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A', 'D', '>', '<',
    'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - Server Properties                                        */
    0, 30, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'S', 'e', 'r', 'v', 'e', 'r', 32, 'P', 'r', 'o', 'p', 'e', 'r', 't',
    'i', 'e', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '?',
    /*  <EM>Server</EM>                                                      */
    0, 16, 0, '<', 'E', 'M', '>', 'S', 'e', 'r', 'v', 'e', 'r', '<',
    '/', 'E', 'M', '>',
    /*  !--ACTION aliases  LABEL="Al ... T=aliases_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 2, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  !--ACTION vhosts  LABEL="Vho ... NT=vhosts_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 3, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 4, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... =security_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 5, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  !--ACTION logging  LABEL="Lo ... T=logging_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) logging_event / 256), (byte) ((word)
    logging_event & 255), 0, 6, 0, 0, 0, 0, 0, 'l', 'o', 'g', 'g', 'i',
    'n', 'g', 0, 'L', 'o', 'g', 'g', 'i', 'n', 'g', 0,
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 7, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=BUTTON           */
    0, 21, 20, 0, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 8, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0, 'M',
    'I', 'M', 'E', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  !--FIELD NUMERIC main_config SIZE=4 VALUE=1                          */
    0, 27, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'm', 'a', 'i', 'n',
    '_', 'c', 'o', 'n', 'f', 'i', 'g', 0, '1', 0,
    /*  !--FIELD NUMERIC on_unix SIZE=4 VALUE=1                              */
    0, 23, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'o', 'n', '_', 'u',
    'n', 'i', 'x', 0, '1', 0,
    /*  !--FIELD NUMERIC on_windows_32 SIZE=4 VALUE=1                        */
    0, 29, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'o', 'n', '_', 'w',
    'i', 'n', 'd', 'o', 'w', 's', '_', '3', '2', 0, '1', 0,
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  !--IF main_config                                                    */
    0, 5, 2, 0, 1, 0, 20,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 10 NAME=L_i ...  VALUE="Server IP address:"         */
    0, 29, 10, 6, 1, 0, 18, 0, 18, '1', '0', 0, 'S', 'e', 'r', 'v', 'e',
    'r', 32, 'I', 'P', 32, 'a', 'd', 'd', 'r', 'e', 's', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--FIELD SELECT 11 NAME=ipad ... ype=dynamic 0="Any address"         */
    0, 22, 15, 0, 1, 1, 0, '1', '1', 0, '0', 0, 'A', 'n', 'y', 32, 'a',
    'd', 'd', 'r', 'e', 's', 's', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 12 NAME=L_portbase VALUE="IP port base:"            */
    0, 24, 10, 6, 1, 0, 13, 0, 13, '1', '2', 0, 'I', 'P', 32, 'p', 'o',
    'r', 't', 32, 'b', 'a', 's', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD NUMERIC 13 NAME=por ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, '1', '3', 0, 0,
    /*  !--FIELD TEXTUAL 14 NAME=L_p ... "&nbsp;&nbsp;Alternatives:"         */
    0, 36, 10, 6, 1, 0, 25, 0, 25, '1', '4', 0, '&', 'n', 'b', 's', 'p',
    ';', '&', 'n', 'b', 's', 'p', ';', 'A', 'l', 't', 'e', 'r', 'n',
    'a', 't', 'i', 'v', 'e', 's', ':', 0,
    /*  !--FIELD NUMERIC 15 NAME=por ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, '1', '5', 0, 0,
    /*  !--FIELD NUMERIC 16 NAME=por ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, '1', '6', 0, 0,
    /*  !--FIELD NUMERIC 17 NAME=por ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, '1', '7', 0, 0,
    /*  !--FIELD NUMERIC 18 NAME=por ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, '1', '8', 0, 0,
    /*  !--FIELD NUMERIC 19 NAME=por ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, '1', '9', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 20 NAME=L_b ... UE="Base host config file:"         */
    0, 33, 10, 6, 1, 0, 22, 0, 22, '2', '0', 0, 'B', 'a', 's', 'e', 32,
    'h', 'o', 's', 't', 32, 'c', 'o', 'n', 'f', 'i', 'g', 32, 'f', 'i',
    'l', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 21 NAME=base-host SIZE=40 MAX=? VALUE=""            */
    0, 11, 10, 0, 1, 0, '(', 0, '(', '2', '1', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 22 NAME=L_w ... ALUE="HTML root directory:"         */
    0, 31, 10, 6, 1, 0, 20, 0, 20, '2', '2', 0, 'H', 'T', 'M', 'L', 32,
    'r', 'o', 'o', 't', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o', 'r', 'y',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 23 NAME=webpages SIZE=40 MAX=100 VALUE=""           */
    0, 11, 10, 0, 1, 0, '(', 0, 'd', '2', '3', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 24 NAME=L_cgi-bin VALUE="CGI directory:"            */
    0, 25, 10, 6, 1, 0, 14, 0, 14, '2', '4', 0, 'C', 'G', 'I', 32, 'd',
    'i', 'r', 'e', 'c', 't', 'o', 'r', 'y', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 25 NAME=cgi-bin SIZE=40 MAX=100 VALUE=""            */
    0, 11, 10, 0, 1, 0, '(', 0, 'd', '2', '5', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 26 NAME=L_c ... ALUE="CGI URLs start with:"         */
    0, 31, 10, 6, 1, 0, 20, 0, 20, '2', '6', 0, 'C', 'G', 'I', 32, 'U',
    'R', 'L', 's', 32, 's', 't', 'a', 'r', 't', 32, 'w', 'i', 't', 'h',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 27 NAME=cgi-url SIZE=40 MAX=? VALUE=""              */
    0, 11, 10, 0, 1, 0, '(', 0, '(', '2', '7', 0, 0,
    /*  !--IF main_config                                                    */
    0, 5, 2, 0, 1, 0, 12,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 28 NAME=L_r ... ALUE="Reload config every:"         */
    0, 31, 10, 6, 1, 0, 20, 0, 20, '2', '8', 0, 'R', 'e', 'l', 'o', 'a',
    'd', 32, 'c', 'o', 'n', 'f', 'i', 'g', 32, 'e', 'v', 'e', 'r', 'y',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD NUMERIC 29 NAME=ref ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, '2', '9', 0, 0,
    /*  seconds                                                              */
    0, 8, 0, 's', 'e', 'c', 'o', 'n', 'd', 's',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 30 NAME=L_debug VALUE="Run in debug mode?"          */
    0, 29, 10, 6, 1, 0, 18, 0, 18, '3', '0', 0, 'R', 'u', 'n', 32, 'i',
    'n', 32, 'd', 'e', 'b', 'u', 'g', 32, 'm', 'o', 'd', 'e', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD BOOLEAN 31 NAME=debug TRUE=yes FALSE=no VALUE=0             */
    0, 15, 14, 0, 1, '3', '1', 0, '0', 0, 'y', 'e', 's', 0, 'n', 'o', 0,
    /*  - creates additional log files                                       */
    0, 31, 0, 45, 32, 'c', 'r', 'e', 'a', 't', 'e', 's', 32, 'a', 'd',
    'd', 'i', 't', 'i', 'o', 'n', 'a', 'l', 32, 'l', 'o', 'g', 32, 'f',
    'i', 'l', 'e', 's',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 32 NAME=L_l ... UE="Max. HTTP connections:"         */
    0, 33, 10, 6, 1, 0, 22, 0, 22, '3', '2', 0, 'M', 'a', 'x', '.', 32,
    'H', 'T', 'T', 'P', 32, 'c', 'o', 'n', 'n', 'e', 'c', 't', 'i', 'o',
    'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD NUMERIC 33 NAME=lim ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, '3', '3', 0, 0,
    /*  if any                                                               */
    0, 7, 0, 'i', 'f', 32, 'a', 'n', 'y',
    /*  !--IF on_unix                                                        */
    0, 5, 2, 0, 2, 0, 5,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 34 NAME=L_b ...  VALUE="Run in background?"         */
    0, 29, 10, 6, 1, 0, 18, 0, 18, '3', '4', 0, 'R', 'u', 'n', 32, 'i',
    'n', 32, 'b', 'a', 'c', 'k', 'g', 'r', 'o', 'u', 'n', 'd', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD BOOLEAN 35 NAME=background TRUE=yes FALSE=no VALUE=0        */
    0, 15, 14, 0, 1, '3', '5', 0, '0', 0, 'y', 'e', 's', 0, 'n', 'o', 0,
    /*  !--IF on_windows_32                                                  */
    0, 5, 2, 0, 3, 0, 5,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 36 NAME=L_a ... tart when TCP/IP is ready?"         */
    0, 38, 10, 6, 1, 0, 27, 0, 27, '3', '6', 0, 'S', 't', 'a', 'r', 't',
    32, 'w', 'h', 'e', 'n', 32, 'T', 'C', 'P', '/', 'I', 'P', 32, 'i',
    's', 32, 'r', 'e', 'a', 'd', 'y', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD BOOLEAN 37 NAME=autostart TRUE=yes FALSE=no VALUE=0         */
    0, 15, 14, 0, 1, '3', '7', 0, '0', 0, 'y', 'e', 's', 0, 'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 38 NAME=L_t ... stname in redirected URLs?"         */
    0, 43, 10, 6, 1, 0, 32, 0, 32, '3', '8', 0, 'U', 's', 'e', 32, 'h',
    'o', 's', 't', 'n', 'a', 'm', 'e', 32, 'i', 'n', 32, 'r', 'e', 'd',
    'i', 'r', 'e', 'c', 't', 'e', 'd', 32, 'U', 'R', 'L', 's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD BOOLEAN 39 NAME=translate TRUE=yes FALSE=no VALUE=0         */
    0, 15, 14, 0, 1, '3', '9', 0, '0', 0, 'y', 'e', 's', 0, 'n', 'o', 0,
    /*  - switch-off for PPP links                                           */
    0, 27, 0, 45, 32, 's', 'w', 'i', 't', 'c', 'h', 45, 'o', 'f', 'f',
    32, 'f', 'o', 'r', 32, 'P', 'P', 'P', 32, 'l', 'i', 'n', 'k', 's',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 40 NAME=L_h ... tname for redirected URLs:"         */
    0, 40, 10, 6, 1, 0, 29, 0, 29, '4', '0', 0, 'H', 'o', 's', 't', 'n',
    'a', 'm', 'e', 32, 'f', 'o', 'r', 32, 'r', 'e', 'd', 'i', 'r', 'e',
    'c', 't', 'e', 'd', 32, 'U', 'R', 'L', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 41 NAME=hostname SIZE=40 MAX=80 VALUE=""            */
    0, 11, 10, 0, 1, 0, '(', 0, 'P', '4', '1', 0, 0,
    /*  - for virtual hosts using IP address                                 */
    0, 37, 0, 45, 32, 'f', 'o', 'r', 32, 'v', 'i', 'r', 't', 'u', 'a',
    'l', 32, 'h', 'o', 's', 't', 's', 32, 'u', 's', 'i', 'n', 'g', 32,
    'I', 'P', 32, 'a', 'd', 'd', 'r', 'e', 's', 's',
    /*  <TR><TD></TD><TD>                                                    */
    0, 18, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 42 NAME=L_k ... E="Keep-Alive connections?"         */
    0, 34, 10, 6, 1, 0, 23, 0, 23, '4', '2', 0, 'K', 'e', 'e', 'p', 45,
    'A', 'l', 'i', 'v', 'e', 32, 'c', 'o', 'n', 'n', 'e', 'c', 't', 'i',
    'o', 'n', 's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD BOOLEAN 43 NAME=keep-alive TRUE=yes FALSE=no VALUE=0        */
    0, 15, 14, 0, 1, '4', '3', 0, '0', 0, 'y', 'e', 's', 0, 'n', 'o', 0,
    /*  !--FIELD TEXTUAL 44 NAME=L_k ... ="&nbsp;&nbsp;Allow up to:"         */
    0, 35, 10, 6, 1, 0, 24, 0, 24, '4', '4', 0, '&', 'n', 'b', 's', 'p',
    ';', '&', 'n', 'b', 's', 'p', ';', 'A', 'l', 'l', 'o', 'w', 32, 'u',
    'p', 32, 't', 'o', ':', 0,
    /*  !--FIELD NUMERIC 45 NAME=kee ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, '4', '5', 0, 0,
    /*  requests                                                             */
    0, 9, 0, 'r', 'e', 'q', 'u', 'e', 's', 't', 's',
    /*  !--FIELD TEXTUAL 46 NAME=L_t ... ="&nbsp;&nbsp;Close after:"         */
    0, 35, 10, 6, 1, 0, 24, 0, 24, '4', '6', 0, '&', 'n', 'b', 's', 'p',
    ';', '&', 'n', 'b', 's', 'p', ';', 'C', 'l', 'o', 's', 'e', 32, 'a',
    'f', 't', 'e', 'r', ':', 0,
    /*  !--FIELD NUMERIC 47 NAME=tim ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 17, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, '4', '7', 0, 0,
    /*  seconds                                                              */
    0, 4, 1, 0, 6, 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 8, '6',
    /*  <P>                                                                  */
    0, 4, 1, 0, 8, 'J',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 48 NAME=L_d ...  VALUE="Default HTML page:"         */
    0, 29, 10, 6, 1, 0, 18, 0, 18, '4', '8', 0, 'D', 'e', 'f', 'a', 'u',
    'l', 't', 32, 'H', 'T', 'M', 'L', 32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 49 NAME=default1 SIZE=12 MAX=40 VALUE=""            */
    0, 11, 10, 0, 1, 0, 12, 0, '(', '4', '9', 0, 0,
    /*  !--FIELD TEXTUAL 50 NAME=L_default2 VALUE="&nbsp;&nbsp;Then:"        */
    0, 28, 10, 6, 1, 0, 17, 0, 17, '5', '0', 0, '&', 'n', 'b', 's', 'p',
    ';', '&', 'n', 'b', 's', 'p', ';', 'T', 'h', 'e', 'n', ':', 0,
    /*  !--FIELD TEXTUAL 51 NAME=default2 SIZE=12 MAX=40 VALUE=""            */
    0, 11, 10, 0, 1, 0, 12, 0, '(', '5', '1', 0, 0,
    /*  !--FIELD TEXTUAL 52 NAME=default3 SIZE=12 MAX=40 VALUE=""            */
    0, 11, 10, 0, 1, 0, 12, 0, '(', '5', '2', 0, 0,
    /*  !--FIELD TEXTUAL 53 NAME=default4 SIZE=12 MAX=40 VALUE=""            */
    0, 11, 10, 0, 1, 0, 12, 0, '(', '5', '3', 0, 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 8, '6',
    /*  <P>                                                                  */
    0, 4, 1, 0, 8, 'J',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 54 NAME=L_n ... UE="Actions for this page:"         */
    0, 33, 10, 6, 1, 0, 22, 0, 22, '5', '4', 0, 'A', 'c', 't', 'i', 'o',
    'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32, 'p', 'a',
    'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 9, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 10, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION errors  LABEL="Err ... NT=errors_event TYPE=BUTTON         */
    0, 28, 20, 0, (byte) ((word) errors_event / 256), (byte) ((word)
    errors_event & 255), 0, 11, 0, 0, 0, 0, 0, 'e', 'r', 'r', 'o', 'r',
    's', 0, 'E', 'r', 'r', 'o', 'r', 's', '.', '.', '.', 0,
    /*  !--ACTION wsx  LABEL="WSX..." EVENT=wsx_event TYPE=BUTTON            */
    0, 22, 20, 0, (byte) ((word) wsx_event / 256), (byte) ((word)
    wsx_event & 255), 0, 12, 0, 0, 0, 0, 0, 'w', 's', 'x', 0, 'W', 'S',
    'X', '.', '.', '.', 0,
    /*  !--ACTION filters  LABEL="Fi ... NT=filter_event TYPE=BUTTON         */
    0, 30, 20, 0, (byte) ((word) filter_event / 256), (byte) ((word)
    filter_event & 255), 0, 13, 0, 0, 0, 0, 0, 'f', 'i', 'l', 't', 'e',
    'r', 's', 0, 'F', 'i', 'l', 't', 'e', 'r', 's', '.', '.', '.', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 8, '6',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, '|',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 55 NAME=L_test-uri VALUE="Test URI mapping:"        */
    0, 28, 10, 6, 1, 0, 17, 0, 17, '5', '5', 0, 'T', 'e', 's', 't', 32,
    'U', 'R', 'I', 32, 'm', 'a', 'p', 'p', 'i', 'n', 'g', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 56 NAME=test-uri SIZE=50 MAX=? VALUE=""             */
    0, 11, 10, 0, 1, 0, '2', 0, '2', '5', '6', 0, 0,
    /*  !--ACTION test  LABEL="Test" EVENT=test_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) test_event / 256), (byte) ((word)
    test_event & 255), 0, 14, 0, 0, 0, 0, 0, 't', 'e', 's', 't', 0, 'T',
    'e', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'c',
    /*  !--FIELD TEXTUAL 57 NAME=L_m ...  VALUE="Result of mapping:"         */
    0, 29, 10, 6, 1, 0, 18, 0, 18, '5', '7', 0, 'R', 'e', 's', 'u', 'l',
    't', 32, 'o', 'f', 32, 'm', 'a', 'p', 'p', 'i', 'n', 'g', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 170,
    /*  !--FIELD TEXTUAL 58 NAME=mapped-uri SIZE=50 MAX=? VALUE=""           */
    0, 11, 10, 6, 1, 0, '2', 0, '2', '5', '8', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 236,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, '|',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 131,
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 160, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '?',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 160, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm03_fields [] = {
    { 0, 98, 80 },                      /*  message_to_user                 */
    { 82, 755, 4 },                     /*  main_config                     */
    { 88, 784, 4 },                     /*  on_unix                         */
    { 94, 809, 4 },                     /*  on_windows_32                   */
    { 100, 907, 18 },                   /*  L_ipaddress                     */
    { 120, 980, 3 },                    /*  ipaddress                       */
    { 125, 1023, 13 },                  /*  L_portbase                      */
    { 140, 1055, 4 },                   /*  portbase                        */
    { 146, 1074, 25 },                  /*  L_portbase1                     */
    { 173, 1112, 4 },                   /*  portbase1                       */
    { 179, 1131, 4 },                   /*  portbase2                       */
    { 185, 1150, 4 },                   /*  portbase3                       */
    { 191, 1169, 4 },                   /*  portbase4                       */
    { 197, 1188, 4 },                   /*  portbase5                       */
    { 203, 1219, 22 },                  /*  L_base-host                     */
    { 227, 1260, 40 },                  /*  base-host                       */
    { 269, 1285, 20 },                  /*  L_webpages                      */
    { 291, 1324, 100 },                 /*  webpages                        */
    { 393, 1349, 14 },                  /*  L_cgi-bin                       */
    { 409, 1382, 100 },                 /*  cgi-bin                         */
    { 511, 1407, 20 },                  /*  L_cgi-url                       */
    { 533, 1446, 40 },                  /*  cgi-url                         */
    { 575, 1478, 20 },                  /*  L_refresh                       */
    { 597, 1517, 4 },                   /*  refresh                         */
    { 603, 1558, 18 },                  /*  L_debug                         */
    { 623, 1595, 1 },                   /*  debug                           */
    { 626, 1657, 22 },                  /*  L_limit                         */
    { 650, 1698, 4 },                   /*  limit                           */
    { 656, 1745, 18 },                  /*  L_background                    */
    { 676, 1782, 1 },                   /*  background                      */
    { 679, 1818, 27 },                  /*  L_autostart                     */
    { 708, 1864, 1 },                   /*  autostart                       */
    { 711, 1893, 32 },                  /*  L_translate                     */
    { 745, 1944, 1 },                   /*  translate                       */
    { 748, 2002, 29 },                  /*  L_hostname                      */
    { 779, 2050, 80 },                  /*  hostname                        */
    { 861, 2140, 23 },                  /*  L_keep-alive                    */
    { 886, 2182, 1 },                   /*  keep-alive                      */
    { 889, 2199, 24 },                  /*  L_keep-alive-max                */
    { 915, 2236, 4 },                   /*  keep-alive-max                  */
    { 921, 2266, 24 },                  /*  L_timeout                       */
    { 947, 2303, 4 },                   /*  timeout                         */
    { 953, 2352, 18 },                  /*  L_default1                      */
    { 973, 2389, 40 },                  /*  default1                        */
    { 1015, 2402, 17 },                 /*  L_default2                      */
    { 1034, 2432, 40 },                 /*  default2                        */
    { 1076, 2445, 40 },                 /*  default3                        */
    { 1118, 2458, 40 },                 /*  default4                        */
    { 1160, 2495, 22 },                 /*  L_noname1                       */
    { 1184, 2700, 17 },                 /*  L_test-uri                      */
    { 1203, 2736, 50 },                 /*  test-uri                        */
    { 1255, 2784, 18 },                 /*  L_mapped-uri                    */
    { 1275, 2821, 50 },                 /*  mapped-uri                      */
    { 1327, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   main_config_a        ;
    char   main_config          [4 + 1];
    byte   on_unix_a            ;
    char   on_unix              [4 + 1];
    byte   on_windows_32_a      ;
    char   on_windows_32        [4 + 1];
    byte   l_ipaddress_a        ;
    char   l_ipaddress          [18 + 1];
    byte   ipaddress_a          ;
    char   ipaddress            [3 + 1];
    byte   l_portbase_a         ;
    char   l_portbase           [13 + 1];
    byte   portbase_a           ;
    char   portbase             [4 + 1];
    byte   l_portbase1_a        ;
    char   l_portbase1          [25 + 1];
    byte   portbase1_a          ;
    char   portbase1            [4 + 1];
    byte   portbase2_a          ;
    char   portbase2            [4 + 1];
    byte   portbase3_a          ;
    char   portbase3            [4 + 1];
    byte   portbase4_a          ;
    char   portbase4            [4 + 1];
    byte   portbase5_a          ;
    char   portbase5            [4 + 1];
    byte   l_base_host_a        ;
    char   l_base_host          [22 + 1];
    byte   base_host_a          ;
    char   base_host            [40 + 1];
    byte   l_webpages_a         ;
    char   l_webpages           [20 + 1];
    byte   webpages_a           ;
    char   webpages             [100 + 1];
    byte   l_cgi_bin_a          ;
    char   l_cgi_bin            [14 + 1];
    byte   cgi_bin_a            ;
    char   cgi_bin              [100 + 1];
    byte   l_cgi_url_a          ;
    char   l_cgi_url            [20 + 1];
    byte   cgi_url_a            ;
    char   cgi_url              [40 + 1];
    byte   l_refresh_a          ;
    char   l_refresh            [20 + 1];
    byte   refresh_a            ;
    char   refresh              [4 + 1];
    byte   l_debug_a            ;
    char   l_debug              [18 + 1];
    byte   debug_a              ;
    char   debug                [1 + 1];
    byte   l_limit_a            ;
    char   l_limit              [22 + 1];
    byte   limit_a              ;
    char   limit                [4 + 1];
    byte   l_background_a       ;
    char   l_background         [18 + 1];
    byte   background_a         ;
    char   background           [1 + 1];
    byte   l_autostart_a        ;
    char   l_autostart          [27 + 1];
    byte   autostart_a          ;
    char   autostart            [1 + 1];
    byte   l_translate_a        ;
    char   l_translate          [32 + 1];
    byte   translate_a          ;
    char   translate            [1 + 1];
    byte   l_hostname_a         ;
    char   l_hostname           [29 + 1];
    byte   hostname_a           ;
    char   hostname             [80 + 1];
    byte   l_keep_alive_a       ;
    char   l_keep_alive         [23 + 1];
    byte   keep_alive_a         ;
    char   keep_alive           [1 + 1];
    byte   l_keep_alive_max_a   ;
    char   l_keep_alive_max     [24 + 1];
    byte   keep_alive_max_a     ;
    char   keep_alive_max       [4 + 1];
    byte   l_timeout_a          ;
    char   l_timeout            [24 + 1];
    byte   timeout_a            ;
    char   timeout              [4 + 1];
    byte   l_default1_a         ;
    char   l_default1           [18 + 1];
    byte   default1_a           ;
    char   default1             [40 + 1];
    byte   l_default2_a         ;
    char   l_default2           [17 + 1];
    byte   default2_a           ;
    char   default2             [40 + 1];
    byte   default3_a           ;
    char   default3             [40 + 1];
    byte   default4_a           ;
    char   default4             [40 + 1];
    byte   l_noname1_a          ;
    char   l_noname1            [22 + 1];
    byte   l_test_uri_a         ;
    char   l_test_uri           [17 + 1];
    byte   test_uri_a           ;
    char   test_uri             [50 + 1];
    byte   l_mapped_uri_a       ;
    char   l_mapped_uri         [18 + 1];
    byte   mapped_uri_a         ;
    char   mapped_uri           [50 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   aliases_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   logging_a;
    byte   ftp_a;
    byte   mime_a;
    byte   defaults_a;
    byte   undo_a;
    byte   errors_a;
    byte   wsx_a;
    byte   filters_a;
    byte   test_a;
    } XIADM03_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm03 = {
    xiadm03_blocks,
    xiadm03_fields,
    168,                                /*  Number of blocks in form        */
    53,                                 /*  Number of fields in form        */
    15,                                 /*  Number of actions in form       */
    1327,                               /*  Size of fields                  */
    "xiadm03",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
