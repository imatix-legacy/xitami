/*---------------------------------------------------------------------------
 *  xiadm12.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM12__
#define __FORM_XIADM12__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define RESOURCE_LIST_MAX                   10
#define XIADM12_MESSAGE_TO_USER             0
#define XIADM12_L_URI_NAME                  1
#define XIADM12_L_URI_PATH                  2
#define XIADM12_L_WEBMASK                   3
#define XIADM12_L_URI_USERS                 4
#define XIADM12_URI_NAME                    5
#define XIADM12_URI_PATH                    6
#define XIADM12_WEBMASK                     7
#define XIADM12_URI_USERS                   8
#define XIADM12_L_NEW_URI                   9
#define XIADM12_NEW_URI                     10
#define XIADM12_RESOURCE_LIST               11

/*  This table contains each block in the form                               */

static byte xiadm12_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) ... ed URIs</TITLE></HEAD><BODY>        */
    0, 67, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'P', 'r', 'o', 't', 'e', 'c', 't',
    'e', 'd', 32, 'U', 'R', 'I', 's', '<', '/', 'T', 'I', 'T', 'L', 'E',
    '>', '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D', 'Y',
    '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - Protected URIs                                           */
    0, 27, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'P', 'r', 'o', 't', 'e', 'c', 't', 'e', 'd', 32, 'U', 'R', 'I', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 47, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>',
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 20, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP BORDER=1 WIDTH=75% >                                   */
    0, 35, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, 'B', 'O', 'R', 'D', 'E', 'R', '=', '1', 32, 'W', 'I', 'D',
    'T', 'H', '=', '7', '5', '%', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 172 NAME=L_ ... VALUE="URI or partial URI:"         */
    0, 31, 10, 6, 1, 0, 19, 0, 19, '1', '7', '2', 0, 'U', 'R', 'I', 32,
    'o', 'r', 32, 'p', 'a', 'r', 't', 'i', 'a', 'l', 32, 'U', 'R', 'I',
    ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 'L',
    /*  !--FIELD TEXTUAL 173 NAME=L_uri-path VALUE="Translated path:"        */
    0, 28, 10, 6, 1, 0, 16, 0, 16, '1', '7', '3', 0, 'T', 'r', 'a', 'n',
    's', 'l', 'a', 't', 'e', 'd', 32, 'p', 'a', 't', 'h', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 140,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 'L',
    /*  !--FIELD TEXTUAL 174 NAME=L_webmask VALUE="IP address mask:"         */
    0, 28, 10, 6, 1, 0, 16, 0, 16, '1', '7', '4', 0, 'I', 'P', 32, 'a',
    'd', 'd', 'r', 'e', 's', 's', 32, 'm', 'a', 's', 'k', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 140,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 'L',
    /*  !--FIELD TEXTUAL 175 NAME=L_uri-users VALUE="Users:"                 */
    0, 18, 10, 6, 1, 0, 6, 0, 6, '1', '7', '5', 0, 'U', 's', 'e', 'r',
    's', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 140,
    /*  !--REPEAT resource_list  ROWS=10                                     */
    0, 7, 4, 0, 11, 0, 15, 0, 10,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 'E',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 176 NAME=uri-name SIZE=40 MAX=80 VALUE=""           */
    0, 12, 10, 10, 10, 0, '(', 0, 'P', '1', '7', '6', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 31,
    /*  !--FIELD TEXTUAL 177 NAME=uri-path SIZE=60 MAX=? VALUE=""            */
    0, 12, 10, 6, 10, 0, '<', 0, '<', '1', '7', '7', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'L',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 31,
    /*  !--FIELD TEXTUAL 178 NAME=webmask SIZE=40 MAX=80 VALUE=""            */
    0, 12, 10, 0, 10, 0, '(', 0, 'P', '1', '7', '8', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'L',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 31,
    /*  !--FIELD NUMERIC 179 NAME=ur ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 18, 11, 6, 10, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, '1', '7', '9', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'L',
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 17,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'l',
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 180 NAME=L_ ... UE="Add new protected URI:"         */
    0, 34, 10, 6, 1, 0, 22, 0, 22, '1', '8', '0', 0, 'A', 'd', 'd', 32,
    'n', 'e', 'w', 32, 'p', 'r', 'o', 't', 'e', 'c', 't', 'e', 'd', 32,
    'U', 'R', 'I', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--FIELD TEXTUAL 181 NAME=new-uri SIZE=40 MAX=? VALUE=""             */
    0, 12, 10, 0, 1, 0, '(', 0, '(', '1', '8', '1', 0, 0,
    /*  !--ACTION define  LABEL="Def ... NT=define_event TYPE=BUTTON         */
    0, 28, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 2, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'i', 'n',
    'e', 0, 'D', 'e', 'f', 'i', 'n', 'e', '.', '.', '.', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'l',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 3, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 4, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't', 0,
    'F', 'i', 'r', 's', 't', 0,
    /*  !--FIELD NUMERIC resource_list SIZE=4 VALUE=10                       */
    0, 30, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'r', 'e', 's', 'o',
    'u', 'r', 'c', 'e', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 'y',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 128,
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 157, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '<',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 157, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'l',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm12_fields [] = {
    { 0, 95, 80 },                      /*  message_to_user                 */
    { 82, 619, 19 },                    /*  L_uri-name                      */
    { 103, 666, 16 },                   /*  L_uri-path                      */
    { 121, 708, 16 },                   /*  L_webmask                       */
    { 139, 750, 6 },                    /*  L_uri-users                     */
    { 147, 830, 80 },                   /*  uri-name                        */
    { 967, 858, 60 },                   /*  uri-path                        */
    { 1587, 884, 80 },                  /*  webmask                         */
    { 2407, 910, 5 },                   /*  uri-users                       */
    { 2477, 1008, 22 },                 /*  L_new-uri                       */
    { 2501, 1086, 40 },                 /*  new-uri                         */
    { 2543, 1206, 4 },                  /*  resource_list                   */
    { 2549, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_uri_name_a         ;
    char   l_uri_name           [19 + 1];
    byte   l_uri_path_a         ;
    char   l_uri_path           [16 + 1];
    byte   l_webmask_a          ;
    char   l_webmask            [16 + 1];
    byte   l_uri_users_a        ;
    char   l_uri_users          [6 + 1];
    byte   uri_name_a           [10] ;
    char   uri_name             [10] [80 + 1];
    byte   uri_path_a           [10] ;
    char   uri_path             [10] [60 + 1];
    byte   webmask_a            [10] ;
    char   webmask              [10] [80 + 1];
    byte   uri_users_a          [10] ;
    char   uri_users            [10] [5 + 1];
    byte   l_new_uri_a          ;
    char   l_new_uri            [22 + 1];
    byte   new_uri_a            ;
    char   new_uri              [40 + 1];
    byte   resource_list_a      ;
    char   resource_list        [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   define_a;
    byte   more_a;
    byte   first_a;
    } XIADM12_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm12 = {
    xiadm12_blocks,
    xiadm12_fields,
    69,                                 /*  Number of blocks in form        */
    12,                                 /*  Number of fields in form        */
    5,                                  /*  Number of actions in form       */
    2549,                               /*  Size of fields                  */
    "xiadm12",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
