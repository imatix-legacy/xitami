/*  --------------------------- N O T I C E ------------------------------
    This file has been stripped of symbolic information in order to protect
    trade secrets and protected and/or confidential source code.  This file
    remains Copyright (c) 1997 iMatix and is subject to the following terms
    and conditions in addition to the license terms agreed-on between the
    user and iMatix:
    1.  All reverse-engineering, reconstruction, or partial reuse of this
        source code is forbidden.
    2.  Any modification of this source code will consitute a violation of
        the license and guarantee terms agreed between the user and iMatix.
    3.  Distribution of this source code is allowed only according to the
        terms of the respective product license agreement.
    ---------------------------------------------------------------------- */
#include "sfl.h"
#include "formio.h"
char
*form_strerror;
RANGE
range_all = { 0, -1 },
range_none = { -1, 0 };
static FORM_ITEM
*_2638;
static SYMTAB
*_2639;
static char
*_2640 = "<TABLE><TR><TD BGCOLOR=\"#FF0000\">&gt;",
*_2641 = "&lt;</TABLE>";
static FORM_ITEM *_2642 (FORM_DEFN *defn);
static char *_2643 (byte *_2644);
static void _2645 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2647 (VDESCR *buffer, char *source, int size);
static void _2648 (VDESCR *buffer, char *source);
static void _2649 (VDESCR *buffer, char *format, ...);
static void _2650 (VDESCR *buffer, byte *block);
static void _2651 (VDESCR *buffer, byte *block);
static void _2652 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2653 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2654 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2655 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2656 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2657 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2658 (VDESCR *buffer, byte *block, int field, int _2646);
static void _2659 (VDESCR *buffer, byte *block);
static void _2660 (VDESCR *buffer, char *value, int field, int _2646);
static Bool _2661 (int field);
static Bool _2662 (int field, int index);
static Bool _2663 (RANGE *range, int field);
static byte *_2664 (int field, int index);
static char *_2665 (int field, int index);
static char *_2666 (byte *block, int index);
static void _2667 (byte *block, int *flags, int *_2668, int *_2669,
int *width);
static int _2670 (byte *block, int field, int index, char *value);
static void _2671 (int field, int index);
static int _2672 (byte *block, int field, int index, char *value);
static int _2673 (byte *block, int field, int index, char *value);
static void _2674 (SYMTAB *symtab, byte *block);
static Bool _2675 (char *value);
static char *_2676 (int field, int index, int _2677, char _2678);
static char *_2679 (int field, int index, int _2677, char _2678);
static Bool _2680 (FORM_ITEM *form, byte *_2644,
int _2681, va_list _2682);
static Bool _2683 (FORM_ITEM *form, byte *_2644,
int _2681, va_list _2682);
static Bool _2684 (FORM_ITEM *form, byte *_2644,
int _2681, va_list _2682);
static Bool _2685 (FORM_ITEM *form, byte *_2644,
int _2681, va_list _2682);
static Bool _2686 (SYMBOL *symbol, ...);
#define _2687(b) ((b) [0] << 8) + ((b) [1])
#define _2688(b) ((b) [2])
#define _2689(b) ((b) [3])
#define _2690(b) ((b) [4])
#define _2691(b) ((char *) ((b) + 3))
#define _2692(b) ((b) [3])
#define _2693(b) ((b) [4] << 8) + ((b) [5])
#define _2694(b) ((b) [6] << 8) + ((b) [7])
#define _2695(b) ((b) [3] << 8) + ((b) [4])
#define _2696(b) ((b) [5] << 8) + ((b) [6])
#define _2697(b) ((b) [3] << 8) + ((b) [4])
#define _2698(b) ((b) [5] << 8) + ((b) [6])
#define _2699(b) ((b) [3] << 8) + ((b) [4])
#define _2700(b) ((b) [5] << 8) + ((b) [6])
#define _2701(b) ((b) [7] << 8) + ((b) [8])
#define _2702(b) ((b) [3])
#define _2703(b) ((b) [4])
#define _2704(b) ((b) [5] << 8) + ((b) [6])
#define _2705(b) ((b) [7] << 8) + ((b) [8])
#define _2706(b) ((char *) ((b) + 9))
#define _2707(b) (_2706 (b) + strlen (_2706 (b)) + 1)
#define _2708(b) ((b) [3])
#define _2709(b) ((b) [4])
#define _2710(b) ((b) [5] << 8) + ((b) [6])
#define _2711(b) ((b) [7] << 8) + ((b) [8])
#define _2712(b) ((b) [9])
#define _2713(b) ((b) [10])
#define _2714(b) ((b) [11])
#define _2715(b) ((b) [12])
#define _2716(b) ((b) [13])
#define _2717(b) ((b) [14])
#define _2718(b) ((char *) ((b) + 15))
#define _2719(b) (_2718 (b) + strlen (_2718 (b)) + 1)
#define _2720(b) ((b) [3])
#define _2721(b) ((b) [4])
#define _2722(b) ((b) [5] << 8) + ((b) [6])
#define _2723(b) ((b) [7])
#define _2724(b) ((b) [8])
#define _2725(b) ((b) [9])
#define _2726(b) ((b) [10])
#define _2727(b) ((b) [11])
#define _2728(b) (char *) ((b) + 12)
#define _2729(b) (_2728 (b) + strlen (_2728 (b)) + 1)
#define _2730(b) (_2729 (b) + strlen (_2729 (b)) + 1)
#define _2731(b) ((b) [3])
#define _2732(b) ((b) [4])
#define _2733(b) ((b) [5])
#define _2734(b) ((b) [6])
#define _2735(b) ((b) [7] << 8) + ((b) [8])
#define _2736(b) ((char *) ((b) + 9))
#define _2737(b) (_2736 (b) + strlen (_2736 (b)) + 1)
#define _2738(b) ((b) [3])
#define _2739(b) ((b) [4])
#define _2740(b) ((char *) ((b) + 5))
#define _2741(b) (_2740 (b) + strlen (_2740 (b)) + 1)
#define _2742(b) (_2741 (b) + strlen (_2741 (b)) + 1)
#define _2743(b) (_2742 (b) + strlen (_2742 (b)) + 1)
#define _2744(b) ((b) [3])
#define _2745(b) ((b) [4])
#define _2746(b) ((b) [5])
#define _2747(b) ((b) [6])
#define _2748(b) ((char *) ((b) + 7))
#define _2749(b) (_2748 (b) + strlen (_2748 (b)) + 1)
#define _2750(b) (_2749 (b) + strlen (_2749 (b)) + 1)
#define _2751(b) (_2750 (b) + strlen (_2750 (b)) + 1)
#define _2752(b) ((b) [3])
#define _2753(b) ((b) [4])
#define _2754(b) ((b) [5])
#define _2755(b) ((b) [6])
#define _2756(b) ((char *) ((b) + 7))
#define _2757(b) (_2756 (b) + strlen (_2756 (b)) + 1)
#define _2758(b) (_2757 (b) + strlen (_2757 (b)) + 1)
#define _2759(b) ((b) [3] << 8) + ((b) [4])
#define _2760(b) ((b) [5])
#define _2761(b) ((char *) ((b) + 6))
#define _2762(b) ((b) [3])
#define _2763(b) ((b) [4] << 8) + ((b) [5])
#define _2764(b) ((b) [6] << 8) + ((b) [7])
#define _2765(b) ((b) [8])
#define _2766(b) ((b) [9] << 8) + ((b) [10])
#define _2767(b) ((b) [11] << 8) + ((b) [12])
#define _2768(b) ((char *) ((b) + 13))
#define _2769(b) (_2768 (b) + strlen (_2768 (b)) + 1)
#define _2770(t) ((t) == BLOCK_TEXTUAL || \
(t) == BLOCK_NUMERIC || \
(t) == BLOCK_DATE || \
(t) == BLOCK_TEXTBOX || \
(t) == BLOCK_BOOLEAN || \
(t) == BLOCK_SELECT || \
(t) == BLOCK_RADIO )
#define _2771(f) ((char *) _2638-> data + \
_2638-> defn-> fields [f].data)
#define _2772(f) (_2638-> defn-> blocks + \
_2638-> defn-> fields [f].block)
#define _2773(f) (_2638-> defn-> fields [f].max)
#define _2774(b) (_2638-> data + \
_2638-> defn-> fields_size + _2764 (b))
typedef struct {
char *input;
char *output;
int _2775;
int _2776;
} _2777;
static _2777 _2778 [] = {
{ "TEXT", "%s",                 0, 0},
{ "TEXT", "%s",                 1, 0},
{ "PASSWORD", "",               0, 0},
{  NULL,  "%s",                 0, 0},
{ "HIDDEN", "",                 0, 1},
{  NULL,  "",                   0, 1},
{  NULL, "%s",                  0, 0},
{  NULL, "<EM>%s</EM>",         0, 0},
{  NULL, "<STRONG>%s</STRONG>", 0, 0},
{  NULL, "<BIG>%s</BIG>",       0, 0},
{  NULL, "%s",                  0, 0}
};
FORM_ITEM *
form_init (
FORM_DEFN *defn,
Bool values)
{
FORM_ITEM
*form;
ASSERT (defn);
if ((form = _2642 (defn)) == NULL)
return (NULL);
if (values)
{
form-> language = FLANG_ENGLISH;
form-> date_order = DATE_ORDER_DMY;
form-> date_sep = '/';
form-> dec_point = '.';
form-> input_range = range_all;
form-> blank_range = range_none;
form_use (form);
form_exec (form, _2680);
}
return (form);
}
static FORM_ITEM *
_2642 (
FORM_DEFN *defn)
{
FORM_ITEM
*form;
MEMTRN
*_2779;
ASSERT (defn);
_2779 = mem_new_trans ();
if ((form = mem_alloc (sizeof (FORM_ITEM))) == NULL)
return (NULL);
memset (form, 0, sizeof (FORM_ITEM));
form-> defn = defn;
form-> data_size = defn-> fields_size + defn-> action_count;
form-> data = mem_alloc (form-> data_size);
if (form-> data == NULL)
{
mem_rollback (_2779);
return (NULL);
}
memset (form-> data, 0, form-> data_size);
mem_commit (_2779);
return (form);
}
static Bool
_2680 (
FORM_ITEM *form,
byte *_2644,
int _2681,
va_list _2682)
{
byte
_2780,
_2781;
char
*_2782,
*_2783;
int
_2784;
if (_2770 (_2688 (_2644)))
{
_2780 = _2690 (_2644);
_2781 = _2689 (_2644);
_2783 = _2643 (_2644);
_2782 = _2771 (_2681);
for (_2784 = 0; _2784 < _2780; _2784++)
*_2782++ = _2781;
ASSERT (strlen (_2783) <= _2773 (_2681));
for (_2784 = 0; _2784 < _2780; _2784++)
{
strcpy ((char *) _2782, _2783);
_2782 += _2773 (_2681) + 1;
}
}
else
if (_2688 (_2644) == BLOCK_ACTION)
*_2774 (_2644) = _2765 (_2644);
return (TRUE);
}
static char *
_2643 (byte *_2644)
{
switch (_2688 (_2644))
{
case BLOCK_TEXTUAL: return (_2707 (_2644));
case BLOCK_NUMERIC: return (_2719 (_2644));
case BLOCK_DATE: return (_2729 (_2644));
case BLOCK_TEXTBOX: return (_2737 (_2644));
case BLOCK_BOOLEAN: return (_2741 (_2644));
case BLOCK_SELECT: return (_2749 (_2644));
case BLOCK_RADIO: return (_2757 (_2644));
}
return (NULL);
}
void
form_term (
FORM_ITEM *form)
{
if (form)
{
if (form-> list_values)
sym_delete_table (form-> list_values);
mem_free (form-> data);
mem_free (form);
}
}
void
form_use (
FORM_ITEM *form)
{
ASSERT (form);
_2638 = form;
}
size_t
form_put (
FORM_ITEM *form,
VDESCR *buffer,
SYMTAB *symtab)
{
byte
*_2644,
_2785,
*_2786;
int
_2681,
_2787,
_2788,
_2789,
_2790,
_2791,
_2792;
ASSERT (form);
ASSERT (buffer);
ASSERT (symtab);
buffer-> cur_size = 0;
buffer-> data = buffer-> data;
form-> status = FSTATUS_OK;
_2681 = -1;
_2788 = 0;
_2787 = 0;
_2644 = form-> defn-> blocks;
_2638 = form;
_2639 = symtab;
while (_2787 < form-> defn-> block_count)
{
_2785 = _2688 (_2644);
if (_2770 (_2785))
_2681++;
if (_2788 > 0)
_2788--;
else
if (_2785 == BLOCK_IF)
{
if (_2675 (_2665 (_2695 (_2644), 0)))
_2788 = _2696 (_2644);
}
else
if (_2785 == BLOCK_UNLESS)
{
if (!_2675 (_2665 (_2697 (_2644), 0)))
_2788 = _2698 (_2644);
}
else
if (_2785 == BLOCK_REPEAT)
{
_2789 = atoi (_2665 (_2699 (_2644), 0));
for (_2790 = 0; _2790 < _2789; _2790++)
{
_2791 = _2681;
_2786 = _2644;
for (_2792 = 0;
_2792 < _2700 (_2644);
_2792++)
{
_2786 += _2687 (_2786) + 2;
if (_2770 (_2688 (_2786)))
_2791++;
_2645 (buffer, _2786, _2791,
_2790);
}
}
_2788 = _2700 (_2644);
}
else
if (!_2661 (_2681))
_2645 (buffer, _2644, _2681, 0);
_2644 += _2687 (_2644) + 2;
_2787++;
}
if (buffer-> cur_size >= buffer-> max_size)
buffer-> cur_size = buffer-> max_size - 1;
buffer-> data [buffer-> cur_size] = '\0';
return (buffer-> cur_size);
}
static Bool
_2661 (int _2681)
{
return (_2663 (&_2638-> blank_range, _2681));
}
static Bool
_2663 (RANGE *range, int _2681)
{
if (range-> first == -1)
return (FALSE);
else
if (range-> last == -1)
return (TRUE);
else
return (range-> first <= _2681 &&
_2681 <= range-> last);
}
static void
_2645 (
VDESCR *stream,
byte *_2644,
int _2681,
int index)
{
switch (_2688 (_2644))
{
case BLOCK_PLAIN:
_2650 (stream, _2644);
break;
case BLOCK_COMPRESSED:
_2651 (stream, _2644);
break;
case BLOCK_TEXTUAL:
_2652 (stream, _2644, _2681, index);
break;
case BLOCK_NUMERIC:
_2653 (stream, _2644, _2681, index);
break;
case BLOCK_DATE:
_2654 (stream, _2644, _2681, index);
break;
case BLOCK_TEXTBOX:
_2655 (stream, _2644, _2681, index);
break;
case BLOCK_BOOLEAN:
_2656 (stream, _2644, _2681, index);
break;
case BLOCK_SELECT:
_2657 (stream, _2644, _2681, index);
break;
case BLOCK_RLABEL:
_2658 (stream, _2644, _2681, index);
break;
case BLOCK_ACTION:
_2659 (stream, _2644);
break;
}
}
static void
_2650 (VDESCR *stream, byte *_2644)
{
_2647 (stream, _2691 (_2644), _2687 (_2644) - 1);
_2648 (stream, "\n");
}
static void
_2647 (VDESCR *stream, char *source, int size)
{
static char
_2793 [FORMIO_SYMNAME_MAX + 1];
char
*_2794,
*_2795,
*_2796;
int
_2797;
while (size > 0 && (_2794 = memchr (source, '#', size)) != NULL)
{
if (_2794 > source)
{
_2647 (stream, source, (int) (_2794 - source));
size -= (int) (_2794 - source);
source = _2794;
}
_2795 = memchr (source, ')', size);
if (source [1] == '(' && _2795)
{
_2797 = (int) (_2795 - source - 2);
if (_2797 <= FORMIO_SYMNAME_MAX)
{
memcpy (_2793, source + 2, _2797);
_2793 [_2797] = '\0';
_2796 = sym_get_value (_2639, _2793, "(?)");
_2647 (stream, _2796, strlen (_2796));
}
else
_2647 (stream, source, (int) (_2795 - source) + 1);
size -= (int) (_2795 - source) + 1;
source = _2795 + 1;
}
else
{
if ((stream-> cur_size + 1) < stream-> max_size)
{
memcpy (stream-> data + stream-> cur_size, source, 1);
stream-> cur_size += 1;
}
size--;
source++;
}
}
if ((stream-> cur_size + size) < stream-> max_size)
{
memcpy (stream-> data + stream-> cur_size, source, size);
stream-> cur_size += size;
}
}
static void
_2648 (VDESCR *stream, char *source)
{
_2647 (stream, source, strlen (source));
}
static void
_2651 (VDESCR *stream, byte *_2644)
{
byte
*_2798;
word
block_size;
_2798 = _2693 (_2644) + _2638-> defn-> blocks;
if (_2692 (_2644) == COMPR_WHOLEDICT)
block_size = _2687 (_2798) - 1;
else
if (_2692 (_2644) == COMPR_PARTDICT)
block_size = _2694 (_2644);
else
abort ();
_2647 (stream, _2691 (_2798), block_size);
_2648 (stream, "\n");
}
static void
_2652 (VDESCR *stream, byte *_2644, int _2681, int index)
{
char
*value;
_2777
*_2799;
value = _2665 (_2681, index);
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> input && _2662 (_2681, index))
{
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream,
"<INPUT TYPE=%s NAME=%s SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_2799-> input,
_2666 (_2644, index),
_2704 (_2644),
_2705 (_2644),
value);
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, value, _2681, index);
else
if (!_2799-> _2776)
_2649 (stream, _2799-> output, *value? value: "&nbsp;");
}
static Bool
_2662 (int _2681, int index)
{
if (*_2664 (_2681, index) == FATTR_HIDDEN
|| _2663 (&_2638-> input_range, _2681))
return (TRUE);
else
return (FALSE);
}
static char *
_2666 (byte *_2644, int index)
{
static
char _2800 [LINE_MAX + 8];
switch (_2688 (_2644))
{
case BLOCK_TEXTUAL:
strncpy (_2800, _2706 (_2644), LINE_MAX);
break;
case BLOCK_NUMERIC:
strncpy (_2800, _2718 (_2644), LINE_MAX);
break;
case BLOCK_DATE:
strncpy (_2800, _2728 (_2644), LINE_MAX);
break;
case BLOCK_TEXTBOX:
strncpy (_2800, _2736 (_2644), LINE_MAX);
break;
case BLOCK_BOOLEAN:
strncpy (_2800, _2740 (_2644), LINE_MAX);
break;
case BLOCK_SELECT:
strncpy (_2800, _2748 (_2644), LINE_MAX);
break;
case BLOCK_RADIO:
strncpy (_2800, _2756 (_2644), LINE_MAX);
break;
default:
return (NULL);
}
if (index)
sprintf (_2800 + strlen (_2800), ".%d", index);
return (_2800);
}
static void
_2660 (VDESCR *stream, char *value, int _2681, int index)
{
if (strnull (value))
value = "&lt;Empty&gt;";
_2649 (stream, "<A HREF=\"#(uri)&~C%d.%d=1\">%s</A>\n",
_2681, index, value);
}
static byte *
_2664 (int _2681, int index)
{
ASSERT (_2681 < _2638-> defn-> field_count);
return (_2638-> data +
_2638-> defn-> fields [_2681].data + index);
}
static char *
_2665 (int _2681, int index)
{
ASSERT (_2681 < _2638-> defn-> field_count);
ASSERT (index < _2690 (_2772 (_2681)));
return (_2771 (_2681)
+ _2690 (_2772 (_2681))
+ (_2773 (_2681) + 1) * index);
}
static Bool
_2675 (char *value)
{
while (*value == '0')
value++;
return (*value == '\0');
}
static void
_2649 (VDESCR *stream, char *format, ...)
{
static char
_2801 [LINE_MAX];
va_list
_2682;
va_start (_2682, format);
vsprintf (_2801, format, _2682);
va_end (_2682);
_2647 (stream, _2801, strlen (_2801));
}
static void
_2653 (VDESCR *stream, byte *_2644, int _2681, int index)
{
_2777
*_2799;
char
*value;
int
_2802,
sign_format,
_2803,
_2804;
_2667 (
_2644,
&_2802,
&sign_format,
&_2803,
&_2804);
value = conv_number_str (
_2665 (_2681, index),
_2802,
_2638-> dec_point,
_2712 (_2644),
_2803,
_2804,
sign_format);
if (value == NULL)
value = conv_reason_text [conv_reason];
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> input && _2662 (_2681, index))
{
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream,
"<INPUT TYPE=%s NAME=%s SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_2799-> input,
_2666 (_2644, index),
_2710 (_2644),
_2711 (_2644),
value);
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, value, _2681, index);
else
if (!_2799-> _2776)
_2649 (stream, _2799-> output, *value? value: "&nbsp;");
}
static void
_2667 (byte *_2644, int *flags, int *_2668, int *_2669, int *width)
{
*flags = 0;
switch (_2713 (_2644))
{
case FSIGN_NONE:
*_2668 = 0;
break;
case FSIGN_POST:
*flags += FLAG_N_SIGNED;
*_2668 = SIGN_NEG_TRAIL;
break;
case FSIGN_PRE:
*flags += FLAG_N_SIGNED;
*_2668 = SIGN_NEG_LEAD;
break;
case FSIGN_POSTPLUS:
*flags += FLAG_N_SIGNED;
*_2668 = SIGN_ALL_TRAIL;
break;
case FSIGN_PREPLUS:
*flags += FLAG_N_SIGNED;
*_2668 = SIGN_ALL_LEAD;
break;
case FSIGN_FINANCIAL:
*flags += FLAG_N_SIGNED;
*_2668 = SIGN_FINANCIAL;
break;
}
switch (_2714 (_2644))
{
case FDECFMT_NONE:
*_2669 = 0;
break;
case FDECFMT_ALL:
*flags += FLAG_N_DECIMALS;
*_2669 = DECS_SHOW_ALL;
break;
case FDECFMT_DROP:
*flags += FLAG_N_DECIMALS;
*_2669 = DECS_DROP_ZEROS;
break;
}
switch (_2715 (_2644))
{
case FFILL_NONE:
*width = 0;
break;
case FFILL_SPACE:
*width = _2710 (_2644);
break;
case FFILL_ZERO:
*width = _2710 (_2644);
*flags += FLAG_N_ZERO_FILL;
break;
}
if (_2716 (_2644))
*flags += FLAG_N_ZERO_BLANK;
if (_2717 (_2644))
*flags += FLAG_N_THOUSANDS;
}
static void
_2654 (VDESCR *stream, byte *_2644, int _2681, int index)
{
char
*picture;
int
flags,
format;
long
_2805;
char
*value;
_2777
*_2799;
_2805 = atol (_2665 (_2681, index));
picture = _2730 (_2644);
if (strused (picture))
value = conv_date_pict (_2805, picture);
else
{
if (_2723 (_2644) == FSHOW_YMD)
if (_2724 (_2644) == FFORMAT_COMPACT)
format = DATE_YMD_COMPACT;
else
if (_2724 (_2644) == FFORMAT_SLASH)
format = DATE_YMD_DELIM;
else
if (_2724 (_2644) == FFORMAT_SPACE)
format = DATE_YMD_SPACE;
else
if (_2724 (_2644) == FFORMAT_COMMA)
format = DATE_YMD_COMMA;
else
format = DATE_YMD_COMPACT;
else
if (_2723 (_2644) == FSHOW_YM)
if (_2724 (_2644) == FFORMAT_COMPACT)
format = DATE_YM_COMPACT;
else
if (_2724 (_2644) == FFORMAT_SLASH)
format = DATE_YM_DELIM;
else
if (_2724 (_2644) == FFORMAT_SPACE)
format = DATE_YM_SPACE;
else
format = DATE_YM_COMPACT;
else
if (_2723 (_2644) == FSHOW_MD)
if (_2724 (_2644) == FFORMAT_COMPACT)
format = DATE_MD_COMPACT;
else
if (_2724 (_2644) == FFORMAT_SLASH)
format = DATE_MD_DELIM;
else
if (_2724 (_2644) == FFORMAT_SPACE)
format = DATE_MD_SPACE;
else
format = DATE_MD_COMPACT;
else
format = DATE_YMD_COMPACT;
flags = 0;
if (_2725(_2644) == FYEAR_FULL)
flags += FLAG_D_CENTURY;
if (_2726 (_2644) == FMONTH_COUNTER)
flags += FLAG_D_MM_AS_M;
else
if (_2726 (_2644) == FMONTH_ALPHA)
flags += FLAG_D_MONTH_ABC;
else
if (_2726 (_2644) == FMONTH_UPPER)
flags += FLAG_D_UPPER;
if (_2727 (_2644) == FDAY_COUNTER)
flags += FLAG_D_DD_AS_D;
value = conv_date_str (_2805, flags, format,
_2638-> date_order,
_2638-> date_sep,
_2722 (_2644));
}
if (value == NULL)
value = conv_reason_text [conv_reason];
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> input && _2662 (_2681, index))
{
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream,
"<INPUT TYPE=%s NAME=%s SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_2799-> input,
_2666 (_2644, index),
_2722 (_2644),
_2722 (_2644),
value);
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, value, _2681, index);
else
if (!_2799-> _2776)
_2649 (stream, _2799-> output, *value? value: "&nbsp;");
}
static void
_2655 (VDESCR *stream, byte *_2644, int _2681, int index)
{
_2777
*_2799;
char
*_2806,
*value;
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> _2776)
;
else
if (_2799-> input && _2662 (_2681, index))
{
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream,
"<TEXTAREA NAME=%s ROWS=%d COLS=%d MAXLENGTH=%d WRAP=\"VIRTUAL\">",
_2666 (_2644, index),
_2733 (_2644),
_2734 (_2644),
_2735 (_2644));
value = _2665 (_2681, index);
while (*value)
{
if (*value == '<')
_2648 (stream, "&lt;");
else
if (*value == '>')
_2648 (stream, "&gt;");
else
_2647 (stream, value, 1);
value++;
}
_2648 (stream, "</TEXTAREA>\n");
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, _2665 (_2681, index), _2681, index);
else
{
_2806 = _2799-> output;
while (*_2806)
{
if (*_2806 == '%')
{
_2806 += 2;
break;
}
_2647 (stream, _2806, 1);
_2806++;
}
value = _2665 (_2681, index);
if (*value)
while (*value)
{
if (*value == '\n')
_2648 (stream, "<BR>");
else
_2647 (stream, value, 1);
value++;
}
else
_2648 (stream, "&nbsp;");
while (*_2806)
_2647 (stream, _2806++, 1);
}
}
static void
_2656 (VDESCR *stream, byte *_2644, int _2681, int index)
{
_2777
*_2799;
char
*value;
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> _2776)
;
else
if (_2799-> input && _2662 (_2681, index))
{
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream,
"<INPUT TYPE=CHECKBOX %sNAME=%s>\n",
_2665 (_2681, index) [0] == '1'? "CHECKED ": "",
_2666 (_2644, index));
strcpy (_2665 (_2681, index), "0");
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
{
value = _2665 (_2681, index) [0] == '1'?
_2742 (_2644): _2743 (_2644);
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, value, _2681, index);
else
_2649 (stream, _2799-> output, *value? value: "&nbsp;");
}
}
static void
_2657 (VDESCR *stream, byte *_2644, int _2681, int index)
{
_2777
*_2799;
int
_2807,
_2808,
_2809;
char
*value,
*_2810;
_2809 = atoi (_2665 (_2681, index));
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> _2776)
;
else
if (_2799-> input && _2662 (_2681, index))
{
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream, "<SELECT NAME=%s SIZE=%d>\n",
_2666 (_2644, index),
_2746 (_2644));
_2649 (stream, "<OPTION VALUE=\"0\"%s>%s\n",
_2809 == 0? " SELECTED": "",
_2750 (_2644));
if (_2747 (_2644) == 0)
{
_2808 = fxlist_size (_2681, index);
for (_2807 = 1; _2807 <= _2808; _2807++)
_2649 (stream, "<OPTION VALUE=\"%d\"%s>%s\n", _2807,
_2807 == _2809? " SELECTED": "",
_2676 (_2681, index, _2807, 'v'));
}
else
{
_2810 = _2751 (_2644);
for (_2807 = 1; _2807 <= _2747 (_2644); _2807++)
{
_2649 (stream, "<OPTION VALUE=\"%d\"%s>%s\n", _2807,
_2807 == _2809? " SELECTED": "",
_2810);
_2810 += strlen (_2810) + 1;
}
}
_2648 (stream, "</SELECT>\n");
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
if (_2809 == 0)
_2649 (stream, _2799-> output, _2750 (_2644));
else
{
if (_2747 (_2644) == 0)
value = _2676 (_2681, index, _2809, 'v');
else
{
_2810 = _2750 (_2644);
for (_2807 = 0; _2807 < _2809; _2807++)
_2810 += strlen (_2810) + 1;
value = _2810;
}
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, value, _2681, index);
else
_2649 (stream, _2799-> output, *value? value: "&nbsp;");
}
}
static void
_2658 (VDESCR *stream, byte *_2644, int _2681, int index)
{
_2777
*_2799;
int
_2811;
byte
*_2812;
char
*value;
_2811 = atoi (_2665 (_2681, index));
_2812 = _2638-> defn-> blocks + _2759 (_2644);
_2799 = &_2778 [*_2664 (_2681, index)];
if (_2799-> _2776)
;
else
if (_2799-> input && _2662 (_2681, index))
{
if (_2760 (_2644) > 1 && _2755 (_2812))
_2648 (stream, "<BR>");
if (_2799-> _2775)
_2648 (stream, _2640);
_2649 (stream, "<INPUT TYPE=RADIO VALUE=\"%d\" NAME=%s%s>%s\n",
_2760 (_2644),
_2666 (_2812, index),
_2760 (_2644) == _2811? " CHECKED": "",
_2761 (_2644));
if (_2799-> _2775)
_2648 (stream, _2641);
}
else
if (_2754 (_2812))
{
if (_2760 (_2644) > 1 && _2755 (_2812))
_2648 (stream, "<BR>");
value = xstrcpy (NULL,
_2760 (_2644) == _2811?
" (*) ": " (&nbsp;) ",
_2761 (_2644),
NULL);
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, value, _2681, index);
else
_2649 (stream, _2799-> output, value);
mem_free (value);
}
else
if (_2811 == 0 && _2760 (_2644) == 1)
{
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, _2758 (_2812), _2681, index);
else
_2649 (stream, _2799-> output, _2758 (_2812));
}
else
if (_2760 (_2644) == _2811)
{
if (*_2664 (_2681, index) == FATTR_OPTION)
_2660 (stream, _2761 (_2644), _2681, index);
else
_2649 (stream, _2799-> output, _2761 (_2644));
}
}
static void
_2659 (VDESCR *stream, byte *_2644)
{
if (*_2774 (_2644) == FACTION_ENABLED)
{
if (_2762 (_2644) == FTYPE_BUTTON)
_2649 (stream, "<INPUT TYPE=SUBMIT VALUE=\"%s\" NAME=%s>\n",
_2769 (_2644), _2768 (_2644));
else
if (_2762 (_2644) == FTYPE_PLAIN)
_2649 (stream, "<A HREF=\"#(uri)&%s=1\">%s</A>\n",
_2768 (_2644), _2769 (_2644));
else
if (_2762 (_2644) == FTYPE_IMAGE)
{
_2649 (stream, "<INPUT TYPE=IMAGE BORDER=0 SRC=%s NAME=%s",
_2769 (_2644), _2768 (_2644));
if (_2766 (_2644))
_2649 (stream, " HEIGHT=%d WIDTH=%d",
_2766 (_2644), _2767 (_2644));
_2648 (stream, ">\n");
}
}
else
if (*_2774 (_2644) == FACTION_DISABLED)
{
if (_2762 (_2644) == FTYPE_BUTTON)
_2649 (stream, "&nbsp;[ %s ]&nbsp;\n", _2769 (_2644));
else
if (_2762 (_2644) == FTYPE_PLAIN)
_2649 (stream, "%s\n", _2769 (_2644));
else
if (_2762 (_2644) == FTYPE_IMAGE)
{
_2649 (stream, "<IMG BORDER=0 SRC=%s ALT=%s",
_2769 (_2644), _2768 (_2644));
if (_2766 (_2644))
_2649 (stream, " HEIGHT=%d WIDTH=%d",
_2766 (_2644), _2767 (_2644));
_2648 (stream, ">\n");
}
}
}
int
form_get (
FORM_ITEM *form,
const char *query)
{
SYMTAB
*symtab;
int
_2813 = 0;
ASSERT (form);
ASSERT (query);
if ((symtab = http_query2symb (query)) == NULL)
return 0;
form-> status = FSTATUS_OK;
form-> image_x = 0;
form-> image_y = 0;
form-> click_field = 0;
form-> click_index = 0;
strclr (form-> livelink);
form-> event = form-> click_event;
mem_check (form-> data);
form_use (form);
form_exec (form, _2683, symtab, &_2813);
sym_exec_all (symtab, _2686);
sym_delete_table (symtab);
return (form-> status == FSTATUS_OK? _2813: -1);
}
static Bool
_2683 (
FORM_ITEM *form,
byte *_2644,
int _2681,
va_list _2682)
{
static int
_2814,
_2815;
SYMTAB
*symtab;
SYMBOL
*symbol;
byte
_2785;
int
_2816,
*_2817,
_2818,
index;
symtab = va_arg (_2682, SYMTAB *);
_2817 = va_arg (_2682, int *);
if (_2681 == -1)
_2814 = 0;
mem_check (form-> data);
_2785 = _2688 (_2644);
if (_2770 (_2785))
{
_2818 = _2814? _2815: 1;
for (index = 0; index < _2818; index++)
{
_2671 (_2681, index);
symbol = sym_lookup_symbol (symtab, _2666 (_2644, index));
if (symbol)
{
_2816 = _2670 (_2644, _2681, index,
symbol-> value);
if (_2816 == -1)
form-> status = FSTATUS_FIELD;
else
*_2817 += _2816;
}
}
}
else
if (_2785 == BLOCK_ACTION)
_2674 (symtab, _2644);
else
if (_2785 == BLOCK_REPEAT)
{
_2814 = _2700 (_2644) + 1;
_2815 = atoi (_2665 (_2699 (_2644), 0));
}
if (_2814)
_2814--;
return (TRUE);
}
static int
_2670 (byte *_2644, int _2681, int index, char *value)
{
switch (_2688 (_2644))
{
case BLOCK_TEXTUAL:
case BLOCK_TEXTBOX:
case BLOCK_SELECT:
case BLOCK_RADIO:
return (fxputn_text (_2681, index, value));
case BLOCK_NUMERIC:
return (_2672 (_2644, _2681, index, value));
case BLOCK_DATE:
return (_2673 (_2644, _2681, index, value));
case BLOCK_BOOLEAN:
return (fxputn_text (_2681, index, "1"));
}
return (0);
}
static int
_2672 (byte *_2644, int _2681, int index, char *value)
{
static char
_2819 [LINE_MAX];
int
_2802,
sign_format,
_2803,
_2820;
char
*_2821;
byte
*attr;
_2667 (
_2644,
&_2802,
&sign_format,
&_2803,
&_2820);
_2820 = _2710 (_2644);
_2821 = conv_str_number
(
value,
_2802,
_2638-> dec_point,
_2712 (_2644),
_2803,
_2820
);
if (_2821 == NULL)
{
xstrcpy (_2819, "Invalid number (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _2819;
attr = _2664 (_2681, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_text (_2681, index, _2821));
}
static int
_2673 (byte *_2644, int _2681, int index, char *value)
{
static char
_2822 [LINE_MAX];
int
format;
long
_2805 = -1;
byte
*attr;
if (_2723 (_2644) == FSHOW_YMD)
format = DATE_YMD_DELIM;
else
if (_2723 (_2644) == FSHOW_YM)
format = DATE_YM_DELIM;
else
format = DATE_MD_DELIM;
_2805 = conv_str_date (value, 0, format, _2638-> date_order);
if (_2805 == -1)
{
xstrcpy (_2822, "Invalid date (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _2822;
attr = _2664 (_2681, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_date (_2681, index, _2805));
}
static void
_2671 (int _2681, int index)
{
byte
*attr;
attr = _2664 (_2681, index);
if (*attr == FATTR_ERROR)
*attr = FATTR_INPUT;
}
static void
_2674 (SYMTAB *symtab, byte *_2644)
{
SYMBOL
*symbol;
char
*_2823;
if (_2762 (_2644) == FTYPE_IMAGE)
{
_2823 = xstrcpy (NULL, _2768 (_2644), ".x", NULL);
symbol = sym_lookup_symbol (symtab, _2823);
if (symbol)
{
_2638-> event = _2763 (_2644);
_2638-> image_x = atoi (symbol-> value);
strlast (_2823) = 'y';
symbol = sym_lookup_symbol (symtab, _2823);
if (symbol)
_2638-> image_y = atoi (symbol-> value);
}
mem_free (_2823);
}
else
{
symbol = sym_lookup_symbol (symtab, _2768 (_2644));
if (symbol)
_2638-> event = _2763 (_2644);
}
}
static Bool
_2686 (SYMBOL *symbol, ...)
{
char
*_2824;
if (symbol-> name [0] == '~')
{
if (symbol-> name [1] == 'C')
{
_2824 = strchr (symbol-> name + 2, '.');
if (_2824)
{
_2638-> click_field = atoi (symbol-> name + 2);
_2638-> click_index = atoi (_2824 + 1);
_2638-> event = _2638-> click_event;
return (FALSE);
}
}
else
if (symbol-> name [1] == 'L')
{
strncpy (_2638-> livelink, symbol-> name + 2,
FORMIO_LIVELINK_MAX);
_2638-> livelink [FORMIO_LIVELINK_MAX] = '\0';
_2638-> event = _2638-> click_event;
return (FALSE);
}
}
return (TRUE);
}
int
fxputn_text (int field, int index, const char *new_value)
{
char
*value;
ASSERT (new_value);
ASSERT (index < _2690 (_2772 (field)));
if (field < 0 || field >= _2638-> defn-> field_count)
return (0);
value = _2665 (field, index);
if (streq (value, new_value))
return (0);
else
{
strncpy (value, new_value, _2773 (field));
value [_2773 (field)] = '\0';
strcrop (value);
return (1);
}
}
int
fxputn_date (int field, int index, long new_value)
{
ASSERT (index < _2690 (_2772 (field)));
return (fxputn_long (field, index, new_value));
}
int
fxputn_int (int field, int index, int new_value)
{
ASSERT (index < _2690 (_2772 (field)));
return (fxputn_long (field, index, (long) new_value));
}
int
fxputn_long (int field, int index, long new_value)
{
static char
_2801 [20];
ASSERT (index < _2690 (_2772 (field)));
if (field < 0 || field >= _2638-> defn-> field_count)
return (0);
sprintf (_2801, "%ld", new_value);
return (fxputn_text (field, index, _2801));
}
int
fxputn_double (int field, int index, double new_value)
{
static char
_2801 [40];
ASSERT (index < _2690 (_2772 (field)));
sprintf (_2801, "%g", new_value);
return (fxputn_text (field, index, _2801));
}
int
fxputn_bool (int field, int index, Bool new_value)
{
ASSERT (index < _2690 (_2772 (field)));
return (fxputn_text (field, index, new_value? "1": "0"));
}
char *
fxgetn_text (int field, int index)
{
if (field < 0 || field >= _2638-> defn-> field_count)
return (NULL);
ASSERT (index < _2690 (_2772 (field)));
return (_2665 (field, index));
}
long
fxgetn_date (int field, int index)
{
if (field < 0 || field >= _2638-> defn-> field_count)
return (0);
ASSERT (index < _2690 (_2772 (field)));
ASSERT (_2688 (_2772 (field)) == BLOCK_DATE);
return (atol (_2665 (field, index)));
}
int
fxgetn_int (int field, int index)
{
if (field < 0 || field >= _2638-> defn-> field_count)
return (0);
ASSERT (index < _2690 (_2772 (field)));
return (atoi (_2665 (field, index)));
}
long
fxgetn_long (int field, int index)
{
if (field < 0 || field >= _2638-> defn-> field_count)
return (0);
ASSERT (index < _2690 (_2772 (field)));
return (atol (_2665 (field, index)));
}
double
fxgetn_double (int field, int index)
{
if (field < 0 || field >= _2638-> defn-> field_count)
return (0);
ASSERT (index < _2690 (_2772 (field)));
return (atof (_2665 (field, index)));
}
Bool
fxgetn_bool (int field, int index)
{
ASSERT (index < _2690 (_2772 (field)));
return (fxgetn_long (field, index)? TRUE: FALSE);
}
byte
fxattr_get (
int _2681,
int index)
{
FORM_DEFN
*defn;
defn = _2638-> defn;
ASSERT (_2681 >= 0 && _2681 < defn-> field_count);
return (*_2664 (_2681, index));
}
void
fxattr_put (
int _2681,
int index,
byte attr)
{
FORM_DEFN
*defn;
defn = _2638-> defn;
ASSERT (_2681 >= 0 && _2681 < defn-> field_count);
*_2664 (_2681, index) = attr;
}
size_t
fxlist_size (int field, int index)
{
return (atoi (_2676 (field, index, 0, 'h')));
}
static char *
_2679 (int field, int index, int _2677, char _2678)
{
static char
key [11];
sprintf (key, "%02x.%02x.%02x.%c",
(byte) field, (byte) index, (byte) _2677, _2678);
return (key);
}
static char *
_2676 (int field, int index, int _2677, char _2678)
{
SYMBOL
*symbol;
if (_2638-> list_values)
{
symbol = sym_lookup_symbol (_2638-> list_values,
_2679 (field, index, _2677, _2678));
if (symbol)
return (symbol-> value);
}
return ("");
}
void
fxlist_reset (int field, int index)
{
SYMBOL
*symbol;
int
_2677;
if (_2638-> list_values == NULL)
_2638-> list_values = sym_create_table ();
_2677 = fxlist_size (field, index);
while (_2677 > 0)
{
symbol = sym_lookup_symbol (_2638-> list_values,
_2679 (field, index, _2677, 'k'));
if (symbol)
sym_delete_symbol (_2638-> list_values, symbol);
symbol = sym_lookup_symbol (_2638-> list_values,
_2679 (field, index, _2677, 'v'));
if (symbol)
sym_delete_symbol (_2638-> list_values, symbol);
_2677--;
}
sym_create_symbol (_2638-> list_values,
_2679 (field, index, 0, 'h'), "000");
}
int
fxlist_append (int field, int index, char *key, char *value)
{
SYMBOL
*symbol;
int
_2825;
ASSERT (_2638-> list_values);
symbol = sym_lookup_symbol (_2638-> list_values,
_2679 (field, index, 0, 'h'));
if (symbol == NULL)
return (0);
_2825 = fxlist_size (field, index);
if (_2825 == 999)
return (_2825);
_2825++;
sym_assume_symbol (_2638-> list_values,
_2679 (field, index, _2825, 'k'), key);
sym_assume_symbol (_2638-> list_values,
_2679 (field, index, _2825, 'v'), value);
sprintf (symbol-> value, "%d", _2825);
return (_2825);
}
char *
fxlist_key (int field, int index)
{
return (_2676 (field, index, fxgetn_int (field, index), 'k'));
}
void
fxlist_set (int field, int index, char *key)
{
int
_2677;
ASSERT (_2638-> list_values);
_2677 = fxlist_size (field, index);
while (_2677 > 0)
{
if (streq (_2676 (field, index, _2677, 'k'), key))
break;
_2677--;
}
fxputn_int (field, index, _2677);
}
int
form_exec (
FORM_ITEM *form,
blockfunc _2826,
...)
{
va_list
_2682;
byte
*_2644;
word
block_size;
int
_2681,
_2787,
count = 0;
ASSERT (form);
va_start (_2682, _2826);
_2681 = -1;
_2644 = form-> defn-> blocks;
for (_2787 = 0; _2787 < form-> defn-> block_count; _2787++)
{
block_size = _2687 (_2644);
ASSERT (block_size > 0);
if (_2770 (_2688 (_2644)))
_2681++;
if ((*_2826) (form, _2644, _2681, _2682))
count++;
else
break;
_2644 += block_size + 2;
}
va_end (_2682);
return (count);
}
void
action_enable (FORM_ITEM *form, int event)
{
form_exec (form, _2685, event, FACTION_ENABLED);
}
static Bool
_2685 (
FORM_ITEM *form,
byte *_2644,
int _2681,
va_list _2682)
{
int
event,
attr;
event = va_arg (_2682, int);
attr = va_arg (_2682, int);
_2638 = form;
if (_2688 (_2644) == BLOCK_ACTION)
{
if (event == -1
|| event == _2763 (_2644))
*_2774 (_2644) = attr;
}
return (TRUE);
}
void
action_disable (FORM_ITEM *form, int event)
{
form_exec (form, _2685, event, FACTION_DISABLED);
}
void
action_hide (FORM_ITEM *form, int event)
{
form_exec (form, _2685, event, FACTION_HIDDEN);
}
int
form_save (
const char *filename,
FORM_ITEM *form)
{
FILE
*stream;
stream = fopen (filename, FOPEN_WRITE_BINARY);
if (stream)
{
fwrite (form, sizeof (FORM_ITEM), 1, stream);
fwrite (form-> data, form-> data_size, 1, stream);
fclose (stream);
return (0);
}
else
return (-1);
}
FORM_ITEM *
form_load (
const char *filename,
FORM_DEFN *defn)
{
FILE
*stream;
FORM_ITEM
*form;
byte
*data;
stream = fopen (filename, FOPEN_READ_BINARY);
if (!stream)
return (NULL);
if ((form = _2642 (defn)) == NULL)
return (NULL);
data = form-> data;
fread (form, sizeof (FORM_ITEM), 1, stream);
form-> data = data;
form-> defn = defn;
fread (form-> data, form-> data_size, 1, stream);
mem_check (form-> data);
fclose (stream);
return (form);
}
void
form_dump (FORM_ITEM *form)
{
int
_2787 = 0;
ASSERT (form);
printf ("Dumping contents of form %s\n", form-> defn-> form_name);
printf ("Block: Size:  Type:      Details:\n");
form_exec (form, _2684, &_2787);
}
static Bool
_2684 (
FORM_ITEM *form,
byte *_2644,
int _2681,
va_list _2682)
{
byte
*_2798;
word
block_size;
int
*_2787;
_2787 = va_arg (_2682, int *);
block_size = _2687 (_2644);
printf ("%p %-6d %-6d ", _2644, *_2787, block_size);
(*_2787)++;
switch (_2688 (_2644))
{
case BLOCK_PLAIN:
printf ("plain      ");
_2644 += 2;
block_size--;
if (block_size > 50)
block_size = 50;
while (block_size-- > 0)
printf ("%c", *++_2644);
printf ("\n");
break;
case BLOCK_COMPRESSED:
printf ("compressed ");
_2798 = _2693 (_2644) + form-> defn-> blocks;
if (_2692 (_2644) == COMPR_WHOLEDICT)
block_size = _2687 (_2798) - 1;
else
if (_2692 (_2644) == COMPR_PARTDICT)
block_size = _2694 (_2644);
else
abort ();
_2798 += 2;
if (block_size > 50)
block_size = 50;
while (block_size-- > 0)
printf ("%c", *++_2798);
printf ("\n");
break;
case BLOCK_IF:
printf ("if         ");
printf ("field=%d scope=%d\n",
_2695 (_2644),
_2696 (_2644));
break;
case BLOCK_UNLESS:
printf ("unless     ");
printf ("field=%d scope=%d\n",
_2697 (_2644),
_2698 (_2644));
break;
case BLOCK_REPEAT:
printf ("repeat     ");
printf ("field=%d scope=%d occurs=%d\n",
_2699 (_2644),
_2700 (_2644),
_2701 (_2644));
break;
case BLOCK_TEXTUAL:
printf ("textual    ");
printf ("x%d attr=%d size=%d max=%d name=%s value=%s\n",
_2703 (_2644),
_2702 (_2644),
_2704 (_2644),
_2705 (_2644),
_2706 (_2644),
_2707 (_2644));
break;
case BLOCK_NUMERIC:
printf ("numeric    ");
printf ("x%d attr=%d size=%d max=%d sign=%d decs=%d ",
_2709 (_2644),
_2708 (_2644),
_2710 (_2644),
_2711 (_2644),
_2713 (_2644),
_2712 (_2644));
printf ("fill=%d blank=%d comma=%d name=%s value=%s\n",
_2715 (_2644),
_2716 (_2644),
_2717 (_2644),
_2718 (_2644),
_2719 (_2644));
break;
case BLOCK_DATE:
printf ("date       ");
printf ("x%d attr=%d size=%d show=%d format=%d year=%d ",
_2721 (_2644),
_2720 (_2644),
_2722 (_2644),
_2723 (_2644),
_2724 (_2644),
_2725 (_2644));
printf ("month=%d day=%d name=%s value=%s picture=%s\n",
_2726 (_2644),
_2727 (_2644),
_2728 (_2644),
_2729 (_2644),
_2730 (_2644));
break;
case BLOCK_TEXTBOX:
printf ("textbox    ");
printf ("x%d attr=%d rows=%d cols=%d max=%d name=%s value=%s\n",
_2732 (_2644),
_2731 (_2644),
_2733 (_2644),
_2734 (_2644),
_2735 (_2644),
_2736 (_2644),
_2737 (_2644));
break;
case BLOCK_BOOLEAN:
printf ("boolean    ");
printf ("x%d attr=%d name=%s value=%s\n",
_2739 (_2644),
_2738 (_2644),
_2740 (_2644),
_2741 (_2644));
break;
case BLOCK_SELECT:
printf ("select     ");
printf ("x%d attr=%d size=%d opts=%d name=%s value=%s first=%s\n",
_2745 (_2644),
_2744 (_2644),
_2746 (_2644),
_2747 (_2644),
_2748 (_2644),
_2749 (_2644),
_2751 (_2644));
break;
case BLOCK_RADIO:
printf ("radio      ");
printf ("x%d attr=%d detail=%d column=%d name=%s value=%s\n",
_2753 (_2644),
_2752 (_2644),
_2754 (_2644),
_2755 (_2644),
_2756 (_2644),
_2757 (_2644));
break;
case BLOCK_RLABEL:
printf ("rlabel     ");
printf ("data=%d index=%d value=%s\n",
_2759 (_2644),
_2760 (_2644),
_2761 (_2644));
break;
case BLOCK_ACTION:
printf ("action     ");
printf ("type=%d event=%d show=%d height=%d width=%d label=%s\n",
_2762 (_2644),
_2763 (_2644),
_2765 (_2644),
_2766 (_2644),
_2767 (_2644),
_2769 (_2644));
break;
default:
printf ("ERROR!\n");
abort ();
}
return (TRUE);
}
int
form_ftype (
FORM_ITEM *form,
int _2681)
{
FORM_DEFN
*defn;
ASSERT (form);
defn = form-> defn;
if (_2681 < 0 || _2681 >= defn-> field_count)
return (0);
else
return (_2688 (defn-> blocks + defn-> fields [_2681].block));
}
