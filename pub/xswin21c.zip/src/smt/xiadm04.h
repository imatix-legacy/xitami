/*---------------------------------------------------------------------------
 *  xiadm04.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM04__
#define __FORM_XIADM04__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define ALIAS_LIST_MAX                      10
#define XIADM04_MESSAGE_TO_USER             0
#define XIADM04_L_ALIAS_NAME                1
#define XIADM04_L_ALIAS_PATH                2
#define XIADM04_KEY                         3
#define XIADM04_ALIAS_NAME                  4
#define XIADM04_ALIAS_PATH                  5
#define XIADM04_L_NONAME2                   6
#define XIADM04_ALIAS_LIST                  7

/*  This table contains each block in the form                               */

static byte xiadm04_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - Aliases</TITLE></HEAD><BODY>          */
    0, 60, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'A', 'l', 'i', 'a', 's', 'e', 's',
    '<', '/', 'T', 'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A',
    'D', '>', '<', 'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - Aliases                                                  */
    0, 20, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'A', 'l', 'i', 'a', 's', 'e', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '5',
    /*  !--ACTION server  LABEL="Ser ... NT=server_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 2, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  <EM>Aliases</EM>                                                     */
    0, 17, 0, '<', 'E', 'M', '>', 'A', 'l', 'i', 'a', 's', 'e', 's',
    '<', '/', 'E', 'M', '>',
    /*  !--ACTION vhosts  LABEL="Vho ... NT=vhosts_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 3, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 4, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... =security_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 5, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  !--ACTION logging  LABEL="Lo ... T=logging_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) logging_event / 256), (byte) ((word)
    logging_event & 255), 0, 6, 0, 0, 0, 0, 0, 'l', 'o', 'g', 'g', 'i',
    'n', 'g', 0, 'L', 'o', 'g', 'g', 'i', 'n', 'g', 0,
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 7, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=BUTTON           */
    0, 21, 20, 0, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 8, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0, 'M',
    'I', 'M', 'E', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, 247, 0, 28,
    /*  !--FIELD TEXTUAL 59 NAME=L_alias-name VALUE="Alias:"                 */
    0, 17, 10, 6, 1, 0, 6, 0, 6, '5', '9', 0, 'A', 'l', 'i', 'a', 's',
    ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, 247, 0, 28,
    /*  !--FIELD TEXTUAL 60 NAME=L_alias-path VALUE="Points to path:"        */
    0, 26, 10, 6, 1, 0, 15, 0, 15, '6', '0', 0, 'P', 'o', 'i', 'n', 't',
    's', 32, 't', 'o', 32, 'p', 'a', 't', 'h', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, '6',
    /*  !--REPEAT alias_list  ROWS=10                                        */
    0, 7, 4, 0, 7, 0, 12, 0, 10,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 240,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 61 NAME=key SIZE=20 MAX=? VALUE=""                  */
    0, 11, 10, 4, 10, 0, 20, 0, 20, '6', '1', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL 62 NAME=alias-name SIZE=20 MAX=? VALUE=""           */
    0, 11, 10, 0, 10, 0, 20, 0, 20, '6', '2', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 171,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 3, 179,
    /*  !--FIELD TEXTUAL 63 NAME=alias-path SIZE=50 MAX=80 VALUE=""          */
    0, 11, 10, 0, 10, 0, '2', 0, 'P', '6', '3', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 171,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 'q',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '^',
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 64 NAME=L_n ... UE="Actions for this page:"         */
    0, 33, 10, 6, 1, 0, 22, 0, 22, '6', '4', 0, 'A', 'c', 't', 'i', 'o',
    'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32, 'p', 'a',
    'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 9, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 10, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 11, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 12, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't',
    0, 'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '^',
    /*  !--FIELD NUMERIC alias_list SIZE=4 VALUE=10                          */
    0, 27, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a',
    's', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 'r',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 'y',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 150, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '5',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 150, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '^',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm04_fields [] = {
    { 0, 88, 80 },                      /*  message_to_user                 */
    { 82, 803, 6 },                     /*  L_alias-name                    */
    { 90, 838, 15 },                    /*  L_alias-path                    */
    { 107, 926, 20 },                   /*  key                             */
    { 327, 976, 20 },                   /*  alias-name                      */
    { 547, 1001, 80 },                  /*  alias-path                      */
    { 1367, 1092, 22 },                 /*  L_noname2                       */
    { 1391, 1287, 4 },                  /*  alias_list                      */
    { 1397, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_alias_name_a       ;
    char   l_alias_name         [6 + 1];
    byte   l_alias_path_a       ;
    char   l_alias_path         [15 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [20 + 1];
    byte   alias_name_a         [10] ;
    char   alias_name           [10] [20 + 1];
    byte   alias_path_a         [10] ;
    char   alias_path           [10] [80 + 1];
    byte   l_noname2_a          ;
    char   l_noname2            [22 + 1];
    byte   alias_list_a         ;
    char   alias_list           [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   server_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   logging_a;
    byte   ftp_a;
    byte   mime_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM04_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm04 = {
    xiadm04_blocks,
    xiadm04_fields,
    69,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    13,                                 /*  Number of actions in form       */
    1397,                               /*  Size of fields                  */
    "xiadm04",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
