/*---------------------------------------------------------------------------
 *  xiadm08.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM08__
#define __FORM_XIADM08__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM08_MESSAGE_TO_USER             0
#define XIADM08_MAIN_CONFIG                 1
#define XIADM08_L_LOGFILE                   2
#define XIADM08_L_ENABLED                   3
#define XIADM08_L_CYCLE                     4
#define XIADM08_LOGTYPE_1                   5
#define XIADM08_LOGFILE_1                   6
#define XIADM08_ENABLED_1                   7
#define XIADM08_CYCLE_1                     8
#define XIADM08_LOGTYPE_2                   9
#define XIADM08_LOGFILE_2                   10
#define XIADM08_ENABLED_2                   11
#define XIADM08_CYCLE_2                     12
#define XIADM08_LOGTYPE_3                   13
#define XIADM08_LOGFILE_3                   14
#define XIADM08_ENABLED_3                   15
#define XIADM08_CYCLE_3                     16
#define XIADM08_L_NONAME7                   17

/*  This table contains each block in the form                               */

static byte xiadm08_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - Log Files</TITLE></HEAD><BODY>        */
    0, 62, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'L', 'o', 'g', 32, 'F', 'i', 'l',
    'e', 's', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', '<', '/', 'H',
    'E', 'A', 'D', '>', '<', 'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - Log Files                                                */
    0, 22, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'L', 'o', 'g', 32, 'F', 'i', 'l', 'e', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  !--FIELD NUMERIC main_config SIZE=4 VALUE=1                          */
    0, 27, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'm', 'a', 'i', 'n',
    '_', 'c', 'o', 'n', 'f', 'i', 'g', 0, '1', 0,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '7',
    /*  !--ACTION server  LABEL="Ser ... NT=server_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 2, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  !--ACTION aliases  LABEL="Al ... T=aliases_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 3, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  !--ACTION vhosts  LABEL="Vho ... NT=vhosts_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 4, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 5, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... =security_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 6, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  <EM>Logging</EM>                                                     */
    0, 17, 0, '<', 'E', 'M', '>', 'L', 'o', 'g', 'g', 'i', 'n', 'g',
    '<', '/', 'E', 'M', '>',
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 7, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=BUTTON           */
    0, 21, 20, 0, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 8, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0, 'M',
    'I', 'M', 'E', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, 24, 0, 28,
    /*  !--FIELD TEXTUAL 120 NAME=L_logfile VALUE="Filename:"                */
    0, 21, 10, 6, 1, 0, 9, 0, 9, '1', '2', '0', 0, 'F', 'i', 'l', 'e',
    'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, 24, 0, 28,
    /*  !--FIELD TEXTUAL 121 NAME=L_enabled VALUE="On:"                      */
    0, 15, 10, 6, 1, 0, 3, 0, 3, '1', '2', '1', 0, 'O', 'n', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, '[',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, 24, 0, 28,
    /*  !--FIELD TEXTUAL 122 NAME=L_cycle VALUE="Cycle:"                     */
    0, 18, 10, 6, 1, 0, 6, 0, 6, '1', '2', '2', 0, 'C', 'y', 'c', 'l',
    'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, '[',
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 17,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL 123 NAME=logtype_1 SIZE=15 MAX=? VALUE=""           */
    0, 12, 10, 7, 1, 0, 15, 0, 15, '1', '2', '3', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 124 NAME=logfile_1 SIZE=16 MAX=40 VALUE=""          */
    0, 12, 10, 0, 1, 0, 16, 0, '(', '1', '2', '4', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD BOOLEAN 125 NAME=enabled_1 TRUE=yes FALSE=no VALUE=0        */
    0, 16, 14, 0, 1, '1', '2', '5', 0, '0', 0, 'y', 'e', 's', 0, 'n',
    'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD SELECT 126 NAME=cyc ... ekly" 4="Monthly" 5="Never"         */
    0, 50, 15, 0, 1, 1, 5, '1', '2', '6', 0, '0', 0, 'A', 't', 32, 's',
    't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y', 0,
    'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 164,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 17,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 3, 178,
    /*  !--FIELD TEXTUAL 127 NAME=logtype_2 SIZE=15 MAX=? VALUE=""           */
    0, 12, 10, 7, 1, 0, 15, 0, 15, '1', '2', '7', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD TEXTUAL 128 NAME=logfile_2 SIZE=16 MAX=40 VALUE=""          */
    0, 12, 10, 0, 1, 0, 16, 0, '(', '1', '2', '8', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD BOOLEAN 129 NAME=enabled_2 TRUE=yes FALSE=no VALUE=0        */
    0, 16, 14, 0, 1, '1', '2', '9', 0, '0', 0, 'y', 'e', 's', 0, 'n',
    'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD SELECT 130 NAME=cyc ... ekly" 4="Monthly" 5="Never"         */
    0, 50, 15, 0, 1, 1, 5, '1', '3', '0', 0, '0', 0, 'A', 't', 32, 's',
    't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y', 0,
    'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 164,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 17,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 3, 178,
    /*  !--FIELD TEXTUAL 131 NAME=logtype_3 SIZE=15 MAX=? VALUE=""           */
    0, 12, 10, 7, 1, 0, 15, 0, 15, '1', '3', '1', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD TEXTUAL 132 NAME=logfile_3 SIZE=16 MAX=40 VALUE=""          */
    0, 12, 10, 0, 1, 0, 16, 0, '(', '1', '3', '2', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD BOOLEAN 133 NAME=enabled_3 TRUE=yes FALSE=no VALUE=0        */
    0, 16, 14, 0, 1, '1', '3', '3', 0, '0', 0, 'y', 'e', 's', 0, 'n',
    'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 229,
    /*  !--FIELD SELECT 134 NAME=cyc ... ekly" 4="Monthly" 5="Never"         */
    0, 50, 15, 0, 1, 1, 5, '1', '3', '4', 0, '0', 0, 'A', 't', 32, 's',
    't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y', 0,
    'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 221,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 164,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'b',
    /*  !--UNLESS main_config                                                */
    0, 5, 3, 0, 1, 0, 1,
    /*  <P>To change the server log, ...  the Defaults configuration.        */
    0, 72, 0, '<', 'P', '>', 'T', 'o', 32, 'c', 'h', 'a', 'n', 'g', 'e',
    32, 't', 'h', 'e', 32, 's', 'e', 'r', 'v', 'e', 'r', 32, 'l', 'o',
    'g', ',', 32, 'y', 'o', 'u', 32, 'm', 'u', 's', 't', 32, 'b', 'e',
    32, 'i', 'n', 32, 't', 'h', 'e', 32, 'D', 'e', 'f', 'a', 'u', 'l',
    't', 's', 32, 'c', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't', 'i',
    'o', 'n', '.',
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 135 NAME=L_ ... UE="Actions for this page:"         */
    0, 34, 10, 6, 1, 0, 22, 0, 22, '1', '3', '5', 0, 'A', 'c', 't', 'i',
    'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32, 'p',
    'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 9, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 10, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'b',
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 't',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, '{',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 152, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '7',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 152, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'b',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm08_fields [] = {
    { 0, 90, 80 },                      /*  message_to_user                 */
    { 82, 365, 4 },                     /*  main_config                     */
    { 88, 836, 9 },                     /*  L_logfile                       */
    { 99, 875, 3 },                     /*  L_enabled                       */
    { 104, 906, 6 },                    /*  L_cycle                         */
    { 112, 975, 15 },                   /*  logtype_1                       */
    { 129, 1028, 40 },                  /*  logfile_1                       */
    { 171, 1054, 1 },                   /*  enabled_1                       */
    { 174, 1084, 3 },                   /*  cycle_1                         */
    { 179, 1160, 15 },                  /*  logtype_2                       */
    { 196, 1186, 40 },                  /*  logfile_2                       */
    { 238, 1212, 1 },                   /*  enabled_2                       */
    { 241, 1242, 3 },                   /*  cycle_2                         */
    { 246, 1318, 15 },                  /*  logtype_3                       */
    { 263, 1344, 40 },                  /*  logfile_3                       */
    { 305, 1370, 1 },                   /*  enabled_3                       */
    { 308, 1400, 3 },                   /*  cycle_3                         */
    { 313, 1611, 22 },                  /*  L_noname7                       */
    { 337, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   main_config_a        ;
    char   main_config          [4 + 1];
    byte   l_logfile_a          ;
    char   l_logfile            [9 + 1];
    byte   l_enabled_a          ;
    char   l_enabled            [3 + 1];
    byte   l_cycle_a            ;
    char   l_cycle              [6 + 1];
    byte   logtype_1_a          ;
    char   logtype_1            [15 + 1];
    byte   logfile_1_a          ;
    char   logfile_1            [40 + 1];
    byte   enabled_1_a          ;
    char   enabled_1            [1 + 1];
    byte   cycle_1_a            ;
    char   cycle_1              [3 + 1];
    byte   logtype_2_a          ;
    char   logtype_2            [15 + 1];
    byte   logfile_2_a          ;
    char   logfile_2            [40 + 1];
    byte   enabled_2_a          ;
    char   enabled_2            [1 + 1];
    byte   cycle_2_a            ;
    char   cycle_2              [3 + 1];
    byte   logtype_3_a          ;
    char   logtype_3            [15 + 1];
    byte   logfile_3_a          ;
    char   logfile_3            [40 + 1];
    byte   enabled_3_a          ;
    char   enabled_3            [1 + 1];
    byte   cycle_3_a            ;
    char   cycle_3              [3 + 1];
    byte   l_noname7_a          ;
    char   l_noname7            [22 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   server_a;
    byte   aliases_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   ftp_a;
    byte   mime_a;
    byte   defaults_a;
    byte   undo_a;
    } XIADM08_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm08 = {
    xiadm08_blocks,
    xiadm08_fields,
    102,                                /*  Number of blocks in form        */
    18,                                 /*  Number of fields in form        */
    11,                                 /*  Number of actions in form       */
    337,                                /*  Size of fields                  */
    "xiadm08",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
