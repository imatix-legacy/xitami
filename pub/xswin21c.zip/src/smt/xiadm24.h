/*---------------------------------------------------------------------------
 *  xiadm24.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM24__
#define __FORM_XIADM24__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define CLIENT_LIST_MAX                     16
#define XIADM24_MESSAGE_TO_USER             0
#define XIADM24_REFRESH_ON                  1
#define XIADM24_L_TYPE                      2
#define XIADM24_L_IPADDRESS                 3
#define XIADM24_L_USERNAME                  4
#define XIADM24_TYPE                        5
#define XIADM24_IPADDRESS                   6
#define XIADM24_USERNAME                    7
#define XIADM24_CLIENT_LIST                 8

/*  This table contains each block in the form                               */

static byte xiadm24_blocks [] = {
    /*  <HTML><HEAD><TITLE>Current H ... ections</TITLE></HEAD><BODY>        */
    0, 71, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'C', 'u', 'r', 'r', 'e',
    'n', 't', 32, 'H', 'T', 'T', 'P', 32, '&', 32, 'F', 'T', 'P', 32,
    'C', 'o', 'n', 'n', 'e', 'c', 't', 'i', 'o', 'n', 's', '<', '/',
    'T', 'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A', 'D', '>',
    '<', 'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 133, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  Current HTTP & FTP Connections                                       */
    0, 31, 0, 'C', 'u', 'r', 'r', 'e', 'n', 't', 32, 'H', 'T', 'T', 'P',
    32, '&', 32, 'F', 'T', 'P', 32, 'C', 'o', 'n', 'n', 'e', 'c', 't',
    'i', 'o', 'n', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  !--FIELD NUMERIC refresh_on SIZE=4 VALUE=1                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r',
    'e', 's', 'h', '_', 'o', 'n', 0, '1', 0,
    /*  !--IF refresh_on                                                     */
    0, 5, 2, 0, 1, 0, 1,
    /*  <META HTTP-EQUIV="REFRESH" CONTENT="#(rate)">                        */
    0, 46, 0, '<', 'M', 'E', 'T', 'A', 32, 'H', 'T', 'T', 'P', 45, 'E',
    'Q', 'U', 'I', 'V', '=', '"', 'R', 'E', 'F', 'R', 'E', 'S', 'H',
    '"', 32, 'C', 'O', 'N', 'T', 'E', 'N', 'T', '=', '"', '#', '(', 'r',
    'a', 't', 'e', ')', '"', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION close  LABEL="Close" EVENT=ok_event TYPE=BUTTON            */
    0, 23, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'c', 'l', 'o', 's', 'e', 0,
    'C', 'l', 'o', 's', 'e', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP WIDTH=50% >                                            */
    0, 26, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, 'W', 'I', 'D', 'T', 'H', '=', '5', '0', '%', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 306 NAME=L_type VALUE="Type:"                       */
    0, 17, 10, 6, 1, 0, 5, 0, 5, '3', '0', '6', 0, 'T', 'y', 'p', 'e',
    ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 'q',
    /*  !--FIELD TEXTUAL 307 NAME=L_ ...  VALUE="Client IP address:"         */
    0, 30, 10, 6, 1, 0, 18, 0, 18, '3', '0', '7', 0, 'C', 'l', 'i', 'e',
    'n', 't', 32, 'I', 'P', 32, 'a', 'd', 'd', 'r', 'e', 's', 's', ':',
    0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 163,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 'q',
    /*  !--FIELD TEXTUAL 308 NAME=L_username VALUE="User name:"              */
    0, 22, 10, 6, 1, 0, 10, 0, 10, '3', '0', '8', 0, 'U', 's', 'e', 'r',
    32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 163,
    /*  !--REPEAT client_list  ROWS=16                                       */
    0, 7, 4, 0, 8, 0, 12, 0, 16,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 'j',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL 309 NAME=type SIZE=4 MAX=? VALUE=""                 */
    0, 12, 10, 0, 16, 0, 4, 0, 4, '3', '0', '9', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 18,
    /*  !--FIELD TEXTUAL 310 NAME=ipaddress SIZE=15 MAX=? VALUE=""           */
    0, 12, 10, 0, 16, 0, 15, 0, 15, '3', '1', '0', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, '?',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 18,
    /*  !--FIELD NUMERIC 311 NAME=us ... MA=0 SIZE=20 MAX=? VALUE=""         */
    0, 18, 11, 0, 16, 0, 20, 0, 20, 0, 0, 0, 0, 0, 0, '3', '1', '1', 0,
    0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, '?',
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 4,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 92,
    /*  !--ACTION refresh  LABEL="Re ... T=refresh_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) refresh_event / 256), (byte) ((word)
    refresh_event & 255), 0, 1, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r', 'e',
    's', 'h', 0, 'R', 'e', 'f', 'r', 'e', 's', 'h', 0,
    /*  !--FIELD NUMERIC client_list SIZE=4 VALUE=16                         */
    0, 28, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'c', 'l', 'i', 'e',
    'n', 't', '_', 'l', 'i', 's', 't', 0, '1', '6', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, '}',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 132,
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 161, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '(',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 161, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 92,
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm24_fields [] = {
    { 0, 99, 80 },                      /*  message_to_user                 */
    { 82, 359, 4 },                     /*  refresh_on                      */
    { 88, 656, 5 },                     /*  L_type                          */
    { 95, 689, 18 },                    /*  L_ipaddress                     */
    { 115, 733, 10 },                   /*  L_username                      */
    { 127, 817, 4 },                    /*  type                            */
    { 223, 845, 15 },                   /*  ipaddress                       */
    { 495, 871, 20 },                   /*  username                        */
    { 847, 938, 4 },                    /*  client_list                     */
    { 853, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   refresh_on_a         ;
    char   refresh_on           [4 + 1];
    byte   l_type_a             ;
    char   l_type               [5 + 1];
    byte   l_ipaddress_a        ;
    char   l_ipaddress          [18 + 1];
    byte   l_username_a         ;
    char   l_username           [10 + 1];
    byte   type_a               [16] ;
    char   type                 [16] [4 + 1];
    byte   ipaddress_a          [16] ;
    char   ipaddress            [16] [15 + 1];
    byte   username_a           [16] ;
    char   username             [16] [20 + 1];
    byte   client_list_a        ;
    char   client_list          [4 + 1];
    byte   close_a;
    byte   refresh_a;
    } XIADM24_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm24 = {
    xiadm24_blocks,
    xiadm24_fields,
    55,                                 /*  Number of blocks in form        */
    9,                                  /*  Number of fields in form        */
    2,                                  /*  Number of actions in form       */
    853,                                /*  Size of fields                  */
    "xiadm24",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
