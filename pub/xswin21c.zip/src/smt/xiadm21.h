/*---------------------------------------------------------------------------
 *  xiadm21.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM21__
#define __FORM_XIADM21__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM21_MESSAGE_TO_USER             0
#define XIADM21_REFRESH_ON                  1
#define XIADM21_L_SERVER_MESSAGE            2
#define XIADM21_SERVER_MESSAGE              3
#define XIADM21_L_HTTP_PORT                 4
#define XIADM21_HTTP_PORT                   5
#define XIADM21_L_FTP_PORT                  6
#define XIADM21_FTP_PORT                    7
#define XIADM21_L_CUR_CONNECTS              8
#define XIADM21_CUR_CONNECTS                9
#define XIADM21_L_MAX_CONNECTS              10
#define XIADM21_MAX_CONNECTS                11
#define XIADM21_L_CONNECT_COUNT             12
#define XIADM21_CONNECT_COUNT               13
#define XIADM21_L_ERROR_COUNT               14
#define XIADM21_ERROR_COUNT                 15
#define XIADM21_L_TRANSFER_SIZE             16
#define XIADM21_TRANSFER_SIZE               17

/*  This table contains each block in the form                               */

static byte xiadm21_blocks [] = {
    /*  <HTML><HEAD><TITLE>Server Console Panel</TITLE></HEAD><BODY>         */
    0, 61, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'S', 'e', 'r', 'v', 'e',
    'r', 32, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'P', 'a', 'n', 'e',
    'l', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E',
    'A', 'D', '>', '<', 'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 133, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  Server Console Panel                                                 */
    0, 21, 0, 'S', 'e', 'r', 'v', 'e', 'r', 32, 'C', 'o', 'n', 's', 'o',
    'l', 'e', 32, 'P', 'a', 'n', 'e', 'l',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  !--FIELD NUMERIC refresh_on SIZE=4 VALUE=1                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r',
    'e', 's', 'h', '_', 'o', 'n', 0, '1', 0,
    /*  !--IF refresh_on                                                     */
    0, 5, 2, 0, 1, 0, 1,
    /*  <META HTTP-EQUIV="REFRESH" CONTENT="#(rate)">                        */
    0, 46, 0, '<', 'M', 'E', 'T', 'A', 32, 'H', 'T', 'T', 'P', 45, 'E',
    'Q', 'U', 'I', 'V', '=', '"', 'R', 'E', 'F', 'R', 'E', 'S', 'H',
    '"', 32, 'C', 'O', 'N', 'T', 'E', 'N', 'T', '=', '"', '#', '(', 'r',
    'a', 't', 'e', ')', '"', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  !--ACTION close  LABEL="Close" EVENT=ok_event TYPE=BUTTON            */
    0, 23, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'c', 'l', 'o', 's', 'e', 0,
    'C', 'l', 'o', 's', 'e', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 277 NAME=L_ ... Last server error message:"         */
    0, 38, 10, 6, 1, 0, 26, 0, 26, '2', '7', '7', 0, 'L', 'a', 's', 't',
    32, 's', 'e', 'r', 'v', 'e', 'r', 32, 'e', 'r', 'r', 'o', 'r', 32,
    'm', 'e', 's', 's', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--FIELD TEXTUAL 278 NAME=se ... sage SIZE=80 MAX=? VALUE=""         */
    0, 12, 10, 0, 1, 0, 'P', 0, 'P', '2', '7', '8', 0, 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 279 NAME=L_ ... ="HTTP service is on port:"         */
    0, 36, 10, 6, 1, 0, 24, 0, 24, '2', '7', '9', 0, 'H', 'T', 'T', 'P',
    32, 's', 'e', 'r', 'v', 'i', 'c', 'e', 32, 'i', 's', 32, 'o', 'n',
    32, 'p', 'o', 'r', 't', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 280 NAME=ht ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, '2', '8', '0', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 281 NAME=L_ ... E="FTP service is on port:"         */
    0, 35, 10, 6, 1, 0, 23, 0, 23, '2', '8', '1', 0, 'F', 'T', 'P', 32,
    's', 'e', 'r', 'v', 'i', 'c', 'e', 32, 'i', 's', 32, 'o', 'n', 32,
    'p', 'o', 'r', 't', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 282 NAME=ft ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, '2', '8', '2', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 283 NAME=L_ ... umber of open connections:"         */
    0, 39, 10, 6, 1, 0, 27, 0, 27, '2', '8', '3', 0, 'N', 'u', 'm', 'b',
    'e', 'r', 32, 'o', 'f', 32, 'o', 'p', 'e', 'n', 32, 'c', 'o', 'n',
    'n', 'e', 'c', 't', 'i', 'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 284 NAME=cu ... MMA=0 SIZE=6 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 6, 0, 6, 0, 0, 0, 0, 0, 0, '2', '8', '4', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 285 NAME=L_ ... "Highest open connections:"         */
    0, 37, 10, 6, 1, 0, 25, 0, 25, '2', '8', '5', 0, 'H', 'i', 'g', 'h',
    'e', 's', 't', 32, 'o', 'p', 'e', 'n', 32, 'c', 'o', 'n', 'n', 'e',
    'c', 't', 'i', 'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 286 NAME=ma ... MMA=0 SIZE=6 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 6, 0, 6, 0, 0, 0, 0, 0, 0, '2', '8', '6', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 287 NAME=L_ ... LUE="Total number of hits:"         */
    0, 33, 10, 6, 1, 0, 21, 0, 21, '2', '8', '7', 0, 'T', 'o', 't', 'a',
    'l', 32, 'n', 'u', 'm', 'b', 'e', 'r', 32, 'o', 'f', 32, 'h', 'i',
    't', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 288 NAME=co ... MA=0 SIZE=10 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, '2', '8', '8', 0,
    0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 289 NAME=L_ ... E="Total number of errors:"         */
    0, 35, 10, 6, 1, 0, 23, 0, 23, '2', '8', '9', 0, 'T', 'o', 't', 'a',
    'l', 32, 'n', 'u', 'm', 'b', 'e', 'r', 32, 'o', 'f', 32, 'e', 'r',
    'r', 'o', 'r', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 290 NAME=er ... MA=0 SIZE=10 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, '2', '9', '0', 0,
    0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'N',
    /*  !--FIELD TEXTUAL 291 NAME=L_ ... UE="Total data transferred"         */
    0, 34, 10, 6, 1, 0, 22, 0, 22, '2', '9', '1', 0, 'T', 'o', 't', 'a',
    'l', 32, 'd', 'a', 't', 'a', 32, 't', 'r', 'a', 'n', 's', 'f', 'e',
    'r', 'r', 'e', 'd', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 158,
    /*  !--FIELD NUMERIC 292 NAME=tr ... MA=0 SIZE=10 MAX=? VALUE=""         */
    0, 18, 11, 0, 1, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, '2', '9', '2', 0,
    0,
    /*  Kb                                                                   */
    0, 3, 0, 'K', 'b',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 214,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'H',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  !--ACTION messages  LABEL="M ... =messages_event TYPE=BUTTON         */
    0, 32, 20, 0, (byte) ((word) messages_event / 256), (byte) ((word)
    messages_event & 255), 0, 1, 0, 0, 0, 0, 0, 'm', 'e', 's', 's', 'a',
    'g', 'e', 's', 0, 'M', 'e', 's', 's', 'a', 'g', 'e', 's', '.', '.',
    '.', 0,
    /*  !--ACTION details  LABEL="De ... T=details_event TYPE=BUTTON         */
    0, 30, 20, 0, (byte) ((word) details_event / 256), (byte) ((word)
    details_event & 255), 0, 2, 0, 0, 0, 0, 0, 'd', 'e', 't', 'a', 'i',
    'l', 's', 0, 'D', 'e', 't', 'a', 'i', 'l', 's', '.', '.', '.', 0,
    /*  !--ACTION properties  LABEL= ... NT=define_event TYPE=BUTTON         */
    0, 36, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 3, 0, 0, 0, 0, 0, 'p', 'r', 'o', 'p', 'e',
    'r', 't', 'i', 'e', 's', 0, 'P', 'r', 'o', 'p', 'e', 'r', 't', 'i',
    'e', 's', '.', '.', '.', 0,
    /*  !--ACTION refresh  LABEL="Re ... T=refresh_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) refresh_event / 256), (byte) ((word)
    refresh_event & 255), 0, 4, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r', 'e',
    's', 'h', 0, 'R', 'e', 'f', 'r', 'e', 's', 'h', 0,
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 5, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION restart  LABEL="Re ... T=restart_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) restart_event / 256), (byte) ((word)
    restart_event & 255), 0, 6, 0, 0, 0, 0, 0, 'r', 'e', 's', 't', 'a',
    'r', 't', 0, 'R', 'e', 's', 't', 'a', 'r', 't', 0,
    /*  !--ACTION terminate  LABEL=" ... VENT=kill_event TYPE=BUTTON         */
    0, 31, 20, 0, (byte) ((word) kill_event / 256), (byte) ((word)
    kill_event & 255), 0, 7, 0, 0, 0, 0, 0, 't', 'e', 'r', 'm', 'i',
    'n', 'a', 't', 'e', 0, 'T', 'e', 'r', 'm', 'i', 'n', 'a', 't', 'e',
    0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 's',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 'z',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 151, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, 30,
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 151, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'H',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm21_fields [] = {
    { 0, 89, 80 },                      /*  message_to_user                 */
    { 82, 339, 4 },                     /*  refresh_on                      */
    { 88, 630, 26 },                    /*  L_server-message                */
    { 116, 712, 80 },                   /*  server-message                  */
    { 198, 745, 24 },                   /*  L_http-port                     */
    { 224, 789, 5 },                    /*  http-port                       */
    { 231, 821, 23 },                   /*  L_ftp-port                      */
    { 256, 864, 5 },                    /*  ftp-port                        */
    { 263, 896, 27 },                   /*  L_cur-connects                  */
    { 292, 943, 6 },                    /*  cur-connects                    */
    { 300, 975, 25 },                   /*  L_max-connects                  */
    { 327, 1020, 6 },                   /*  max-connects                    */
    { 335, 1052, 21 },                  /*  L_connect-count                 */
    { 358, 1093, 10 },                  /*  connect-count                   */
    { 370, 1125, 23 },                  /*  L_error-count                   */
    { 395, 1168, 10 },                  /*  error-count                     */
    { 407, 1200, 22 },                  /*  L_transfer-size                 */
    { 431, 1242, 10 },                  /*  transfer-size                   */
    { 443, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   refresh_on_a         ;
    char   refresh_on           [4 + 1];
    byte   l_server_message_a   ;
    char   l_server_message     [26 + 1];
    byte   server_message_a     ;
    char   server_message       [80 + 1];
    byte   l_http_port_a        ;
    char   l_http_port          [24 + 1];
    byte   http_port_a          ;
    char   http_port            [5 + 1];
    byte   l_ftp_port_a         ;
    char   l_ftp_port           [23 + 1];
    byte   ftp_port_a           ;
    char   ftp_port             [5 + 1];
    byte   l_cur_connects_a     ;
    char   l_cur_connects       [27 + 1];
    byte   cur_connects_a       ;
    char   cur_connects         [6 + 1];
    byte   l_max_connects_a     ;
    char   l_max_connects       [25 + 1];
    byte   max_connects_a       ;
    char   max_connects         [6 + 1];
    byte   l_connect_count_a    ;
    char   l_connect_count      [21 + 1];
    byte   connect_count_a      ;
    char   connect_count        [10 + 1];
    byte   l_error_count_a      ;
    char   l_error_count        [23 + 1];
    byte   error_count_a        ;
    char   error_count          [10 + 1];
    byte   l_transfer_size_a    ;
    char   l_transfer_size      [22 + 1];
    byte   transfer_size_a      ;
    char   transfer_size        [10 + 1];
    byte   close_a;
    byte   messages_a;
    byte   details_a;
    byte   properties_a;
    byte   refresh_a;
    byte   clear_a;
    byte   restart_a;
    byte   terminate_a;
    } XIADM21_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm21 = {
    xiadm21_blocks,
    xiadm21_fields,
    79,                                 /*  Number of blocks in form        */
    18,                                 /*  Number of fields in form        */
    8,                                  /*  Number of actions in form       */
    443,                                /*  Size of fields                  */
    "xiadm21",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
