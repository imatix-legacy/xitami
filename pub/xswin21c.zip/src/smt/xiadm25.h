/*---------------------------------------------------------------------------
 *  xiadm25.h - HTML form definition
 *
 *  Generated 1997/12/23, 12:28:09 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com/>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM25__
#define __FORM_XIADM25__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM25_MESSAGE_TO_USER             0
#define XIADM25_L_HOST_FILE                 1
#define XIADM25_HOST_FILE                   2
#define XIADM25_L_OVERWRITE                 3
#define XIADM25_OVERWRITE                   4
#define XIADM25_L_HOST_ADDR                 5
#define XIADM25_HOST_ADDR                   6
#define XIADM25_L_HOST_NAME                 7
#define XIADM25_HOST_NAME                   8
#define XIADM25_L_WEBPAGES                  9
#define XIADM25_WEBPAGES                    10
#define XIADM25_L_CGI_BIN                   11
#define XIADM25_CGI_BIN                     12
#define XIADM25_L_SUPERUSER                 13
#define XIADM25_SUPERUSER                   14
#define XIADM25_L_SHARELOGS                 15
#define XIADM25_SHARELOGS                   16

/*  This table contains each block in the form                               */

static byte xiadm25_blocks [] = {
    /*  <HTML><HEAD><TITLE>Virtual Host Wizard</TITLE></HEAD><BODY>          */
    0, 60, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'V', 'i', 'r', 't', 'u',
    'a', 'l', 32, 'H', 'o', 's', 't', 32, 'W', 'i', 'z', 'a', 'r', 'd',
    '<', '/', 'T', 'I', 'T', 'L', 'E', '>', '<', '/', 'H', 'E', 'A',
    'D', '>', '<', 'B', 'O', 'D', 'Y', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  Virtual Host Wizard                                                  */
    0, 20, 0, 'V', 'i', 'r', 't', 'u', 'a', 'l', 32, 'H', 'o', 's', 't',
    32, 'W', 'i', 'z', 'a', 'r', 'd',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <HR><H2><A NAME="TOC2">Virtual Host Wizard</A></H2>                  */
    0, 52, 0, '<', 'H', 'R', '>', '<', 'H', '2', '>', '<', 'A', 32, 'N',
    'A', 'M', 'E', '=', '"', 'T', 'O', 'C', '2', '"', '>', 'V', 'i',
    'r', 't', 'u', 'a', 'l', 32, 'H', 'o', 's', 't', 32, 'W', 'i', 'z',
    'a', 'r', 'd', '<', '/', 'A', '>', '<', '/', 'H', '2', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <TABLE WIDTH=750>                                                    */
    0, 18, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '7', '5', '0', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL 312 NAME=L_ ... eate virtual host profile:"         */
    0, 40, 10, 6, 1, 0, 28, 0, 28, '3', '1', '2', 0, 'C', 'r', 'e', 'a',
    't', 'e', 32, 'v', 'i', 'r', 't', 'u', 'a', 'l', 32, 'h', 'o', 's',
    't', 32, 'p', 'r', 'o', 'f', 'i', 'l', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--FIELD TEXTUAL 313 NAME=host-file SIZE=12 MAX=40 VALUE=""          */
    0, 12, 10, 0, 1, 0, 12, 0, '(', '3', '1', '3', 0, 0,
    /*  .cfg extension is assumed                                            */
    0, 26, 0, '.', 'c', 'f', 'g', 32, 'e', 'x', 't', 'e', 'n', 's', 'i',
    'o', 'n', 32, 'i', 's', 32, 'a', 's', 's', 'u', 'm', 'e', 'd',
    /*  !--FIELD TEXTUAL 314 NAME=L_ ... ;&nbsp;Overwrite existing?"         */
    0, 43, 10, 6, 1, 0, 31, 0, 31, '3', '1', '4', 0, '&', 'n', 'b', 's',
    'p', ';', '&', 'n', 'b', 's', 'p', ';', 'O', 'v', 'e', 'r', 'w',
    'r', 'i', 't', 'e', 32, 'e', 'x', 'i', 's', 't', 'i', 'n', 'g', '?',
    0,
    /*  !--FIELD BOOLEAN 315 NAME=overwrite TRUE=yes FALSE=no VALUE=0        */
    0, 16, 14, 0, 1, '3', '1', '5', 0, '0', 0, 'y', 'e', 's', 0, 'n',
    'o', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 18, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 'r',
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 1, 216,
    /*  !--FIELD TEXTUAL 316 NAME=L_ ...  VALUE="Select IP address:"         */
    0, 30, 10, 6, 1, 0, 18, 0, 18, '3', '1', '6', 0, 'S', 'e', 'l', 'e',
    'c', 't', 32, 'I', 'P', 32, 'a', 'd', 'd', 'r', 'e', 's', 's', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '*',
    /*  !--FIELD SELECT 317 NAME=hos ... pe=dynamic 0="No selection"         */
    0, 24, 15, 0, 1, 1, 0, '3', '1', '7', 0, '0', 0, 'N', 'o', 32, 's',
    'e', 'l', 'e', 'c', 't', 'i', 'o', 'n', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 1, 216,
    /*  !--FIELD TEXTUAL 318 NAME=L_ ... ="Or, enter DNS host name:"         */
    0, 36, 10, 6, 1, 0, 24, 0, 24, '3', '1', '8', 0, 'O', 'r', ',', 32,
    'e', 'n', 't', 'e', 'r', 32, 'D', 'N', 'S', 32, 'h', 'o', 's', 't',
    32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '*',
    /*  !--FIELD TEXTUAL 319 NAME=host-name SIZE=50 MAX=? VALUE=""           */
    0, 12, 10, 0, 1, 0, '2', 0, '2', '3', '1', '9', 0, 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 2, 189,
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 'r',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 1, 216,
    /*  !--FIELD TEXTUAL 320 NAME=L_ ... ="Web page root directory:"         */
    0, 36, 10, 6, 1, 0, 24, 0, 24, '3', '2', '0', 0, 'W', 'e', 'b', 32,
    'p', 'a', 'g', 'e', 32, 'r', 'o', 'o', 't', 32, 'd', 'i', 'r', 'e',
    'c', 't', 'o', 'r', 'y', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '*',
    /*  !--FIELD TEXTUAL 321 NAME=webpages SIZE=50 MAX=? VALUE=""            */
    0, 12, 10, 0, 1, 0, '2', 0, '2', '3', '2', '1', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 1, 216,
    /*  !--FIELD TEXTUAL 322 NAME=L_ ...  VALUE="CGI-bin directory:"         */
    0, 30, 10, 6, 1, 0, 18, 0, 18, '3', '2', '2', 0, 'C', 'G', 'I', 45,
    'b', 'i', 'n', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o', 'r', 'y', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '*',
    /*  !--FIELD TEXTUAL 323 NAME=cgi-bin SIZE=50 MAX=? VALUE=""             */
    0, 12, 10, 0, 1, 0, '2', 0, '2', '3', '2', '3', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 1, 216,
    /*  !--FIELD TEXTUAL 324 NAME=L_ ... VALUE="Superuser password:"         */
    0, 31, 10, 6, 1, 0, 19, 0, 19, '3', '2', '4', 0, 'S', 'u', 'p', 'e',
    'r', 'u', 's', 'e', 'r', 32, 'p', 'a', 's', 's', 'w', 'o', 'r', 'd',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '*',
    /*  !--FIELD TEXTUAL 325 NAME=superuser SIZE=20 MAX=? VALUE=""           */
    0, 12, 10, 0, 1, 0, 20, 0, 20, '3', '2', '5', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 1, 216,
    /*  !--FIELD TEXTUAL 326 NAME=L_ ... ALUE="Use shared logfiles?"         */
    0, 32, 10, 6, 1, 0, 20, 0, 20, '3', '2', '6', 0, 'U', 's', 'e', 32,
    's', 'h', 'a', 'r', 'e', 'd', 32, 'l', 'o', 'g', 'f', 'i', 'l', 'e',
    's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '*',
    /*  !--FIELD BOOLEAN 327 NAME=sharelogs TRUE=yes FALSE=no VALUE=0        */
    0, 16, 14, 0, 1, '3', '2', '7', 0, '0', 0, 'y', 'e', 's', 0, 'n',
    'o', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 2, 189,
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  <TR><TD></TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                      */
    0, 48, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P', 32, 'W', 'I', 'D', 'T',
    'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION create  LABEL="Cre ... NT=define_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 0, 0, 0, 0, 0, 0, 'c', 'r', 'e', 'a', 't',
    'e', 0, 'C', 'r', 'e', 'a', 't', 'e', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 215,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '^',
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 'r',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 4, 1, 0, 0, 'y',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 150, 0, 13,
    /*  #(date)<BR>#(time)                                                   */
    0, 19, 0, '#', '(', 'd', 'a', 't', 'e', ')', '<', 'B', 'R', '>',
    '#', '(', 't', 'i', 'm', 'e', ')',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, '5',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 150, 0, 13,
    /*  Copyright &#169 1997 iMatix<BR>Powered by iMatix Studio 1.0          */
    0, 60, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 32, 'i', 'M', 'a', 't', 'i',
    'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r', 'e', 'd', 32, 'b',
    'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S', 't', 'u', 'd', 'i',
    'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '^',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm25_fields [] = {
    { 0, 88, 80 },                      /*  message_to_user                 */
    { 82, 512, 28 },                    /*  L_host-file                     */
    { 112, 596, 40 },                   /*  host-file                       */
    { 154, 638, 31 },                   /*  L_overwrite                     */
    { 187, 683, 1 },                    /*  overwrite                       */
    { 190, 746, 18 },                   /*  L_host-addr                     */
    { 210, 784, 3 },                    /*  host-addr                       */
    { 215, 822, 24 },                   /*  L_host-name                     */
    { 241, 866, 50 },                   /*  host-name                       */
    { 293, 904, 24 },                   /*  L_webpages                      */
    { 319, 948, 50 },                   /*  webpages                        */
    { 371, 974, 18 },                   /*  L_cgi-bin                       */
    { 391, 1012, 50 },                  /*  cgi-bin                         */
    { 443, 1038, 19 },                  /*  L_superuser                     */
    { 464, 1077, 20 },                  /*  superuser                       */
    { 486, 1103, 20 },                  /*  L_sharelogs                     */
    { 508, 1143, 1 },                   /*  sharelogs                       */
    { 511, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_host_file_a        ;
    char   l_host_file          [28 + 1];
    byte   host_file_a          ;
    char   host_file            [40 + 1];
    byte   l_overwrite_a        ;
    char   l_overwrite          [31 + 1];
    byte   overwrite_a          ;
    char   overwrite            [1 + 1];
    byte   l_host_addr_a        ;
    char   l_host_addr          [18 + 1];
    byte   host_addr_a          ;
    char   host_addr            [3 + 1];
    byte   l_host_name_a        ;
    char   l_host_name          [24 + 1];
    byte   host_name_a          ;
    char   host_name            [50 + 1];
    byte   l_webpages_a         ;
    char   l_webpages           [24 + 1];
    byte   webpages_a           ;
    char   webpages             [50 + 1];
    byte   l_cgi_bin_a          ;
    char   l_cgi_bin            [18 + 1];
    byte   cgi_bin_a            ;
    char   cgi_bin              [50 + 1];
    byte   l_superuser_a        ;
    char   l_superuser          [19 + 1];
    byte   superuser_a          ;
    char   superuser            [20 + 1];
    byte   l_sharelogs_a        ;
    char   l_sharelogs          [20 + 1];
    byte   sharelogs_a          ;
    char   sharelogs            [1 + 1];
    byte   create_a;
    byte   cancel_a;
    } XIADM25_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm25 = {
    xiadm25_blocks,
    xiadm25_fields,
    72,                                 /*  Number of blocks in form        */
    17,                                 /*  Number of fields in form        */
    2,                                  /*  Number of actions in form       */
    511,                                /*  Size of fields                  */
    "xiadm25",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
