/*---------------------------------------------------------------------------
 *  xiadm23.h - HTML form definition
 *
 *  Generated 1998/06/24, 15:57:12 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM23__
#define __FORM_XIADM23__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM23_MESSAGE_TO_USER             0
#define XIADM23_L_STARTUP                   1
#define XIADM23_STARTUP                     2
#define XIADM23_L_REFRESH                   3
#define XIADM23_REFRESH                     4
#define XIADM23_L_RATE                      5
#define XIADM23_RATE                        6
#define XIADM23_L_CAPTURE                   7
#define XIADM23_CAPTURE                     8
#define XIADM23_L_FILENAME                  9
#define XIADM23_FILENAME                    10
#define XIADM23_L_APPEND                    11
#define XIADM23_APPEND                      12
#define XIADM23_L_JAVASCRIPT                13
#define XIADM23_JAVASCRIPT                  14
#define XIADM23_L_NONAME18                  15

/*  This table contains each block in the form                               */

static byte xiadm23_blocks [] = {
    /*  <HTML><HEAD><TITLE>Console Properties</TITLE>                        */
    0, 47, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'C', 'o', 'n', 's', 'o',
    'l', 'e', 32, 'P', 'r', 'o', 'p', 'e', 'r', 't', 'i', 'e', 's', '<',
    '/', 'T', 'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 134, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  Console Properties                                                   */
    0, 20, 0, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'P', 'r', 'o', 'p',
    'e', 'r', 't', 'i', 'e', 's', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 52, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD ALIGN=LEFT>                                                      */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>', 10,
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 4, 1, 0, 1, 210,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f316 NAME=L_startup VALUE="Start-up page:"          */
    0, 28, 10, 6, 1, 0, 0, 14, 0, 14, 'f', '3', '1', '6', 0, 'S', 't',
    'a', 'r', 't', 45, 'u', 'p', 32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD RADIO f317 NAME=sta ... 0 DETAIL=0 VALUE=0 NULL="?"         */
    0, 25, 16, 0, 1, 0, 0, 'f', '3', '1', '7', 0, '0', 0, 'N', 'o', 32,
    's', 'e', 'l', 'e', 'c', 't', 'i', 'o', 'n', 0,
    /*  !--FIELD RADIO f317 OPTION="Main menu"                               */
    0, 14, 17, 2, 237, 1, 'M', 'a', 'i', 'n', 32, 'm', 'e', 'n', 'u', 0,
    /*  !--FIELD RADIO f317 OPTION="Basic config"                            */
    0, 17, 17, 2, 237, 2, 'B', 'a', 's', 'i', 'c', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 0,
    /*  !--FIELD RADIO f317 OPTION="VHost config"                            */
    0, 17, 17, 2, 237, 3, 'V', 'H', 'o', 's', 't', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 0,
    /*  !--FIELD RADIO f317 OPTION="Console page"                            */
    0, 17, 17, 2, 237, 4, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'p',
    'a', 'g', 'e', 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f318 NAME=L ...  VALUE="Automatic refresh?"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '3', '1', '8', 0, 'A', 'u',
    't', 'o', 'm', 'a', 't', 'i', 'c', 32, 'r', 'e', 'f', 'r', 'e', 's',
    'h', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--FIELD BOOLEAN f319 NAME=refresh TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '1', '9', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f320 NAME=L_rate VALUE=" - refresh every:"          */
    0, 31, 10, 6, 1, 0, 0, 17, 0, 17, 'f', '3', '2', '0', 0, 32, 45, 32,
    'r', 'e', 'f', 'r', 'e', 's', 'h', 32, 'e', 'v', 'e', 'r', 'y', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--FIELD NUMERIC f321 NAME=r ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, 'f', '3', '2', '1',
    0, 0,
    /*  seconds                                                              */
    0, 9, 0, 's', 'e', 'c', 'o', 'n', 'd', 's', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f322 NAME=L_capture VALUE="Capture console?"        */
    0, 30, 10, 6, 1, 0, 0, 16, 0, 16, 'f', '3', '2', '2', 0, 'C', 'a',
    'p', 't', 'u', 'r', 'e', 32, 'c', 'o', 'n', 's', 'o', 'l', 'e', '?',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--FIELD BOOLEAN f323 NAME=capture TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '2', '3', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f324 NAME=L ... VALUE=" - capture to file:"         */
    0, 33, 10, 6, 1, 0, 0, 19, 0, 19, 'f', '3', '2', '4', 0, 32, 45, 32,
    'c', 'a', 'p', 't', 'u', 'r', 'e', 32, 't', 'o', 32, 'f', 'i', 'l',
    'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--FIELD TEXTUAL f325 NAME=f ... =15 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 15, 0, '(', 'f', '3', '2', '5', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f326 NAME=L_append VALUE=" - append data?"          */
    0, 29, 10, 6, 1, 0, 0, 15, 0, 15, 'f', '3', '2', '6', 0, 32, 45, 32,
    'a', 'p', 'p', 'e', 'n', 'd', 32, 'd', 'a', 't', 'a', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--FIELD BOOLEAN f327 NAME=append TRUE=yes FALSE=no VALUE=0          */
    0, 17, 14, 0, 1, 'f', '3', '2', '7', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f328 NAME=L ... ipt VALUE="Use JavaScript?"         */
    0, 29, 10, 6, 1, 0, 0, 15, 0, 15, 'f', '3', '2', '8', 0, 'U', 's',
    'e', 32, 'J', 'a', 'v', 'a', 'S', 'c', 'r', 'i', 'p', 't', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--FIELD BOOLEAN f329 NAME=j ... t TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '2', '9', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 19, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>', 10,
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, '{',
    /*  !--FIELD TEXTUAL f330 NAME=L ... UE="Actions for this page:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '3', '3', '0', 0, 'A', 'c',
    't', 'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's',
    32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 194,
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 2, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 'Q',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm23_fields [] = {
    { 0, 110, 80 },                     /*  message_to_user                 */
    { 82, 676, 14 },                    /*  l_startup                       */
    { 98, 749, 3 },                     /*  startup                         */
    { 103, 869, 18 },                   /*  l_refresh                       */
    { 123, 909, 1 },                    /*  refresh                         */
    { 126, 940, 17 },                   /*  l_rate                          */
    { 145, 979, 5 },                    /*  rate                            */
    { 152, 1023, 16 },                  /*  l_capture                       */
    { 170, 1061, 1 },                   /*  capture                         */
    { 173, 1092, 19 },                  /*  l_filename                      */
    { 194, 1133, 40 },                  /*  filename                        */
    { 236, 1161, 15 },                  /*  l_append                        */
    { 253, 1198, 1 },                   /*  append                          */
    { 256, 1229, 15 },                  /*  l_javascript                    */
    { 273, 1266, 1 },                   /*  javascript                      */
    { 276, 1325, 22 },                  /*  l_noname18                      */
    { 300, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_startup_a          ;
    char   l_startup            [14 + 1];
    byte   startup_a            ;
    char   startup              [3 + 1];
    byte   l_refresh_a          ;
    char   l_refresh            [18 + 1];
    byte   refresh_a            ;
    char   refresh              [1 + 1];
    byte   l_rate_a             ;
    char   l_rate               [17 + 1];
    byte   rate_a               ;
    char   rate                 [5 + 1];
    byte   l_capture_a          ;
    char   l_capture            [16 + 1];
    byte   capture_a            ;
    char   capture              [1 + 1];
    byte   l_filename_a         ;
    char   l_filename           [19 + 1];
    byte   filename_a           ;
    char   filename             [40 + 1];
    byte   l_append_a           ;
    char   l_append             [15 + 1];
    byte   append_a             ;
    char   append               [1 + 1];
    byte   l_javascript_a       ;
    char   l_javascript         [15 + 1];
    byte   javascript_a         ;
    char   javascript           [1 + 1];
    byte   l_noname18_a         ;
    char   l_noname18           [22 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   defaults_a;
    byte   undo_a;
    } XIADM23_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm23 = {
    xiadm23_blocks,
    xiadm23_fields,
    79,                                 /*  Number of blocks in form        */
    16,                                 /*  Number of fields in form        */
    4,                                  /*  Number of actions in form       */
    300,                                /*  Size of fields                  */
    "xiadm23",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
