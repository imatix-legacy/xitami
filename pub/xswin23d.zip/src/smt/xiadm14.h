/*---------------------------------------------------------------------------
 *  xiadm14.h - HTML form definition
 *
 *  Generated 1998/06/24, 15:57:12 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM14__
#define __FORM_XIADM14__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define CGI_ALIAS_LIST_MAX                  10
#define XIADM14_MESSAGE_TO_USER             0
#define XIADM14_L_CGI_ALIAS_NAME            1
#define XIADM14_L_CGI_ALIAS_PATH            2
#define XIADM14_KEY                         3
#define XIADM14_CGI_ALIAS_NAME              4
#define XIADM14_CGI_ALIAS_PATH              5
#define XIADM14_L_NONAME12                  6
#define XIADM14_CGI_ALIAS_LIST              7

/*  This table contains each block in the form                               */

static byte xiadm14_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - CGI Aliases</TITLE>                   */
    0, 52, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'C', 'G', 'I', 32, 'A', 'l', 'i',
    'a', 's', 'e', 's', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 158, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  #(config) - CGI Aliases                                              */
    0, 25, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'C', 'G', 'I', 32, 'A', 'l', 'i', 'a', 's', 'e', 's', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 48, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 21, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>', 10,
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  <TABLE NOWRAP WIDTH= >                                               */
    0, 24, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, 'W', 'I', 'D', 'T', 'H', '=', 32, '>', 10,
    /*  <TR>                                                                 */
    0, 6, 0, '<', 'T', 'R', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 35, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f202 NAME=L ... ias-name VALUE="CGI alias:"         */
    0, 24, 10, 6, 1, 0, 0, 10, 0, 10, 'f', '2', '0', '2', 0, 'C', 'G',
    'I', 32, 'a', 'l', 'i', 'a', 's', ':', 0,
    /*  </TH>                                                                */
    0, 7, 0, '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 222,
    /*  !--FIELD TEXTUAL f203 NAME=L ... ath VALUE="Points to path:"         */
    0, 29, 10, 6, 1, 0, 0, 15, 0, 15, 'f', '2', '0', '3', 0, 'P', 'o',
    'i', 'n', 't', 's', 32, 't', 'o', 32, 'p', 'a', 't', 'h', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, 24,
    /*  !--REPEAT cgi_alias_list  ROWS=10                                    */
    0, 7, 4, 0, 7, 0, 12, 0, 10,
    /*  </TR>                                                                */
    0, 7, 0, '<', '/', 'T', 'R', '>', 10,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 177,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f204 NAME=key SIZE=20 MAX=? UPPER=0 VALUE=""        */
    0, 14, 10, 4, 10, 0, 0, 20, 0, 20, 'f', '2', '0', '4', 0, 0,
    /*  </TD>                                                                */
    0, 7, 0, '<', '/', 'T', 'D', '>', 10,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 28, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    10,
    /*  !--FIELD TEXTUAL f205 NAME=c ... E=20 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 10, 0, 0, 20, 0, 20, 'f', '2', '0', '5', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 148,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 3, 157,
    /*  !--FIELD TEXTUAL f206 NAME=c ... =50 MAX=80 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 10, 0, 0, '2', 0, 'P', 'f', '2', '0', '6', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 148,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 'U',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 4, 1, 0, 1, 244,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f207 NAME=L ... UE="Actions for this page:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '2', '0', '7', 0, 'A', 'c',
    't', 'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's',
    32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 2, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 4, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 5, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't', 0,
    'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  !--FIELD NUMERIC cgi_alias_list SIZE=4 VALUE=10                      */
    0, 31, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'c', 'g', 'i', '_',
    'a', 'l', 'i', 'a', 's', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm14_fields [] = {
    { 0, 115, 80 },                     /*  message_to_user                 */
    { 82, 766, 10 },                    /*  l_cgi_alias_name                */
    { 94, 807, 15 },                    /*  l_cgi_alias_path                */
    { 111, 900, 20 },                   /*  key                             */
    { 331, 955, 20 },                   /*  cgi_alias_name                  */
    { 551, 983, 80 },                   /*  cgi_alias_path                  */
    { 1371, 1064, 22 },                 /*  l_noname12                      */
    { 1395, 1264, 4 },                  /*  cgi_alias_list                  */
    { 1401, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_cgi_alias_name_a   ;
    char   l_cgi_alias_name     [10 + 1];
    byte   l_cgi_alias_path_a   ;
    char   l_cgi_alias_path     [15 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [20 + 1];
    byte   cgi_alias_name_a     [10] ;
    char   cgi_alias_name       [10] [20 + 1];
    byte   cgi_alias_path_a     [10] ;
    char   cgi_alias_path       [10] [80 + 1];
    byte   l_noname12_a         ;
    char   l_noname12           [22 + 1];
    byte   cgi_alias_list_a     ;
    char   cgi_alias_list       [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM14_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm14 = {
    xiadm14_blocks,
    xiadm14_fields,
    63,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    6,                                  /*  Number of actions in form       */
    1401,                               /*  Size of fields                  */
    "xiadm14",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
