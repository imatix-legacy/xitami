/*===========================================================================
 *                                                                           
 *  ggeval.c    GSLgen schema evaluator
 *                                                                           
 *  Written:    99/02/28    iMatix <tools@imatix.com>                        
 *  Revised:    99/10/23
 *                                                                            
 *  Copyright (c) 1996-99 iMatix Corporation                                  
 *                                                                            
 *  This program is free software; you can redistribute it and/or modify      
 *  it under the terms of the GNU General Public License as published by      
 *  the Free Software Foundation; either version 2 of the License, or         
 *  (at your option) any later version.                                       
 *                                                                            
 *  This program is distributed in the hope that it will be useful,           
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             
 *  GNU General Public License for more details.                              
 *                                                                            
 *  You should have received a copy of the GNU General Public License         
 *  along with this program; if not, write to the Free Software               
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 
 *===========================================================================*/

#include "sfl.h"                        /*  Universal include file           */
#include "ggpars.h"                     /*  Schema parser header file        */
#include "ggeval.h"                     /*  Include header file              */


/*- Function prototypes -----------------------------------------------------*/

static int  evaluate_substitute_node (SCHEMA_NODE *node);
static void copy_result              (SCHEMA_NODE *dest, SCHEMA_NODE *source);
static void pretty_print             (char *text,
				      SCHEMA_NODE *pretty,
				      char *example);
static void strneat                  (char *text);
static void undefined_expression_error
                                     (SCHEMA_NODE *node);
static int  evaluate_literal_node    (SCHEMA_NODE *node);
static int  evaluate_operand_node    (SCHEMA_NODE *node);
static int  evaluate_symbol_node     (SCHEMA_NODE *node);
static int  evaluate_member_node     (SCHEMA_NODE *node);
static int  evaluate_function_node   (SCHEMA_NODE *node);
static int  evaluate_count_function  (SCHEMA_NODE *node);
static Bool verify_function_parameters
                                     (SCHEMA_NODE *fn_node, int min, int max);
static Bool validate_identifier_as_parameter
                                     (SCHEMA_NODE *node,
                                      char **scope, char **name);
static int  evaluate_env_function    (SCHEMA_NODE *node);
static int  evaluate_index_function  (SCHEMA_NODE *node);
static int  evaluate_name_function   (SCHEMA_NODE *node);
static int  evaluate_exists_function (SCHEMA_NODE *node);
static int  evaluate_timestamp_function (SCHEMA_NODE *node);
static int  evaluate_length_function (SCHEMA_NODE *node);
static int  evaluate_defined_function (SCHEMA_NODE *node);
static int  evaluate_substr_function (SCHEMA_NODE *node);
static SCHEMA_NODE *function_parameter 
                                     (SCHEMA_NODE *node, int n);
static Bool node_is_countable        (SCHEMA_NODE *node);
static int  evaluate_trim_function   (SCHEMA_NODE *node);
static int  evaluate_justify_function (SCHEMA_NODE *node);
static int  evaluate_operator        (SCHEMA_NODE *node);
static int  evaluate_text_node       (SCHEMA_NODE *node);

/*- Functions ---------------------------------------------------------------*/

int evaluate_schema (SCHEMA_NODE *node)
{
    int
        result;

    if (node)
      {
        result = evaluate_schema_node (node);
        if (result)
            return result;
        if (node-> result_type == TYPE_UNDEFINED)
            undefined_expression_error (node);
      }
    return 0;
}


int
evaluate_schema_node (SCHEMA_NODE *node)
{
    if (node == NULL)
        return 0;

    node-> indent = node-> spaces;
    if (node-> type == GG_SUBSTITUTE)
       if (evaluate_substitute_node (node) != 0)
           return -1;

    if (node-> type == GG_LITERAL)
        if (evaluate_literal_node (node) != 0)
           return -1;

    if (node-> type == GG_OPERAND)
        if (evaluate_operand_node (node) != 0)
           return -1;

    if (node-> type  == GG_SYMBOL)
        if (evaluate_symbol_node (node) != 0)
           return -1;

    if (node-> type  == GG_MEMBER)
        if (evaluate_member_node (node) != 0)
           return -1;

    if (node-> type == GG_FUNCTION)
        if (evaluate_function_node (node) != 0)
             return -1;

    if (node-> type == GG_OPERATOR)
        if (evaluate_operator (node) != 0)
             return -1;

    if (node-> type == GG_TEXT)
        if (evaluate_text_node (node) != 0)
             return -1;

    if (node-> line_break)
        node-> shuffle_cnt = 0;
    else
        node-> shuffle_cnt = strlen (string_result (node))
                           - node-> length;
    return 0;
}


static int
evaluate_substitute_node (SCHEMA_NODE *node)
{
    char
        *format,
        buffer [LINE_MAX + 1];
    int
        length;

    if (evaluate_schema_node (node-> op1) != 0)
        return -1;
    if (evaluate_schema_node (node-> op3) != 0)
        return -1;
    if (evaluate_schema_node (node-> pretty) != 0)
        return -1;
    if (evaluate_schema_node (node-> format) != 0)
        return -1;

    if ((node-> op1) ? (node-> op1-> result_type != TYPE_UNDEFINED) : FALSE)
      {
        copy_result (node, node-> op1);
        
        /*  Only match the case if ignorecase is TRUE and the expression */
        /*  consists of a single identifier.                             */
        string_result (node);
        if ((ignorecase)
        &&  (node-> op1-> type == GG_SYMBOL)
        &&  (node-> op1-> op1))
            pretty_print (node-> result_s, node-> pretty, 
                          string_result (node-> op1-> op1));
        else
            pretty_print (node-> result_s, node-> pretty, NULL);
      }
    else
    if (node-> op3)
      {
        copy_result (node, node-> op3);
        if (node-> op3-> result_type == TYPE_UNDEFINED)
            node-> culprit = node-> op3-> culprit;
      }
    else
      {
        node-> result_type = TYPE_UNDEFINED;
        if (node-> op1)
            node-> culprit = node-> op1-> culprit;
      }

    if (node-> format)
      {
        if (strchr (string_result (node-> format), '%') == NULL)
          {
            format = mem_alloc (strlen (node-> format-> result_s) + 2);
            strcpy (format, "%");
            strcat (format, node-> format-> result_s);
          }
        else
            format = mem_strdup (node-> format-> result_s);

        length = snprintf (buffer, LINE_MAX, format, string_result (node));
        mem_free (format);
        if (length == -1)
            gg_report_error ('W', "Output line too long.");
            
        mem_free (node-> result_s);
        node-> result_s = mem_alloc (length + 1);
        ASSERT (node-> result_s);
        strcpy (node-> result_s, buffer);
        node-> result_type = TYPE_STRING;
      }
    return 0;
}


static void
copy_result (SCHEMA_NODE *dest, SCHEMA_NODE *source)
{
    dest-> result_type = source-> result_type;
    dest-> result_s    = mem_strdup (source-> result_s);
    dest-> result_n    = source-> result_n;
}


/*  pretty_print: Reformats a string according to a format string consisting */
/*  of a comma-separated series of specifiers.  Currently accepted formats:  */
/*         lower - lower case                                                */
/*         UPPER - UPPER CASE                                                */
/*         Neat  - Neat Case                                                 */
/*         c     - Valid_c_identifier                                        */
/*         COBOL - VALID-COBOL-IDENTIFIER                                    */
/*                                                                           */
/*  If no case modifier is provided and pretty is not empty and the expr-    */
/*  is a single identifier, its case is used as an example to match for      */
/*  lower, upper or neat case.                                               */

static void
pretty_print (char *text, SCHEMA_NODE *pretty, char *example)
{
    char
        *tokens,
        *token,
        *c;
    Bool
        use_example;

    ASSERT (text);

    if (*text == 0)                     /* Do nothing to null string         */
        return;

    use_example = (example != NULL);

    if (pretty)
      {
        if (strlen (string_result (pretty)) == 0)
            use_example = FALSE;

        tokens = mem_strdup (pretty-> result_s);
        token = strtok (tokens, ", ");
        while (token)
          {
            strlwc (token);
            if (streq (token, "lower"))
              {
                use_example = FALSE;
                strlwc (text);
              }
            else
            if (streq (token, "upper"))
              {
                use_example = FALSE;
                strupc (text);
              }
            else
            if (streq (token, "neat"))
              {
                use_example = FALSE;
                strneat (text);
              }
            else
            if (streq (token, "c"))
              {
                c = text;
                if (!isalpha (*c))
                    *c = '_';
                
                while (*c)
                  {
                    if (!(isalpha (*c) || isdigit (*c)))
                        *c = '_';

                    c++;
                  }
              }
            else
            if (streq (token, "cobol"))
              {
                c = text;
                if (!isalpha (*c))
                    *c = '-';
                
                while (*c)
                  {
                    if (!(isalpha (*c) || isdigit (*c)))
                        *c = '-';

                    c++;
                  }
              }

            token = strtok (NULL, ", ");
          }
        mem_free (tokens);
      }

    if ((use_example)
    &&  (strlen (example) > 1))
      {
        c = example;

        if (isupper (*c))
            while ((isupper (*c) || !isalpha (*c)) && (*c))
                c++;

        if (*c == 0)
            strupc (text);
        else
        if (c == example + 1)
          {
            if (islower (*c))
              {
                while ((islower (*c) || !isalpha (*c)) && (*c))
                    c++;
                if (!isupper (*c))
                    strneat (text);
              }
          }
        else
            if (c == example)
              {
                if (islower (*c))
                    while ((islower (*c) || !isalpha (*c)) && (*c))
                        c++;

                if (*c == 0)
                    strlwc (text);
              }
      }
}


static void
strneat (char *text)
{
    char
        *c;

    c = text;
    while (*c)
      {
        while ((!isalpha (*c)) && (*c))
            c++;
        *c = toupper (*c);
        c++;
        while (isalpha (*c) && (*c))
          {
            *c = tolower (*c);
            c = c++;
          }
      }
}


static void
undefined_expression_error (SCHEMA_NODE *node)
{
    char 
        *scope = "",
        *point = ".";
    SCHEMA_NODE
        *culprit;

    culprit = node-> culprit;
    if ((culprit) ? culprit-> type == GG_SYMBOL : FALSE)
      {
        if (culprit-> op2)
            scope = string_result (culprit-> op2);

        /*  Print point except if there is identifier and no scope  */
        if (culprit-> op1 && ! culprit-> op2)
            point = "";
        gg_report_error ('W', "Undefined identifier: %s%s%s", 
                      scope, point,
                      (culprit-> op1) ? string_result (culprit-> op1) : "");
      }
    else
        gg_report_error ('W', "Undefined expression.");
}


static int
evaluate_literal_node (SCHEMA_NODE *node)
{
    if (node-> op1)
      {
        if (evaluate_schema_node (node-> op1) != 0)
            return -1;

        node-> result_type = node-> op1-> result_type;
        if (node-> op1-> result_s)
          {
            node-> result_s = mem_alloc (node-> op1-> indent +
                                         strlen (node-> op1-> result_s) + 1);
            memset (node-> result_s, ' ', node-> op1-> indent);
            strcpy (node-> result_s + node-> op1-> indent, 
                    node-> op1-> result_s);
          }
        node-> result_n    = node-> op1-> result_n;
        node-> culprit     = node-> op1-> culprit;
      }
    else
        node-> result_type = TYPE_UNDEFINED;

    return 0;
}


static int
evaluate_operand_node (SCHEMA_NODE *node)
{
    SCHEMA_NODE
        *expr_root = NULL;
    int
        rc;

    if (node-> op1)
      {
        if (evaluate_schema_node (node-> op1) != 0)
            return -1;
       
        if (node-> op1-> result_type == TYPE_UNDEFINED)
          {
            gg_report_error ('E', "Undefined operand.");
            return -1;
          }

        expr_root = gg_parse_expression (string_result (node-> op1));
        if (expr_root)
          {
            rc = evaluate_schema_node (expr_root);
            if (rc == 0)
              {
                node-> result_type = expr_root-> result_type;
                node-> result_s    = mem_strdup (expr_root-> result_s);
                node-> result_n    = expr_root-> result_n;
                node-> indent      = expr_root-> indent;
                node-> culprit     = expr_root-> culprit;
                
                if (node-> result_type == TYPE_UNDEFINED)
                    undefined_expression_error (expr_root);
              }
            gg_free (expr_root);
            return rc;
          }
        else
          {
            gg_free (expr_root);
            gg_report_error ('E', "Error in operand: %s", 
                                  node-> op1-> result_s);
            gg_report_error ('E', "%s", gg_error ());
            return -1;
          }
      }
    else
        node-> result_type = TYPE_UNDEFINED;

    return 0;
}


static int
evaluate_symbol_node (SCHEMA_NODE *node)
{
    char
        *scope = NULL,
        *name  = NULL;

    if (node-> op1)
      {
        if (evaluate_schema_node (node-> op1) != 0)
            return -1;

        name = string_result (node-> op1);
      }
    if (node-> op2)
      {
        if (evaluate_schema_node (node-> op2) != 0)
            return -1;

        scope = string_result (node-> op2);
      }

    node-> result_s = mem_strdup (valueof (scope, name));
    if (node-> result_s)
        node-> result_type = TYPE_STRING;
    else
      {
        node-> result_type = TYPE_UNDEFINED;
        node-> culprit     = node;
      }

    return 0;
}


static int
evaluate_member_node (SCHEMA_NODE *node)
{
    char
        *item  = NULL;
    XML_ITEM
        *xml_item,
        *xml_child;

    ASSERT (node-> op1);
    if (evaluate_schema_node (node-> op1) != 0)
        return -1;

    item = string_result (node-> op1);

    if (node-> op2)
      {
        if (evaluate_schema_node (node-> op2) != 0)
            return -1;

	xml_item = lookup_scope_xml (string_result (node-> op2));
      }
    else
        xml_item = last_scope_xml ();

    if (xml_item)
      {
        FORCHILDREN (xml_child, xml_item)
            if (ignorecase)
              {
                if (lexcmp (item, xml_item_name (xml_child)) == 0)
                  {
                    node-> result_type = TYPE_STRING;
                    node-> result_s    = mem_strdup
                                             (compound_item_value (xml_child));
                    return 0;
                  }
              }
            else
              {
                if (streq (item, xml_item_name (xml_child)))
                  {
                    node-> result_type = TYPE_STRING;
                    node-> result_s    = mem_strdup
                                             (compound_item_value (xml_child));
                    return 0;
                  }
              }
      }
    return 0;
}

static int
evaluate_function_node (SCHEMA_NODE *node)
{
    if (evaluate_schema_node (node-> op1) != 0)
        return -1;

    strlwc (string_result (node-> op1));
    if (streq (node-> op1-> result_s, "count"))
        return evaluate_count_function (node);
    else
    if (streq (node-> op1-> result_s, "env"))
        return evaluate_env_function (node);
    else
    if (streq (node-> op1-> result_s, "index"))
        return evaluate_index_function (node);
    else
    if (streq (node-> op1-> result_s, "name"))
        return evaluate_name_function (node);
    else
    if (streq (node-> op1-> result_s, "exists"))
        return evaluate_exists_function (node);
    else
    if (streq (node-> op1-> result_s, "timestamp"))
        return evaluate_timestamp_function (node);
    else
    if (streq (node-> op1-> result_s, "length"))
        return evaluate_length_function (node);
    else
    if (streq (node-> op1-> result_s, "defined"))
        return evaluate_defined_function (node);
    else
    if (streq (node-> op1-> result_s, "substr"))
        return evaluate_substr_function (node);
    else
    if (streq (node-> op1-> result_s, "trim"))
        return evaluate_trim_function (node);
    else
    if (streq (node-> op1-> result_s, "justify"))
        return evaluate_justify_function (node);
    else
      {
        gg_report_error ('E', "Unknown function: %s", node-> op1-> result_s);
        return -1;
      }
    return 0;
}                    


static int
evaluate_count_function (SCHEMA_NODE *node)
{
    long
        n,
        index;
    SCHEMA_NODE
        *identifier,
        *condition;
    char
        *scope,
        *name,
        *xml_name;
    FOR_BLOCK
        *from_block,
        *for_block;
    FOR_ITEM
        *for_item;
    XML_ITEM
        *xml_item;
    Bool
        error = FALSE;

    if (!verify_function_parameters (node-> op2, 1, 2))
        return -1;

    identifier = function_parameter (node-> op2, 1);
    condition  = function_parameter (node-> op2, 2);
    if (!validate_identifier_as_parameter (identifier, &scope, &name))
        return -1;

    if (scope)
      {
        from_block = lookup_for_block (scope);
        if (! from_block)
          {
            gg_report_error ('E', "Unknown .for block: %s", scope);
            return -1;
          }
      }
    else
        from_block = last_for_block ();

    for_block = create_for_block ("count");
    
    n = 0;
    index = 0;
    xml_item = xml_first_child (from_block-> scope_block-> xml_item);
    while (xml_item)
      {
        while (xml_item)
          {
            xml_name = xml_item_name (xml_item);
            if (xml_name && name)
              {
                if (ignorecase)
                  {
                    if (lexcmp (xml_name, name) == 0)
                        break;
                  }
                else
                  {
                    if (streq (xml_name, name))
                        break;
                  }
              }
            else
                /*  Take all named children; others are part of value  */
                if (xml_name && (! name))
                    break;

            xml_item = xml_next_sibling (xml_item);
          }
        
        if (xml_item)
          {
            index++;
            if (condition)
              {
                for_item = create_for_item (for_block, xml_item, index);
                for_block-> for_item               = for_item;
                for_block-> scope_block-> xml_item = xml_item;
                if (evaluate_schema (condition) != 0)
                  {
                    error = TRUE;
                    break;
                  }
                number_result (condition);
                if ((condition-> result_type == TYPE_NUMBER)
                &&  (condition-> result_n    != 0))
                    n++;
                destroy_for_item (for_item);
                gg_clean (condition);
              }
            else
                n++;
            
            xml_item = xml_next_sibling (xml_item);
          }
      }
    destroy_for_block ();
    
    if (error)
        return -1;

    node-> result_type = TYPE_NUMBER;
    node-> result_n    = n;
    return 0;
}


static Bool
verify_function_parameters (SCHEMA_NODE *fn_node, int min, int max)
{
    int
        count;
    SCHEMA_NODE
        *node;

    count = 0;
    node = fn_node;

    if (node)
        count++;
    while (node != NULL)
      {
        if ((node-> type     == GG_OPERATOR)
        &&  (node-> operator == OP_NEXT_ARG))
          {
            count++;
            node = node-> op1;
          }
        else
            break;
      }
    
    if (count < min)
      {
        gg_report_error ('E', "Missing function parameter.");
        return FALSE;
      }
    if (count > max)
      {
        gg_report_error ('E', "Too many function parameters.");
        return FALSE;
      }
    return TRUE;
}


static Bool
validate_identifier_as_parameter (SCHEMA_NODE *node,
                                       char **scope,
                                       char **name)
{
  if (node-> type == GG_OPERAND)
    {
      if (evaluate_schema_node (node-> op1) != 0)
          return FALSE;

      *scope = strtok (string_result (node-> op1), ".");
      *name  = strtok (NULL, " .");
      if (!*name)
        {
          *name  = *scope;
          *scope = NULL;
        }
    }
  else
  if (node-> type == GG_SYMBOL)
    {
      if (evaluate_schema_node (node-> op1) != 0)
          return FALSE;
      if (evaluate_schema_node (node-> op2) != 0)
          return FALSE;

      *scope = (node-> op2) ? string_result (node-> op2) : NULL;
      *name  = string_result (node-> op1);
    }
  else
    {
      gg_report_error ('E', "Function argument must be an identifier.");
      return FALSE;
    }
  return TRUE;
}


static int
evaluate_env_function (SCHEMA_NODE *node)
{
    if (!verify_function_parameters (node-> op2, 1, 1))
        return -1;

    if (evaluate_schema_node (node-> op2) != 0)
        return -1;
            
    if (node-> op2-> result_type != TYPE_UNDEFINED)
      {
        node-> result_type = TYPE_STRING;
        node-> result_s    = mem_strdup (getenv (string_result (node-> op2)));
      }
    else
      {
        node-> result_type = TYPE_UNDEFINED;
        node-> culprit     = node-> op2;
      }
    return 0;
}


static int
evaluate_index_function (SCHEMA_NODE *node)
{
    FOR_BLOCK
        *for_block;

    if (!verify_function_parameters (node-> op2, 0, 1))
        return -1;
    
    if (node-> op2)
        if ((node-> op2-> type == GG_OPERAND)
        ||  (node-> op2-> type == GG_SYMBOL))
          {
            if (evaluate_schema_node (node-> op2-> op1) != 0)
                return -1;

            if (node-> op2-> op2)
              {
                gg_report_error ('E', "Argument may not contain a scope.");
                return -1;
              }
            
            for_block = lookup_for_block (string_result (node-> op2-> op1));
            if (for_block == NULL)
              {
                gg_report_error ('E', "Unknown .for scope: %s",
                                  node-> op2-> op1-> result_s);
                return -1;
              }
          }
        else
          {
            gg_report_error ('E', "Argument must be a legal identifier.");
            return -1;
          }
    else
        for_block = last_for_block ();
    
    node-> result_type = TYPE_NUMBER;
    node-> result_n    = for_block-> for_item-> index;
    return 0;
}


static int
evaluate_name_function (SCHEMA_NODE *node)
{
    FOR_BLOCK
        *for_block;

    if (!verify_function_parameters (node-> op2, 0, 1))
        return -1;

    if (node-> op2)
        if ((node-> op2-> type == GG_OPERAND)
        ||  (node-> op2-> type == GG_SYMBOL))
          {
            if (evaluate_schema_node (node-> op2-> op1) != 0)
                return -1;
            
            if (node-> op2-> op2)
              {
                gg_report_error ('E', "Argument may not contain a scope.");
                return -1;
              }
            
            for_block = lookup_for_block (string_result (node-> op2-> op1));
            if (for_block == NULL)
              {
                gg_report_error ('E', "Unknown .for scope: %s",
                                 node-> op2-> op1-> result_s);
                return -1;
              }
          }
        else
          {
            gg_report_error ('E', "Argument must be a legal identifier.");
            return -1;
          }
    else
        for_block = last_for_block ();

    
    node-> result_type = TYPE_STRING;
    node-> result_s    = mem_strdup (
                             xml_item_name (for_block-> for_item-> xml_item));
    return 0;
}


static int
evaluate_exists_function (SCHEMA_NODE *node)
{
    if (!verify_function_parameters (node-> op2, 1, 1))
        return -1;
    if (evaluate_schema_node (node-> op2) != 0)
        return -1;
        

    node-> result_type = TYPE_NUMBER;
    node-> result_n    = file_exists (string_result (node-> op2)) ? 1 : 0;
    return 0;
}


static int
evaluate_timestamp_function (SCHEMA_NODE *node)
{
    char
        buffer [LINE_MAX + 1];
    time_t
        timer;

    if (!verify_function_parameters (node-> op2, 1, 1))
        return -1;
    if (evaluate_schema_node (node-> op2) != 0)
        return -1;
        
    timer = get_file_time (string_result (node-> op2));
    if (timer)
      {
        node-> result_type = TYPE_STRING;
        sprintf (buffer, "%ld%ld", timer_to_date (timer),
                 timer_to_time (timer));
        node-> result_s = mem_strdup (buffer);
        ASSERT (node-> result_s);
      }
    return 0;
}


static int
evaluate_length_function (SCHEMA_NODE *node)
{
    if (!verify_function_parameters (node-> op2, 1, 1))
        return -1;
    if (evaluate_schema_node (node-> op2) != 0)
        return -1;

    if (node-> op2)
        if (node-> op2-> result_type != TYPE_UNDEFINED)
          {
            node-> result_type = TYPE_NUMBER;
            node-> result_n    = strlen (string_result (node-> op2));
          }
        else
          {
            node-> result_type = TYPE_UNDEFINED;
            node-> culprit     = node-> op2-> culprit;
          }
    else
        node-> result_type = TYPE_UNDEFINED;

    return 0;
}


static int
evaluate_defined_function (SCHEMA_NODE *node)
{
    char
        *scope,
        *name;

    if (!verify_function_parameters (node-> op2, 1, 1))
        return -1;
    if (!validate_identifier_as_parameter (node-> op2, &scope, &name))
        return -1;

    node-> result_type = TYPE_NUMBER;
    node-> result_n    = valueof ((scope) ? scope : NULL,
                                   name) != NULL
                             ? 1 : 0;
    return 0;
}


static int
evaluate_substr_function (SCHEMA_NODE *node)
{
    SCHEMA_NODE
        *string,
        *start,
        *end,
        *len;
    unsigned long
        start_n = 0,
        end_n   = 0,
        len_n   = 0;

    if (!verify_function_parameters (node-> op2, 2, 4))
        return -1;
  
    string = function_parameter (node-> op2, 1);
    start  = function_parameter (node-> op2, 2);
    end    = function_parameter (node-> op2, 3);
    len    = function_parameter (node-> op2, 4);
    if (evaluate_schema_node (string) != 0)
        return -1;
    if (string-> result_type == TYPE_UNDEFINED)
      {
        node-> culprit = string-> culprit;
        return 0;
      }
    else
        string_result (string);
  
    if (start && end && len)
      {
        gg_report_error ('E', "Too many parameters for function 'substr'.");
        return -1;
      }
    if (!(start || end || len))
      {
        gg_report_error ('E', "Not enough parameters for function 'substr'.");
        return -1;
      }
    
    if (start)
      {
        if (evaluate_schema_node (start) != 0)
            return -1;
        if (node_is_countable (start))
            start_n = (unsigned long) start-> result_n;
        else
          {
            gg_report_error ('E', "Illegal 'Start' value: %s", 
                             string_result (start));
            return -1;
          }
      }
    if (end)
      {
        if (evaluate_schema_node (end) != 0)
            return -1;
        if (node_is_countable (end))
            end_n = (unsigned long) end-> result_n;
        else
          {
            gg_report_error ('E', "Illegal 'End' value: %s", 
                             string_result (end));
            return -1;
          }
      }
    if (len)
      {
        if (evaluate_schema_node (len) != 0)
            return -1;
        if (node_is_countable (len))
            len_n = (unsigned long) len-> result_n;
        else
          {
            gg_report_error ('E', "Illegal 'Len' value: %s", 
                             string_result (len));
            return -1;
          }
      }

    if (start &&  end
    && (end_n < start_n))
      {
        gg_report_error ('E', "'End' must be at least 'Start' in 'substr'");
        return -1;
      }
    if (len && !start)
      {
        if (!end)
            end_n = strlen (string-> result_s) - 1;

        start_n = end_n - len_n + 1;
      }
    else
      {
        if (!start)
            start_n = 0;

        if (!len)
          {
            if (end)
                len_n = end_n - start_n + 1;
            else
                len_n = strlen (string-> result_s);
          }
      }
    if (start_n >= strlen (string-> result_s))
        node-> result_s = mem_strdup ("");
    else
      {
        node-> result_s = mem_alloc (len_n + 1);
        if (start_n >= 0)
            strncpy (node-> result_s, & string-> result_s [start_n], len_n);
        else
            strncpy (node-> result_s, string-> result_s, len_n);
        
        (node-> result_s) [len_n] = '\0';
      }
    node-> result_type = TYPE_STRING;
    return 0;
}


/*  Return n-th function parameter  */
static SCHEMA_NODE *
function_parameter (SCHEMA_NODE *node, int n)
{
    int
       count = 0;

    if ((node)
    &&  (node-> type           == GG_OPERATOR)
    &&  (node-> operator       == OP_NEXT_ARG))
      {
        count++;

        while ((node-> op1)
           &&  (node-> op1-> type     == GG_OPERATOR)
           &&  (node-> op1-> operator == OP_NEXT_ARG))
          {
            node = node-> op1;
            count++;
          }
      }

    if (n > count + 1)
        return NULL;

    while (n > 2)
      {
        node = node-> parent;
        n--;
      }
    if (n == 1)
        if ((node-> type     == GG_OPERATOR)
        &&  (node-> operator == OP_NEXT_ARG))
            return node-> op1;
        else
            return node;
    else
        return node-> op2;
}


static Bool
node_is_countable (SCHEMA_NODE *node)
{
    if (node)
      {
        if (node-> result_type != TYPE_UNDEFINED)
          {
            number_result (node);
            if ((node-> result_type == TYPE_NUMBER)
            &&  (node-> result_n == floor (node-> result_n))
            &&  (node-> result_n >= 0))
                return TRUE;
          }
        else
            undefined_expression_error (node);
      }
    
    return FALSE;
}


static int
evaluate_trim_function (SCHEMA_NODE *node)
{
    if (!verify_function_parameters (node-> op2, 1, 1))
        return -1;

    if (evaluate_schema_node (node-> op2) != 0)
        return -1;

    node-> result_type = node-> op2-> result_type;
    if (node-> op2-> result_s)
      {
        node-> result_s = mem_strdup (trim (node-> op2-> result_s));
        ASSERT (node-> result_s);
      }
    node-> result_n = node-> op2-> result_n;
    node-> culprit  = node-> op2-> culprit;
    return 0;
}


static int
evaluate_justify_function (SCHEMA_NODE *node)
{
    SCHEMA_NODE
        *string,
        *width,
        *prefix;
    unsigned long
        width_n;

    if (!verify_function_parameters (node-> op2, 3, 3))
        return -1;

    string = function_parameter (node-> op2, 1);
    width  = function_parameter (node-> op2, 2);
    prefix = function_parameter (node-> op2, 3);
    if (evaluate_schema_node (string) != 0)
        return -1;
    if (evaluate_schema_node (prefix) != 0)
        return -1;
    if (evaluate_schema_node (width) != 0)
        return -1;
    if (node_is_countable (width))
        width_n = (unsigned long) width-> result_n;
    else
      {
        gg_report_error ('E', "Illegal 'Width' value: %s", 
                         string_result (width));
        return -1;
      }
    node-> result_s = mem_strdup (
                          strreformat (string_result (string),
                                       width_n,
                                       string_result (prefix)));
    node-> result_type = TYPE_STRING;
    return 0;
}


static int
evaluate_operator (SCHEMA_NODE *node)
{
    OPERATOR
        the_operator = node-> operator;
    double
        n = 0;
    long
        i;
    Bool
        safe;
    int
        offset,
        length,
        cmp;

    node-> line_break  = node-> op2 ? node-> op2-> line_break : FALSE;
    node-> extend      = node-> op2 ? node-> op2-> extend     : FALSE;
    node-> result_type = TYPE_UNDEFINED;
    node-> result_s    = NULL;
    node-> culprit     = NULL;

    if (the_operator == OP_NEXT_ARG)
      {
        if (evaluate_schema_node (node-> op1) != 0)
            return -1;
        if (evaluate_schema_node (node-> op2) != 0)
            return -1;
        return 0;
      }

    safe = ((the_operator == OP_SAFE_EQUALS)
         || (the_operator == OP_SAFE_NOT_EQUALS)
         || (the_operator == OP_SAFE_GREATER_THAN)
         || (the_operator == OP_SAFE_LESS_THAN)
         || (the_operator == OP_SAFE_GREATER_EQUAL)
         || (the_operator == OP_SAFE_LESS_EQUAL));

    /*  Evaluate first operand  */
    if (evaluate_schema_node (node-> op1) != 0)
        return -1;

    if (node-> op1)
      {
        /*  Now try some optimisation.  This also allows for             */
        /*  constructs such as '.if defined (N) & N = 1'                 */
        if ((the_operator == OP_OR) || (the_operator == OP_AND))
          {
            number_result (node-> op1);
            if (node-> op1-> result_type == TYPE_NUMBER)
              {
                if ((the_operator == OP_OR) 
                &&  (node-> op1-> result_n != 0))
                  {
                    node-> result_type = TYPE_NUMBER;
                    node-> result_n    = 1;
                    return 0;
                  }
                else
                if ((the_operator == OP_AND)
                &&  (node-> op1-> result_n == 0))
                  {
                    node-> result_type = TYPE_NUMBER;
                    node-> result_n    = 0;
                    return 0;
                  }
              }
          }
        if (node-> op1-> result_type == TYPE_UNDEFINED)
          {
            if (! safe)
              {
                node-> culprit = node-> op1-> culprit;
                return 0;
              }
            else                        /*  Return FALSE if op is undefined  */
              {
                node-> result_type = TYPE_NUMBER;
                node-> result_n    = 0;
                return 0;
              }
          }
      }

    if (evaluate_schema_node (node-> op2) != 0)
        return -1;
    if (node-> op2)
      {
        if (node-> op2-> result_type == TYPE_UNDEFINED)
          {
            if (! safe)
              {
                node-> culprit = node-> op2-> culprit;
                return 0;
              }
            else              /*  Return FALSE if operand is undefined       */
              {
                node-> result_type = TYPE_NUMBER;
                node-> result_n    = 0;
                return 0;
              }
          }
      }
    else                      /* This should never happen, but might save us */
        return 0;      

    /*  Change safe operator to non-safe equevalent */
    if (the_operator == OP_SAFE_EQUALS)
        the_operator = OP_EQUALS;
    else if (the_operator == OP_SAFE_NOT_EQUALS)
        the_operator = OP_NOT_EQUALS;
    else if (the_operator == OP_SAFE_GREATER_THAN)
        the_operator = OP_GREATER_THAN;
    else if (the_operator == OP_SAFE_LESS_THAN)
        the_operator = OP_LESS_THAN;
    else if (the_operator == OP_SAFE_GREATER_EQUAL)
        the_operator = OP_GREATER_EQUAL;
    else if (the_operator == OP_SAFE_LESS_EQUAL)
        the_operator = OP_LESS_EQUAL;

    if (node-> op1)                     /*  Not unary operator               */
        number_result (node-> op1);
    number_result (node-> op2);
 
    /*  If operator wants numeric operands, do conversion  */
    if ((the_operator == OP_TIMES)
    ||  (the_operator == OP_DIVIDE)
    ||  (the_operator == OP_PLUS)
    ||  (the_operator == OP_MINUS)
    ||  (the_operator == OP_OR)
    ||  (the_operator == OP_AND)
    ||  (the_operator == OP_NOT))
      {
        /*  Binary PLUS between string operands or TIMES with string first   */
        /*  operand are allowed.  Otherwise both operands must be numeric.   */
        if ( (! (   ( (the_operator == OP_PLUS)
                  &&  (node-> op1)           )
        ||          ( (the_operator == OP_TIMES)
                  &&  (node-> op2-> result_type == TYPE_NUMBER) ) ))
        &&   ((node-> op1 ? node-> op1-> result_type == TYPE_STRING : FALSE)
        ||    (node-> op2-> result_type == TYPE_STRING)) )
          {
            gg_report_error ('E', "Non-numeric operand to numeric operator.");
            return -1;
          }
      }

    /*  If the operator is UNDEFINED then we are concatenating strings,      */
    /*  including the spaces, and shuffling if enabled.  If the operator is  */
    /*  PLUS and at least one of the operands is non-numeric then we also    */
    /*  concatenate but do not include the spaces before the 2nd string.     */
    if (( the_operator == OP_UNDEFINED)
    ||  ((the_operator == OP_PLUS) && (node-> op1)
    &&   ((node-> op1-> result_type == TYPE_STRING)
    ||    (node-> op2-> result_type == TYPE_STRING)) ) )
      {
        offset = strlen (string_result (node-> op1));
        if (node-> op1-> line_break)
            offset++;
        node-> indent = node-> op1-> indent;

        if (the_operator == OP_UNDEFINED)  /*  Must be 2 ops in this case   */
            if (! node-> op1-> line_break)
                if (node-> op2-> indent > shuffle)
                  {
                    if (node-> op1-> shuffle_cnt <= node-> op2-> indent
                                                  - shuffle)
                        node-> op2-> indent -= node-> op1-> shuffle_cnt;
                    else
                        node-> op2-> indent = shuffle;
                  }

        length = offset
               + node-> op2-> indent
               + strlen (string_result (node-> op2));

        if (node-> op1 ? node-> op1-> line_break : FALSE)
            node-> shuffle_cnt = node-> op2-> shuffle_cnt;
        else
            node-> shuffle_cnt = length - node-> length;

        node-> result_s = mem_alloc (length + 1);
        ASSERT (node-> result_s);
        if (node-> op1)
          {
            strcpy (node-> result_s, node-> op1-> result_s);
            if (node-> op1-> line_break)
                strcat (node-> result_s, "\n");
          }
        
        if (the_operator == OP_UNDEFINED)
          {
            memset (node-> result_s + offset, ' ', node-> op2-> indent);
            offset += node-> op2-> indent;
          }
        strcpy (node-> result_s + offset, node-> op2-> result_s);
        node-> result_type = TYPE_STRING;
        return 0;
      }

    /*  "string" * 3 = "stringstringstring"  */
    if ((the_operator == OP_TIMES)
    &&  (node-> op1-> result_type == TYPE_STRING)
    &&  (node-> op2-> result_type == TYPE_NUMBER))
      {
        length = strlen (node-> op1-> result_s);
        i = (long) node-> op2-> result_n;      /*  Integer value  */
        node-> result_s = mem_alloc (length * i + 1);
        ASSERT (node-> result_s);
        offset = 0;
        while (i-- > 0)
          {
            memcpy (node-> result_s + offset, node-> op1-> result_s, length);
            offset += length;
          }
        node-> result_s [offset] = '\0';
        node-> result_type = TYPE_STRING;
        return 0;
      }

    /*  If at least one operand is non-numeric, treat as a string operator   */
    if (node-> op1)
        if ((node-> op1-> result_type == TYPE_STRING)
        ||  (node-> op2-> result_type == TYPE_STRING))
      {
        cmp = strcmp (string_result (node-> op1),
                      string_result (node-> op2));
        switch (the_operator)
          {
            case OP_EQUALS        : n = (cmp == 0);  break;
            case OP_NOT_EQUALS    : n = (cmp != 0);  break;
            case OP_GREATER_THAN  : n = (cmp >  0);  break;
            case OP_LESS_THAN     : n = (cmp <  0);  break;
            case OP_GREATER_EQUAL : n = (cmp >= 0);  break;
            case OP_LESS_EQUAL    : n = (cmp <= 0);  break;
            default               : gg_report_error ('E', "Invalid operator.");
                                    return -1;
          }
        node-> result_type = TYPE_NUMBER;
        node-> result_n    = n;
        return 0;
      }

    /*  If we got here then we have two numeric operands.  The operator may  */
    /*  be unary, in which case the first operand is zero.                   */
    switch (the_operator)
      {
        case OP_NOT           : n = (double) (! (Bool) node-> op2-> result_n);
                                                                        break;
        case OP_PLUS          : n = (node-> op1 ? node-> op1-> result_n : 0)
                                  +  node-> op2-> result_n;             break;
        case OP_MINUS         : n = (node-> op1 ? node-> op1-> result_n : 0)
                                  -  node-> op2-> result_n;             break;
        case OP_TIMES         : n = node-> op1-> result_n
                                  * node-> op2-> result_n;              break;
        case OP_DIVIDE        : if (node-> op2-> result_n != 0)
                               {
                                 n = node-> op1-> result_n
                                   / node-> op2-> result_n;            
                                 break;
                               }
                             else
                               {
                                 gg_report_error ('E', "Division by zero.");
                                 return -1;
                               }
        case OP_EQUALS        : n = (double) (node-> op1-> result_n
                                           == node-> op2-> result_n);    break;
        case OP_NOT_EQUALS    : n = (double) (node-> op1-> result_n
                                           != node-> op2-> result_n);    break;
        case OP_GREATER_THAN  : n = (double) (node-> op1-> result_n
                                            > node-> op2-> result_n);    break;
        case OP_LESS_THAN     : n = (double) (node-> op1-> result_n
                                            < node-> op2-> result_n);    break;
        case OP_GREATER_EQUAL : n = (double) (node-> op1-> result_n
                                           >= node-> op2-> result_n);    break;
        case OP_LESS_EQUAL    : n = (double) (node-> op1-> result_n
                                           <= node-> op2-> result_n);    break;
        case OP_OR            : n = (double) ((Bool) node-> op1-> result_n
                                           || (Bool) node-> op2-> result_n);
                                                                         break;
        case OP_AND           : n = (double) ((Bool) node-> op1-> result_n
                                           && (Bool) node-> op2-> result_n);
                                                                         break;
        default               : gg_report_error ('E', "Invalid operator.");
                                return -1;
      }
    node-> result_type = TYPE_NUMBER;
    node-> result_n    = n;
    return 0;
}


static int
evaluate_text_node (SCHEMA_NODE *node)
{
    char
        *backslash, 
        *last;

    /*  Replace \x with x */
    node-> result_type = TYPE_STRING;
    node-> result_s    = mem_strdup (node-> text);
    last               = strchr (node-> result_s, 0);
    backslash          = strchr (node-> result_s, '\\');
    while (backslash && (backslash < last - 1))
      {
        memmove (backslash, backslash + 1, last - backslash);
        backslash = strchr (backslash + 1, '\\');
      }

    return 0;
}
