/*---------------------------------------------------------------------------
 *  xiadm10.h - HTML form definition
 *
 *  Generated 1998/06/24, 15:57:12 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM10__
#define __FORM_XIADM10__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM10_MESSAGE_TO_USER             0
#define XIADM10_FILLER                      1
#define XIADM10_L_ERROR_HEADER              2
#define XIADM10_ERROR_HEADER                3
#define XIADM10_L_TEXT_400                  4
#define XIADM10_TEXT_400                    5
#define XIADM10_L_TEXT_401                  6
#define XIADM10_TEXT_401                    7
#define XIADM10_L_TEXT_402                  8
#define XIADM10_TEXT_402                    9
#define XIADM10_L_TEXT_403                  10
#define XIADM10_TEXT_403                    11
#define XIADM10_L_TEXT_404                  12
#define XIADM10_TEXT_404                    13
#define XIADM10_L_TEXT_413                  14
#define XIADM10_TEXT_413                    15
#define XIADM10_L_TEXT_500                  16
#define XIADM10_TEXT_500                    17
#define XIADM10_L_TEXT_501                  18
#define XIADM10_TEXT_501                    19
#define XIADM10_L_TEXT_502                  20
#define XIADM10_TEXT_502                    21
#define XIADM10_L_ERROR_FOOTER              22
#define XIADM10_ERROR_FOOTER                23
#define XIADM10_L_NONAME9                   24

/*  This table contains each block in the form                               */

static byte xiadm10_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) ... mised Error Messages</TITLE>        */
    0, 66, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'C', 'u', 's', 't', 'o', 'm', 'i',
    's', 'e', 'd', 32, 'E', 'r', 'r', 'o', 'r', 32, 'M', 'e', 's', 's',
    'a', 'g', 'e', 's', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 158, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  #(config) - Customised Error Messages                                */
    0, 39, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'C', 'u', 's', 't', 'o', 'm', 'i', 's', 'e', 'd', 32, 'E', 'r', 'r',
    'o', 'r', 32, 'M', 'e', 's', 's', 'a', 'g', 'e', 's', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 176,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 48, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 21, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>', 10,
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 4, 1, 0, 2, 16,
    /*  <TR><TD></TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                      */
    0, 49, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P', 32, 'W', 'I', 'D', 'T',
    'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD TEXTUAL f154 NAME=f ... E="HTML text or @filename:"         */
    0, 37, 10, 7, 1, 0, 0, 23, 0, 23, 'f', '1', '5', '4', 0, 'H', 'T',
    'M', 'L', 32, 't', 'e', 'x', 't', 32, 'o', 'r', 32, '@', 'f', 'i',
    'l', 'e', 'n', 'a', 'm', 'e', ':', 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f155 NAME=L ...  VALUE="Header for errors:"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '1', '5', '5', 0, 'H', 'e',
    'a', 'd', 'e', 'r', 32, 'f', 'o', 'r', 32, 'e', 'r', 'r', 'o', 'r',
    's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD TEXTBOX f156 NAME=e ... 60 MAX=240 UPPER=0 VALUE=""         */
    0, 14, 13, 0, 1, 2, '<', 0, 0, 240, 'f', '1', '5', '6', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f157 NAME=L ...  VALUE="400 - Bad request:"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '1', '5', '7', 0, '4', '0',
    '0', 32, 45, 32, 'B', 'a', 'd', 32, 'r', 'e', 'q', 'u', 'e', 's',
    't', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f158 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '5', '8', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f159 NAME=L ... VALUE="401 - Unauthorized:"         */
    0, 33, 10, 6, 1, 0, 0, 19, 0, 19, 'f', '1', '5', '9', 0, '4', '0',
    '1', 32, 45, 32, 'U', 'n', 'a', 'u', 't', 'h', 'o', 'r', 'i', 'z',
    'e', 'd', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f160 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '6', '0', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f161 NAME=L ... E="402 - Payment required:"         */
    0, 37, 10, 6, 1, 0, 0, 23, 0, 23, 'f', '1', '6', '1', 0, '4', '0',
    '2', 32, 45, 32, 'P', 'a', 'y', 'm', 'e', 'n', 't', 32, 'r', 'e',
    'q', 'u', 'i', 'r', 'e', 'd', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f162 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '6', '2', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f163 NAME=L ... 03 VALUE="403 - Forbidden:"         */
    0, 30, 10, 6, 1, 0, 0, 16, 0, 16, 'f', '1', '6', '3', 0, '4', '0',
    '3', 32, 45, 32, 'F', 'o', 'r', 'b', 'i', 'd', 'd', 'e', 'n', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f164 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '6', '4', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f165 NAME=L ... 04 VALUE="404 - Not found:"         */
    0, 30, 10, 6, 1, 0, 0, 16, 0, 16, 'f', '1', '6', '5', 0, '4', '0',
    '4', 32, 45, 32, 'N', 'o', 't', 32, 'f', 'o', 'u', 'n', 'd', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f166 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '6', '6', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f167 NAME=L ...  Request entity too large:"         */
    0, 45, 10, 6, 1, 0, 0, 31, 0, 31, 'f', '1', '6', '7', 0, '4', '1',
    '3', 32, 45, 32, 'R', 'e', 'q', 'u', 'e', 's', 't', 32, 'e', 'n',
    't', 'i', 't', 'y', 32, 't', 'o', 'o', 32, 'l', 'a', 'r', 'g', 'e',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f168 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '6', '8', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f169 NAME=L ... LUE="500 - Internal error:"         */
    0, 35, 10, 6, 1, 0, 0, 21, 0, 21, 'f', '1', '6', '9', 0, '5', '0',
    '0', 32, 45, 32, 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l', 32, 'e',
    'r', 'r', 'o', 'r', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f170 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '7', '0', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f171 NAME=L ... UE="501 - Not implemented:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '1', '7', '1', 0, '5', '0',
    '1', 32, 45, 32, 'N', 'o', 't', 32, 'i', 'm', 'p', 'l', 'e', 'm',
    'e', 'n', 't', 'e', 'd', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f172 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '7', '2', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f173 NAME=L ... e temporarily unavailable:"         */
    0, 52, 10, 6, 1, 0, 0, '&', 0, '&', 'f', '1', '7', '3', 0, '5', '0',
    '2', 32, 45, 32, 'S', 'e', 'r', 'v', 'i', 'c', 'e', 32, 't', 'e',
    'm', 'p', 'o', 'r', 'a', 'r', 'i', 'l', 'y', 32, 'u', 'n', 'a', 'v',
    'a', 'i', 'l', 'a', 'b', 'l', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTUAL f174 NAME=t ... E=60 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '<', 0, '<', 'f', '1', '7', '4', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f175 NAME=L ...  VALUE="Footer for errors:"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '1', '7', '5', 0, 'F', 'o',
    'o', 't', 'e', 'r', 32, 'f', 'o', 'r', 32, 'e', 'r', 'r', 'o', 'r',
    's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--FIELD TEXTBOX f176 NAME=e ... 60 MAX=240 UPPER=0 VALUE=""         */
    0, 14, 13, 0, 1, 2, '<', 0, 0, 240, 'f', '1', '7', '6', 0, 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 19, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>', 10,
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, '!',
    /*  !--FIELD TEXTUAL f177 NAME=L ... UE="Actions for this page:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '1', '7', '7', 0, 'A', 'c',
    't', 'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's',
    32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 'l',
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 2, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 19,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 176,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 176,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm10_fields [] = {
    { 0, 129, 80 },                     /*  message_to_user                 */
    { 82, 748, 23 },                    /*  filler                          */
    { 107, 842, 18 },                   /*  l_error_header                  */
    { 127, 919, 240 },                  /*  error_header                    */
    { 369, 947, 18 },                   /*  l_text_400                      */
    { 389, 987, 60 },                   /*  text_400                        */
    { 451, 1015, 19 },                  /*  l_text_401                      */
    { 472, 1056, 60 },                  /*  text_401                        */
    { 534, 1084, 23 },                  /*  l_text_402                      */
    { 559, 1129, 60 },                  /*  text_402                        */
    { 621, 1157, 16 },                  /*  l_text_403                      */
    { 639, 1195, 60 },                  /*  text_403                        */
    { 701, 1223, 16 },                  /*  l_text_404                      */
    { 719, 1261, 60 },                  /*  text_404                        */
    { 781, 1289, 31 },                  /*  l_text_413                      */
    { 814, 1342, 60 },                  /*  text_413                        */
    { 876, 1370, 21 },                  /*  l_text_500                      */
    { 899, 1413, 60 },                  /*  text_500                        */
    { 961, 1441, 22 },                  /*  l_text_501                      */
    { 985, 1485, 60 },                  /*  text_501                        */
    { 1047, 1513, 38 },                 /*  l_text_502                      */
    { 1087, 1573, 60 },                 /*  text_502                        */
    { 1149, 1601, 18 },                 /*  l_error_footer                  */
    { 1169, 1641, 240 },                /*  error_footer                    */
    { 1411, 1697, 22 },                 /*  l_noname9                       */
    { 1435, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   filler_a             ;
    char   filler               [23 + 1];
    byte   l_error_header_a     ;
    char   l_error_header       [18 + 1];
    byte   error_header_a       ;
    char   error_header         [240 + 1];
    byte   l_text_400_a         ;
    char   l_text_400           [18 + 1];
    byte   text_400_a           ;
    char   text_400             [60 + 1];
    byte   l_text_401_a         ;
    char   l_text_401           [19 + 1];
    byte   text_401_a           ;
    char   text_401             [60 + 1];
    byte   l_text_402_a         ;
    char   l_text_402           [23 + 1];
    byte   text_402_a           ;
    char   text_402             [60 + 1];
    byte   l_text_403_a         ;
    char   l_text_403           [16 + 1];
    byte   text_403_a           ;
    char   text_403             [60 + 1];
    byte   l_text_404_a         ;
    char   l_text_404           [16 + 1];
    byte   text_404_a           ;
    char   text_404             [60 + 1];
    byte   l_text_413_a         ;
    char   l_text_413           [31 + 1];
    byte   text_413_a           ;
    char   text_413             [60 + 1];
    byte   l_text_500_a         ;
    char   l_text_500           [21 + 1];
    byte   text_500_a           ;
    char   text_500             [60 + 1];
    byte   l_text_501_a         ;
    char   l_text_501           [22 + 1];
    byte   text_501_a           ;
    char   text_501             [60 + 1];
    byte   l_text_502_a         ;
    char   l_text_502           [38 + 1];
    byte   text_502_a           ;
    char   text_502             [60 + 1];
    byte   l_error_footer_a     ;
    char   l_error_footer       [18 + 1];
    byte   error_footer_a       ;
    char   error_footer         [240 + 1];
    byte   l_noname9_a          ;
    char   l_noname9            [22 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   defaults_a;
    byte   undo_a;
    } XIADM10_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm10 = {
    xiadm10_blocks,
    xiadm10_fields,
    97,                                 /*  Number of blocks in form        */
    25,                                 /*  Number of fields in form        */
    4,                                  /*  Number of actions in form       */
    1435,                               /*  Size of fields                  */
    "xiadm10",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
