/*---------------------------------------------------------------------------
 *  xiadm22.h - HTML form definition
 *
 *  Generated 1998/06/24, 15:57:12 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM22__
#define __FORM_XIADM22__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM22_MESSAGE_TO_USER             0
#define XIADM22_REFRESH_ON                  1
#define XIADM22_MESSAGES                    2

/*  This table contains each block in the form                               */

static byte xiadm22_blocks [] = {
    /*  <HTML><HEAD><TITLE>Console Messages</TITLE>                          */
    0, 45, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'C', 'o', 'n', 's', 'o',
    'l', 'e', 32, 'M', 'e', 's', 's', 'a', 'g', 'e', 's', '<', '/', 'T',
    'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 134, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  Console Messages                                                     */
    0, 18, 0, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'M', 'e', 's', 's',
    'a', 'g', 'e', 's', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  !--FIELD NUMERIC refresh_on SIZE=4 VALUE=1                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r',
    'e', 's', 'h', '_', 'o', 'n', 0, '1', 0,
    /*  !--IF refresh_on                                                     */
    0, 5, 2, 0, 1, 0, 1,
    /*  <META HTTP-EQUIV="REFRESH" CONTENT="#(rate)">                        */
    0, 47, 0, '<', 'M', 'E', 'T', 'A', 32, 'H', 'T', 'T', 'P', 45, 'E',
    'Q', 'U', 'I', 'V', '=', '"', 'R', 'E', 'F', 'R', 'E', 'S', 'H',
    '"', 32, 'C', 'O', 'N', 'T', 'E', 'N', 'T', '=', '"', '#', '(', 'r',
    'a', 't', 'e', ')', '"', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'n',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 52, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD ALIGN=LEFT>                                                      */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>', 10,
    /*  !--ACTION close  LABEL="Close" EVENT=ok_event TYPE=BUTTON            */
    0, 23, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'c', 'l', 'o', 's', 'e', 0,
    'C', 'l', 'o', 's', 'e', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  !--FIELD TEXTBOX messages NA ... s ROWS=24 COLS=100 MAX=4000         */
    0, 18, 13, 0, 1, 24, 'd', 0, 15, 160, 'm', 'e', 's', 's', 'a', 'g',
    'e', 's', 0, 0,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 4, 1, 0, 1, 206,
    /*  !--ACTION properties  LABEL= ... NT=define_event TYPE=BUTTON         */
    0, 36, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 1, 0, 0, 0, 0, 0, 'p', 'r', 'o', 'p', 'e',
    'r', 't', 'i', 'e', 's', 0, 'P', 'r', 'o', 'p', 'e', 'r', 't', 'i',
    'e', 's', '.', '.', '.', 0,
    /*  !--ACTION refresh  LABEL="Re ... T=refresh_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) refresh_event / 256), (byte) ((word)
    refresh_event & 255), 0, 2, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r', 'e',
    's', 'h', 0, 'R', 'e', 'f', 'r', 'e', 's', 'h', 0,
    /*  !--ACTION invert  LABEL="Inv ... NT=invert_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) invert_event / 256), (byte) ((word)
    invert_event & 255), 0, 3, 0, 0, 0, 0, 0, 'i', 'n', 'v', 'e', 'r',
    't', 0, 'I', 'n', 'v', 'e', 'r', 't', 0,
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 4, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  </FORM>                                                              */
    0, 4, 1, 0, 2, 196,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'n',
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm22_fields [] = {
    { 0, 108, 80 },                     /*  message_to_user                 */
    { 82, 378, 4 },                     /*  refresh_on                      */
    { 88, 688, 4000 },                  /*  messages                        */
    { 4090, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   refresh_on_a         ;
    char   refresh_on           [4 + 1];
    byte   messages_a           ;
    char   messages             [4000 + 1];
    byte   close_a;
    byte   properties_a;
    byte   refresh_a;
    byte   invert_a;
    byte   clear_a;
    } XIADM22_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm22 = {
    xiadm22_blocks,
    xiadm22_fields,
    38,                                 /*  Number of blocks in form        */
    3,                                  /*  Number of fields in form        */
    5,                                  /*  Number of actions in form       */
    4090,                               /*  Size of fields                  */
    "xiadm22",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
