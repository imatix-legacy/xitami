/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflcbox.c
    Title:      Various C string and file functions
    Package:    standard function library (sfl)

    Written:    88-06-03  Scott Beasley (jscottb@infoave.com)
    Revised:    98-03-03

    Synopsis:   Various C string and file functions, including
                simple parsing, searching, replacing functions.
            
    Copyright:  Copyright (C) 1991-97 Imatix
    License:    this is free software; you can redistribute it and/or modify
                it under the terms of the sfl license agreement as provided
                in the file license.txt.  this software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include "sflcbox.h"

/*  ---------------------------------------------------------------------[<]-
    Function: removechars

    Synopsis:
    Removes known chars from a string. Returns pointer to head of 
    the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
removechars ( 
    char *strbuf, 
    char *chrstorm )
{
   char *offset;

   offset = ( char * ) NULL;

   while ( *strbuf ) 
      {
         offset = strpbrk ( strbuf, chrstorm );
         if ( offset ) 
             strcpy ( offset, ( offset + 1 ) );
         else
             break;
      }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: replacechrswith

    Synopsis:
    Subsitutes known char(s) in a string with another. Returns pointer 
    to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
replacechrswith ( 
    char *strbuf, 
    char *chrstorm, 
    char chartorlcwith )
{
   char *offset;

   offset = ( char * ) NULL;

   while ( *strbuf ) 
      {
         offset = strpbrk ( strbuf, chrstorm );
         if ( offset ) 
           {
             *( offset ) = chartorlcwith;
           }

         else
             break;
      }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: insertstring

    Synopsis:
    Inserts a string into another string.  Returns a pointer to head of 
    the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
insertstring ( 
    char *strbuf, 
    char *chrstoins, 
    int pos )
{
   memmove ( ( strbuf + pos ) + strlen ( chrstoins ),
   ( strbuf + pos ), strlen ( ( strbuf + pos ) ) + 1 );
   memcpy ( ( strbuf + pos ), chrstoins, strlen ( chrstoins ) );

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: insertchar

    Synopsis:
    Inserts a char into a string.  Returns a pointer to head of 
    the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
insertchar ( 
    char *strbuf, 
    char chrtoins, 
    int pos )
{
   memmove ( ( strbuf + pos ) + 1,
   ( strbuf + pos ), strlen ( ( strbuf + pos ) ) + 1 );
   *( strbuf + pos ) = chrtoins;

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: leftfill

    Synopsis:
    Pads a string to the left, to a know length, with the given char value.
    Returns a pointer to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
leftfill ( 
    char *strbuf, 
    char chrtofill, 
    unsigned len )
{
   while ( strlen ( strbuf ) < len ) 
     {
       insertchar ( strbuf, chrtofill, 0 );
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: rightfill

    Synopsis:
    Pads a string to the right, to a known length, with the given char value.
    Returns a pointer to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
rightfill ( 
    char *strbuf, 
    char chrtofill, 
    unsigned len )
{
   while ( strlen ( strbuf ) < len ) 
     {
       insertchar ( strbuf, chrtofill, strlen ( strbuf ) );
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: trimleft

    Synopsis:
    Eats the white spaces from the left side of a string. This function
    maintains a proper pointer head. Returns a pointer to head 
    of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
trimleft ( 
    char *strbuf )
{
   while ( isspace ( ( int ) *strbuf ) ) 
     {
       deletechar ( strbuf, 0 );
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: trimright

    Synopsis:
    Eats the white spaces from the right side of a string. This function
    maintains a proper pointer head.  Returns a pointer to head 
    of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
trimright ( 
    char *strbuf )
{
   while ( isspace ( ( int ) *( strbuf + strlen ( strbuf ) - 1 ) ) ) 
     {
       *( strbuf + strlen ( strbuf ) - 1 ) = 0;
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: trim

    Synopsis:
    Eats the white spaces from the left and right side of a string. This 
    function maintains a proper pointer head.  Returns a pointer to 
    head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
trim ( 
    char *strin )
{
   trimleft ( strin );
   trimright ( strin );

   return strin;
}

/*  ---------------------------------------------------------------------[<]-
    Function: searchreplace

    Synopsis:
    A case insensitive search and replace. Searches for all occurances 
    of a string, and replaces it with another string.  Returns a pointer 
    to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
searchreplace ( 
    char *strbuf, 
    char *strtofnd, 
    char *strtoins )
{
   char *offset, *strbase;

   offset = strbase = ( char * ) NULL;

   while ( *strbuf ) 
     {
       offset = stristr ( !offset ? strbuf : strbase, strtofnd );
       if ( offset ) 
         {
           strbase = ( offset + strlen ( strtoins ) );
           strcpy ( offset, ( offset + strlen ( strtofnd ) ) );
           memmove ( offset + strlen ( strtoins ),
                     offset, strlen ( offset ) + 1 );
           memcpy ( offset, strtoins, strlen ( strtoins ) );
         }

      else
           break;
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: deletestring

    Synopsis:
    Deletes all occurances of one string, in another string. Returns 
    a pointer to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
deletestring ( 
    char *strbuf, 
    char *strtodel )
{
   char *offset;

   offset = ( char * ) NULL;

   while ( *strbuf ) 
     {
        offset = strstr ( strbuf, strtodel );
        if ( offset ) 
          {
            strcpy ( offset, ( offset + strlen ( strtodel ) ) );
          }
        else
            break;
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: getstrfld

    Synopsis:
    Gets a sub-string from a formated string. nice strtok replacement.

    usage:
      char strarray[] = { "123,456,789,abc" };
      char strretbuff[4];
      getstrfld ( strarray, 2, 0, ",", strretbuff );

    This would return the string "789" and place it also in strretbuff.
    Returns a NULL if fldno is out of range, else returns a pointer to 
    head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
getstrfld ( 
    char *strbuf, 
    int fldno, 
    int ofset, 
    char *sep, 
    char *retstr )
{
   char *offset, *strptr;
   int curfld;

   offset = strptr = ( char * ) NULL;
   curfld = 0;

   strbuf += ofset;

   while ( *strbuf ) 
     {
       strptr = !offset ? strbuf : offset;
       offset = strpbrk ( ( !offset ? strbuf : offset ), sep );

       if ( offset )
          offset++;
       else if ( curfld != fldno )
         {
           *retstr = ( char ) NULL;
           break;
         }

       if ( curfld == fldno )
         {
           strncpy ( retstr, strptr,
              ( int )( !offset ? strlen ( strptr ) + 1 : 
              ( int ) ( offset - strptr ) ) );
           if ( offset )
              retstr[offset - strptr - 1] = 0;

           break;
         }
       curfld++;
     }   
   return retstr;
}

/*  ---------------------------------------------------------------------[<]-
    Function: setstrfld

    Synopsis:
    inserts a string into a fomated string.

    usage:
       char strsrray[26] = { "this is a test." };
       setstrfld ( strsrray, 2, 0, " ", "big " );

       result: this is a big test.

    Does nothing if fldno is out of range, else returns pointer to head
    of the buffer.  Returns a pointer to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
setstrfld ( 
    char *strbuf, 
    int fldno, 
    int ofset, 
    char *sep, 
    char *strtoins )
{
   char *offset, *strptr, *strhead;
   int curfld;

   offset = strptr = ( char * ) NULL;
   curfld = 0;

   strhead = strbuf;
   strbuf += ofset;

   while ( *strbuf ) 
     {
       strptr = !offset ? strbuf : offset;
       offset = strpbrk ( ( !offset ? strbuf : offset ), sep );

       if ( offset )
          offset++;

       if ( curfld == fldno ) 
          {
            insertstring ( strptr, strtoins,
               ( int )( !offset ? strlen ( strptr ) : 
               ( int ) ( offset - strptr ) ) );
            break;
          }
       curfld++;
     }   

   return strhead;
}

/*  ---------------------------------------------------------------------[<]-
    Function: getstrfldlen

    Synopsis:
    Get the length of as a field in a string.  Used mainly for getting
    the len to malloc mem to call getstrfld with.  Returns the length of
    the field.
    ---------------------------------------------------------------------[>]-*/

int 
getstrfldlen ( 
    char *strbuf, 
    int fldno, 
    int ofset, 
    char *sep )
{
   char *offset, *strptr;
   int curfld, retlen = 0;

   offset = strptr = ( char * ) NULL;
   curfld = 0;

   strbuf += ofset;

   while ( *strbuf ) 
     {
       strptr = !offset ? strbuf : offset;
       offset = strpbrk ( ( !offset ? strbuf : offset ), sep );

       if ( offset )
          offset++;
       else if ( curfld != fldno ) 
         {
           retlen = 0;
           break;
         }
       if ( curfld == fldno ) 
         {
           retlen = ( int )( !offset ? strlen ( strptr ) + 1 : 
                    ( int ) ( offset - strptr ) );
           break;
         }
       curfld++;
     }   
   return retlen;
}

/*  ---------------------------------------------------------------------[<]-
    Function: uppercase

    Synopsis:
    Sets a string to upper case.  Returns a pointer to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
uppercase ( 
    char *strbuf )
{
   char *strbase;

   strbase = strbuf;   

   while ( *strbuf ) 
     {
       *strbuf = *strbuf <= 'z' && *strbuf >= 'a' ?
       *strbuf + 'a' - 'a' : *strbuf;
       strbuf++;
     }

   return strbase;
}

/*  ---------------------------------------------------------------------[<]-
    Function: lowercase

    Synopsis:
    Sets a string to lower case.  Returns a pointer to head of the buffer.
    ---------------------------------------------------------------------[>]-*/

char *
lowercase ( 
    char *strbuf )
{
   char *strbase;

   strbase = strbuf;   

   while ( *strbuf ) 
     {
       *strbuf = *strbuf <= 'z' && *strbuf >= 'a' ?
       *strbuf + 'a' - 'a' : *strbuf;
       strbuf++;
     }

   return strbase;
}

/*  ---------------------------------------------------------------------[<]-
    Function: findstrinfile

    Synopsis:
    Find's a string inside a text file and reads the line in and sets the
    file pointer to the beginning of that line.  Assumes the line length
    to be <= 1024 bytes.  Returns a pointer to head of the return buffer,
    and the file postion will be at the start of the found string. If
    the strretstr param is != NULL then strretstr will contain the line
    that the search string was found in.
    ---------------------------------------------------------------------[>]-*/

char *
findstrinfile ( 
    FILE *fp, 
    char *strtofind, 
    char *strretstr )
{
   char strline[1025];
   int nfnd = 0;
   long lfpos;

   if ( strretstr )
       *strretstr = 0;

   while ( 1 ) 
     {
       lfpos = ftell ( fp );
       fgets ( strline, 1024, fp );
       trim ( strline );

       if ( stristr ( strline, strtofind ) ) 
         {
           if ( strretstr ) {
               strcpy ( strretstr, strline );
           }

           fseek ( fp, lfpos, SEEK_SET );
           nfnd = 1;
           break;
         }

       if ( feof ( fp ) ) 
           break;
     }         

   if ( strretstr )
       return strretstr;
   else
       return ( char * ) nfnd;
}

/*  ---------------------------------------------------------------------[<]-
    Function: getequval

    Synopsis:
    get the everything on a line past a '='.
    
    Usage:
       char strtest[] = { "progpath=c:\sfl" );
       char strret[256];
       getequval (  strtest, strret );

    This would return: "c:\sfl".  Returns a pointer to head of the 
    return buffer.
    ---------------------------------------------------------------------[>]-*/

char *
getequval ( 
    char *strline, 
    char *strretstr )
{
   char *stroffset;

   stroffset = strstr ( strline, "=" );

   if ( stroffset )
       trimleft ( ( stroffset + 1 ) );
   else
       return ( char * ) NULL;

   return strcpy ( strretstr,
   ( stroffset && *( stroffset + 1 ) ) ? ( stroffset + 1 ) : "" );
}

/*  ---------------------------------------------------------------------[<]-
    Function: matchtable

    Synopsis:
    Function to compare a string with a set of strings. 
    
    Usage:
       iret = matchtable ( strname, "bill|william|billy", "|", IGNORECASE );

    If strname == "william", then matchtable would return 1.
    Returns >= 0 if match is found.  a -1 if no match is found.
    ---------------------------------------------------------------------[>]-*/

int 
matchtable ( 
    char *strbuf, 
    char *strmatch, 
    char *strsept, 
    int ncase )
{
   int nstate = -1, cnt = 0, icmpres;
   int ilen;
   char *strtemp;

   trim ( strbuf );
   while ( 1 ) 
     {
       ilen = getstrfldlen ( strmatch, cnt, 0, strsept );
       strtemp = ( char * ) malloc ( sizeof ( char ) * ilen + 1 );
       getstrfld ( strmatch, cnt, 0, strsept, strtemp );
       if ( *strtemp ) 
         {
           trim ( strtemp );

           if ( !ncase ) 
             {
               icmpres = stricmp ( strbuf, strtemp );
             }
           else 
             {
               icmpres = strcmp ( strbuf, strtemp );
             }

           if ( !icmpres ) 
             {
               nstate = cnt;
               break; 
             }
           else 
             {
               if ( !strcmp ( strbuf, strtemp ) ) 
                 {
                   nstate = cnt;
                   break; 
                 }
             }
         }         
       else 
         {
           nstate = -1;
           break; 
         }
       cnt++;
       free ( strtemp );
     }

   return nstate;
}

/*  ---------------------------------------------------------------------[<]-
    Function: stringreplace

    Synopsis:
    This function searches for known strings, and replaces them with
    another string. 

    Usage:
       stringreplace ( strfilename, "sqv|sqr,ruv|run,h_v|h" );

    This example would replace all occurences of sqv, with sqr, ruv with
    run and h_v with h. Returns pointer to head of the return buffer.
    ---------------------------------------------------------------------[>]-*/

char *
stringreplace ( 
    char *strbuf, 
    char *strpattern )
{
   int ilen, ifld = 0;
   char *strsrch, *strrpl, *strpat;

   if ( !strpattern )
       return strbuf;

   while ( 1 ) 
     {
       ilen = getstrfldlen ( strpattern, ifld, 0, "," );
       if ( !ilen )
           break;
       strpat = ( char * ) malloc ( ilen + 1 );
       getstrfld ( strpattern, ifld, 0, ",", strpat );
       ifld++;

       ilen = getstrfldlen ( strpat, 0, 0, "|" );
       strsrch = ( char * ) malloc ( ilen + 1 );
       getstrfld ( strpat, 0, 0, "|", strsrch );

       ilen = getstrfldlen ( strpat, 1, 0, "|" );
       strrpl = ( char * ) malloc ( ilen + 1 );
       getstrfld ( strpat, 1, 0, "|", strrpl );

       searchreplace ( strbuf, strsrch, strrpl );

       free ( strsrch );
       free ( strrpl );
       free ( strpat );
     }

   return strbuf;
}

/*  ---------------------------------------------------------------------[<]-
    Function: wordwrapstr

    Synopsis:
    Function that does word wraping of a string at or less than iwid.  
    Breaks up a string on word boundaries by placing '\n' in the string. 
    Returns a pointer to head of the return buffer.
    ---------------------------------------------------------------------[>]-*/

char *
wordwrapstr ( 
    char *strbuff, 
    int iwid )
{
   char *strtmp = strbuff;
   int icnt = 0;

   replacechrswith ( strbuff, "\n", ' ' );
   while ( *strtmp ) 
     {
       if ( ( int ) strlen ( strtmp ) > ( int ) iwid ) 
         {
           icnt = iwid; 
           while ( *( strtmp + icnt ) ) 
             {
               if ( strchr ( " .?;!,", *( strtmp + icnt ) ) ) 
                 {
                   trimleft ( ( strtmp + icnt ) );
                   insertchar ( strtmp, '\n', icnt );
                   strtmp += icnt + 1; 
                   break;
                 }
               icnt--;

               if ( !icnt ) 
                 {
                   if ( strchr ( " .?;!,", *( strtmp + icnt ) ) ) 
                     {
                       trimleft ( ( strtmp + iwid ) );
                       insertchar ( strtmp, '\n', iwid );
                       strtmp += iwid + 1; 
                       break;
                     }
                 }
             }
         }
       else
           break;
   }

   return strbuff;
}

/*  ---------------------------------------------------------------------[<]-
    Function: stricmp

    Synopsis:
    A case insensitive strcmp.  Returns a pointer to head of the str1.
    ---------------------------------------------------------------------[>]-*/

int 
stricmp ( 
    const char *str1, 
    const char *str2 )
{
   register char c1, c2;

   while ( *str1 ) 
     {
       c1 = toupper ( ( int ) *str1++ );
       c2 = toupper ( ( int ) *str2++ );

       if ( c1 < c2 ) 
         {
           return -1;
         }
       else if ( c1 > c2 ) 
         {
           return 1;
         }
     }

   if ( *str2 ) 
     {
       return -1;
     } 
   else 
     {
       return 0;
     }
}

/*  ---------------------------------------------------------------------[<]-
    Function: strincmp

    Synopsis:
    A case insensitive strncmp.  Returns a pointer to head of the str1.
    ---------------------------------------------------------------------[>]-*/

int 
strincmp ( 
    const char *str1, 
    const char *str2, 
    int len )
{
   register char c1, c2;

   while ( *str1 ) 
     {
       c1 = toupper ( ( int ) *str1++ );
       c2 = toupper ( ( int ) *str2++ );
       len--;

       if ( c1 < c2 ) 
         {
           return -1;
         }
       else if ( c1 > c2 ) 
         {
           return 1;
         }

       if ( !len ) 
         {
           return 0;
         }
     }

   if ( *str2 || *str2 ) 
     {
       return -1;
     } 
   else 
     {
       return 0;
     }
}

/*  ---------------------------------------------------------------------[<]-
    Function: stristr

    Synopsis:
    A case insensitive strstr.  Returns a pointer to head of the str1.
    ---------------------------------------------------------------------[>]-*/

char *
stristr ( 
    const char *str1, 
    const char *str2 )
{
   char *strtmp = ( char * ) str1;
   int iret = 1;

   while ( *strtmp ) 
     {
       if ( strlen ( strtmp ) >= strlen ( str2 ) ) 
         {
           iret = strincmp ( strtmp, str2, strlen ( str2 ) );
         }
       else 
         {
           break;
         }

       if ( !iret ) 
         {
           break;
         }

       strtmp++;
     }

   return !iret ? strtmp : ( char * ) NULL;
}

/*  ---------------------------------------------------------------------[<]-
    Function: strtempcmp

    Synopsis:
    Compares a string to a template.
    Template chars and there functions:
      # or 9 = Number.
      A or _ = Alpha.
      @      = Alphanumeric
      \char  = Literal.  Char would be the literal to use. ie: "\%" -
               looks for a % in that postion
    Returns 0 if == to the template and 1 if != to the template.
    ---------------------------------------------------------------------[>]-*/

int 
strtempcmp ( 
    const char *str1, 
    const char *strPat )
{
   int ires = 1;

   while ( *str1 && *strPat ) 
     {
       switch ( ( int ) *strPat ) 
         {
           case '#':
           case '9':
              ires = isdigit ( ( int ) *str1 );
              break;

           case 'A':
           case '_':
              ires = isalpha ( ( int ) *str1 );
              break;

           case '@':
              ires = isalnum ( ( int ) *str1 );
              break;

           case ' ':
              ires = isspace ( ( int ) *str1 );
              break;

           case '\\':
              strPat++;
              if ( *str1 != *strPat ) 
                 {
                   ires = 1;
                 }
              break;

           default:
              break;
         }

       if ( !ires ) 
         {
           break;
         }

       str1++; 
       strPat++; 
     }

   return ires ? 0 : 1;
}

/*  ---------------------------------------------------------------------[<]-
    Function: istoken

    Synopsis:
    Eats strToEat from strBuff only if it begins with contents of
    strToEat, and returns a 0 or 1 to tell what it did.
   
    Usage:
       char strBuff[] = { "select * from mytbl;" };
       int iWasToken;
       istoken ( &strBuff, "SELECT", &iWasToken );

    On return here iWasToken would == 1, and strBuff would be:
    " * from mytbl;"
    If the token is not found, then strBuff will not be affected, and 
    a 0 will be returned. 
    ---------------------------------------------------------------------[>]-*/

int 
istoken ( 
    char **strLine, 
    const char *strtoken, 
    int *iWasToken )
{
   int iRet;
   char cChar;

   iRet = strincmp ( *strLine, strtoken, strlen ( strtoken ) );

   if ( !iRet ) 
     {
       cChar = *( *strLine + strlen ( strtoken ) );
       if ( !isalpha ( ( int ) cChar ) && cChar != '_' ) 
         {
           iRet = *iWasToken = 1;
           strcpy ( *strLine, ( *strLine + strlen ( strtoken ) ) );
         }
       else 
           iRet = *iWasToken = 0;
     }   

   else 
       iRet = *iWasToken = 0;

   return iRet;
}

/*  ---------------------------------------------------------------------[<]-
    Function: eatstr

    Synopsis:
    Eats strToEat from strBuff only if it begins with contents of
    strToEat.

    Usage:
       char strBuff[] = { "select * from mytbl;" };
       eatstr ( &strBuff, "SELECT" );

       On return here strBuff would be: " * from mytbl;"

    If the token is not found, then strBuff will not be affected and 
    a NULL char * will be returned, but any white spaces on the left
    of strBuff would be trimed. 
    ---------------------------------------------------------------------[>]-*/

char * 
eatstr ( 
    char **strBuff, 
    char *strToEat )
{
   int iWasToken;

   trimleft ( *strBuff );
   istoken ( strBuff, strToEat, &iWasToken );

   return iWasToken ? *strBuff : ( char * ) NULL;
}

/*  ---------------------------------------------------------------------[<]-
    Function: eatstrpast

    Synopsis:
    Eats chars past first occurrence of one of the chars contained in
    strCharsToEatPast.
    
    Usage:
       char strBuff[] = { " , 456, 789" };
       eatstrpast ( &strBuff, "," );

    On return here strBuff would be: " 456, 789".
    Returns a pointer to head of the input buffer.
    ---------------------------------------------------------------------[>]-*/

char *
eatstrpast ( 
    char **strBuff, 
    char *strCharsToEatPast )
{
   trimleft ( *strBuff );

   while ( **strBuff && strchr ( strCharsToEatPast, **strBuff ) )
      deletechar ( *strBuff, 0 );

   return *strBuff;
}

/*  ---------------------------------------------------------------------[<]-
    Function: movestrpast

    Synopsis:
    Eats chars past first occurrence of one of the chars contained in
    strCharsToEatPast.
    
    Usage:
       char strBuff[] = { "123, 456, 789" };
       movestrpast ( &strBuff, "," );

    On return here strBuff would be: " 456, 789".
    Returns a pointer to head of the input buffer.
    ---------------------------------------------------------------------[>]-*/

char *
movestrpast ( 
    char **strBuff, 
    char cCharToEatPast )
{
   trimleft ( *strBuff );

   while ( **strBuff && **strBuff != cCharToEatPast )
      deletechar ( *strBuff, 0 );

   if ( **strBuff && **strBuff == cCharToEatPast )
      deletechar ( *strBuff, 0 );

   return *strBuff;
}

/*  ---------------------------------------------------------------------[<]-
    Function: eatchar

    Synopsis:
    Trims white spaces and eats just past occurrence of cChar.  If
    contents of cChar is not found then only white spaces are trimmed.
   
    Usage:
       char strBuff[] = { "('test', 5)" };
       eatchar ( &strBuff, '(' );
    On return here strBuff would be: "'test', 5)".
    Returns a pointer to head of the input buffer.
    ---------------------------------------------------------------------[>]-*/

char *
eatchar ( 
    char **strBuff, 
    char cChar )
{
   trimleft ( *strBuff );
   if ( **strBuff && **strBuff == cChar )
      deletechar ( *strBuff, 0 );

   return *strBuff;
}

/*  ---------------------------------------------------------------------[<]-
    Function: isoneoftokens

    Synopsis:
    Eats strToEat from strBuff only if it begins with contents of
    strToEat, and returns a 0 or 1 to tell what it did. Returns 0
    if nothing found, and >= 1 which is an index of the one found.
    
    Usage:
       char strBuff[] = { "select * from mytbl;" };
       int iWasToken;
       isoneoftokens ( &strBuff, "INSERT|SELECT|DELETE", "|", &iWasToken );

       On return here iWasToken would == 1, and strBuff would be:
       " * from mytbl;" and the return value would be 2.  

    If the token is not found, then strBuff will not be affected, and 
    a 0 will be returned. 
    ---------------------------------------------------------------------[>]-*/

int 
isoneoftokens ( 
    char **strbuf, 
    char *strmat, 
    char *strsep, 
    int *iWasToken )
{
   int nstate = 0, cnt = 0, icmpres;
   int iLen;
   char *strtemp, cChar;

   while ( 1 ) 
     {
       iLen = getstrfldlen ( strmat, cnt, 0, strsep );
       strtemp = ( char * ) malloc ( iLen + 1 );
       getstrfld ( strmat, cnt, 0, strsep, strtemp );
       if ( *strtemp ) 
         {
           trim ( strtemp );
           icmpres = strincmp ( *strbuf, strtemp, strlen ( strtemp ) );

           if ( !icmpres ) 
             {
               cChar = *( *strbuf + strlen ( strtemp ) );
               if ( !isalpha ( ( int ) cChar ) && cChar != '_' ) 
                 {
                   *iWasToken = cnt + 1;
                   strcpy ( *strbuf, ( *strbuf + strlen ( strtemp ) ) );

                   nstate = cnt + 1;
                 }
               break; 
             }

            else 
              {
                if ( !strincmp ( *strbuf, strtemp, strlen ( strtemp ) ) ) 
                  {
                    cChar = *( *strbuf + strlen ( strtemp ) );
                    if ( !isalpha ( ( int ) cChar ) && cChar != '_' ) 
                      {
                        *iWasToken = cnt + 1;
                        strcpy ( *strbuf, ( *strbuf + strlen ( strtemp ) ) );

                        nstate = cnt + 1;
                      }
                    break; 
                  }
              }
         }         

       else 
         {
           *iWasToken = 0;
           nstate = 0;
           break; 
         }

       cnt++;
       free ( strtemp );
     }

   return nstate;
}
