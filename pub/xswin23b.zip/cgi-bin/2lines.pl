#! \depot\perl\bin\perl
  print "Content-type: text/html\n";
  print "\n";
  print "Perl: 1st line\n";
  print "Perl: 2nd line\n";
