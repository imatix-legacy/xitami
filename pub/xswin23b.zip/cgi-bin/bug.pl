#! c:\progra~1\xitami\addons\perl.exe

################################################
# START
read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
$top = 0;
foreach $pair (@pairs) {
			($name, $value) = split(/=/, $pair);
			
			$name =~ tr/+/ /;
			$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
			$name =~ s/~!/ ~!/g; # Stop people from using subshells to execute commands
			
			$value =~ tr/+/ /;
			$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
			$value =~ s/\r//g; # wipe out carriage returns
			$value =~ s/\n/\f/g; # replace linefeeds with formfeeds to not confuse the parser
			$value =~ s/~!/ ~!/g; # Stop people from using subshells to execute commands
	
	$INPUT{$name} = $value;
}




&showbug;

#######################
# Showing print bug
sub showbug {

print ("<HTML><body bgcolor=#FFFFFF #vlink=##0000FF text=#000000><center>You never see this line. But it is here. However the other\n");
print ("line shows up.  There are 2 lines here, why do I see only one??\n"); 

exit(0);
}
