#! d:\perl\bin\perl.exe

# build the messageboard page
# for the messageboard
#
# Robert C. Robinson
# 8 October 1997

# now get the URL to the cgi-bin
$CGIDIR = "http://bbs.graymist.com/cgi-bin";

# now get the webmaster's e-mail address
$WEBMASTER = "rrobin\@innet.com";

# now get the header page
$HEADER = "d:\\xiwin\\webpages\\pbvbdev\\msgbdhd.htm";

# now get the directory containing the messages
$MSGDIR = "d:\\xiwin\\webpages\\pbvbdev";

# now get the counter data file
$COUNTER = "d:\\xiwin\\webpages\\pbvbdev\\msgcount.dat";

# maximum number of messages
$MAXMSG = 100;

# ---- end of constants, change anything below here at your own risk ----

# now get the number of possible messages
open (FILE,"$COUNTER");

  @LINES=<FILE>;
  close(FILE);

  $SIZE=@LINES;

  $MAXmessages = $SIZE - $MAXMSG;
  if ($MAXmessages <=0)
  {
	$MAXmessages = 1;
  }

# start the basic webpage
open(WEB,"$HEADER");
@HDR = <WEB>;
close(WEB);
$HDRsize=@HDR;

print "Content-type: text/html\n\n";

for ($j=0;$j<=$HDRsize;$j++)
{

if (($HDR[$j] !=~ /<\/BODY>/) ||($HDR[$j] !=~ /<\/HTML>/))
{
	print $HDR[$j];
}
}


# now read the messages, one by one, and prepare a simple list.

for ($i=$SIZE; $i>=$MAXmessages; $i--)
{
	$m = "$MSGDIR\\$i.msg";
	open(FILEA,"$m");
	@MSGS=<FILEA>;
  	close(FILEA);
	
  	$numMSGs=@MSGS;
	if ($MSGS[0] ne "")
	{
	print "<B><CENTER><A HREF=\"$CGIDIR/vbdisplay.pl?$i\">MESSAGE #$i</A></CENTER></B>\n";
	print "<CENTER>$MSGS[0]</CENTER>";
	print "<CENTER>$MSGS[1]</CENTER>";
	}
}

# now delete the extra messages past the max allowed
for ($i=0; $i<=$MAXmessages -1; $i++)
{
$m = "$MSGDIR\\$i.msg";
unlink("$m");
}


# print out the footer
print "<HR>Any questions or comments?  Please e-mail the <A HREF=\"maito:$WEBMASTER\">Webmaster</A><BR>\n";
print "CGI programming by <A HREF=\"mailto:rrobin\@innet.com\">Robert C. Robinson</A>\n";

# close the webpage up
print "</BODY></HTML>\n";

# all done for this one

