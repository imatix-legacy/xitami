/*  ----------------------------------------------------------------<Prolog>-
    name:       sflcbox.h
    title:      Various c string and file functions
    package:    standard function library (sfl)

    Written:    92/10/28  iMatix SFL project team <sfl@imatix.com>
    Revised:    98/03/02

    synopsis:   Various C string and file functions, including
                simple parsing, searching, replacing functions.
                all written by Scott Beasley (jscottb@infoave.com)
                starting on 06-03-88 and continuing to 03-02-98.

    copyright:  Copyright (C) 1991-97 Imatix
    license:    this is free software; you can redistribute it and/or modify
                it under the terms of the sfl license agreement as provided
                in the file license.txt.  this software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _sflcbox_included               /*  allow multiple inclusions        */
#define _sflcbox_included

/*  Macros & defines                                                         */
#define mstrncpy(dest,src,len) {strncpy(dest,src,len);*(dest+len)='\0';}
#define cstrcpy(dest,src) {*dest=src;*(dest+1)='\0';}
#define deletechar(strbuf,pos) strcpy((strbuf+pos),(strbuf+pos+1))
#define deletechars(strbuf,pos,cnt) strcpy((strbuf+pos),(strbuf+pos+cnt))
#define getcommandlinearg(argnum) ((argnum)<=(argc-1))?argv[argnum]:""
#define numofcmdargs() ((argc-1)>0?argc-1:0)
#define checkargcnt(reqnum) ((argc-1)>=(reqnum)?1:0)
#define makearray(arrnm,type,size) (arrnm)=(type)malloc((size)*sizeof((type)))
#define freearray(arrname) free(arrname)

#define CPY 0
#define PTR 1

#define IGNORECASE 0
#define SENCECASE  1

/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "c" {
#endif

char *removechars     (char *strbuf, char *chrstorm);
char *replacechrswith (char *strbuf, char *chrstorm, char ctorlcwth);
char *insertstring    (char *strbuf, char *chrstoins, int pos);
char *insertchar      (char *strbuf, char chrtoins, int pos);
char *leftfill        (char *strbuf, char chrtofill, unsigned len);
char *rightfill       (char *strbuf, char chrtofill, unsigned len);
char *trimleft        (char *strbuf);
char *trimright       (char *strbuf);
char *trim            (char *strin);
char *searchreplace   (char *strbuf, char *strtofnd, char *strtoins);
char *deletestring    (char *strbuf, char *strtodel);
char *getstrfld       (char *strbuf, int fln, int ofset, char *sep, char *ret);
char *setstrfld       (char *strbf, int fln, int ofset, char *sep, char *ins);
int  getstrfldlen     (char *strbuf, int fln, int ofset, char *sep);
char *uppercase       (char *strbuf);
char *lowercase       (char *strbuf);
char *findstrinfile   (FILE *fp, char *strtofind, char *strretstr);
char *getequval       (char *strline, char *strretstr);
int  matchtable       (char *strbuf, char *strmatch, char *strsept, int ncse);
char *stringreplace   (char *strbuf, char *strpattern);
char *wordwrapstr     (char *strbuff, int iwid);
int  stricmp          (const char *str1, const char *str2);
int  strincmp         (const char *str1, const char *str2, int len);
char *stristr         (const char *str1, const char *str2);
int  strtempcmp       (const char *str1, const char *strPat);
int  IsToken          (char **strLine, const char *strtoken, int *iWasToken);
int  IsOneOfTokens    (char **strbuf, char *strmat, char *strsep, int *iWasTk);
char *eatstr          (char **strBuff, char *strToEat);
char *eatstrpast      (char **strBuff, char *strCharsToEatPast);
char *movestrpast     (char **strBuff, char cCharToEatPast);
char *eatchar         (char **strBuff, char cChar);

#ifdef __cplusplus
}
#endif

#endif
