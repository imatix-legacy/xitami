/*---------------------------------------------------------------------------
 *  xiadm08.h - HTML form definition
 *
 *  Generated 1998/05/21, 11:01:06 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM08__
#define __FORM_XIADM08__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM08_MESSAGE_TO_USER             0
#define XIADM08_MAIN_CONFIG                 1
#define XIADM08_L_LOGFILE                   2
#define XIADM08_L_ENABLED                   3
#define XIADM08_L_CYCLE                     4
#define XIADM08_LOGTYPE_1                   5
#define XIADM08_LOGFILE_1                   6
#define XIADM08_ENABLED_1                   7
#define XIADM08_CYCLE_1                     8
#define XIADM08_LOGTYPE_2                   9
#define XIADM08_LOGFILE_2                   10
#define XIADM08_ENABLED_2                   11
#define XIADM08_CYCLE_2                     12
#define XIADM08_LOGTYPE_3                   13
#define XIADM08_LOGFILE_3                   14
#define XIADM08_ENABLED_3                   15
#define XIADM08_CYCLE_3                     16
#define XIADM08_L_NONAME7                   17

/*  This table contains each block in the form                               */

static byte xiadm08_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - Log Files</TITLE>                     */
    0, 50, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'L', 'o', 'g', 32, 'F', 'i', 'l',
    'e', 's', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 158, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  #(config) - Log Files                                                */
    0, 23, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'L', 'o', 'g', 32, 'F', 'i', 'l', 'e', 's', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  !--FIELD NUMERIC main_config SIZE=4 VALUE=1                          */
    0, 27, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'm', 'a', 'i', 'n',
    '_', 'c', 'o', 'n', 'f', 'i', 'g', 0, '1', 0,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 144,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 52, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD ALIGN=LEFT>                                                      */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>', 10,
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, 'c',
    /*  !--ACTION server  LABEL="Ser ... ENT=server_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 2, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  !--ACTION aliases  LABEL="Al ... NT=aliases_event TYPE=PLAIN         */
    0, 27, 20, 1, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 3, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  !--ACTION vhosts  LABEL="Vho ... ENT=vhosts_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 4, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 5, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... T=security_event TYPE=PLAIN         */
    0, 29, 20, 1, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 6, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  <EM>Logging</EM>                                                     */
    0, 18, 0, '<', 'E', 'M', '>', 'L', 'o', 'g', 'g', 'i', 'n', 'g',
    '<', '/', 'E', 'M', '>', 10,
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 7, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=PLAIN            */
    0, 21, 20, 1, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 8, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0, 'M',
    'I', 'M', 'E', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  <TABLE NOWRAP WIDTH= >                                               */
    0, 24, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, 'W', 'I', 'D', 'T', 'H', '=', 32, '>', 10,
    /*  <TR>                                                                 */
    0, 6, 0, '<', 'T', 'R', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 35, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f130 NAME=L_logfile VALUE="Filename:"               */
    0, 23, 10, 6, 1, 0, 0, 9, 0, 9, 'f', '1', '3', '0', 0, 'F', 'i',
    'l', 'e', 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 7, 0, '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 196,
    /*  !--FIELD TEXTUAL f131 NAME=L_enabled VALUE="On:"                     */
    0, 17, 10, 6, 1, 0, 0, 3, 0, 3, 'f', '1', '3', '1', 0, 'O', 'n',
    ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, 253,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 196,
    /*  !--FIELD TEXTUAL f132 NAME=L_cycle VALUE="Cycle:"                    */
    0, 20, 10, 6, 1, 0, 0, 6, 0, 6, 'f', '1', '3', '2', 0, 'C', 'y',
    'c', 'l', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, 253,
    /*  </TR>                                                                */
    0, 7, 0, '<', '/', 'T', 'R', '>', 10,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 151,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 28, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    10,
    /*  !--FIELD TEXTUAL f133 NAME=l ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 7, 1, 0, 0, 15, 0, 15, 'f', '1', '3', '3', 0, 0,
    /*  </TD>                                                                */
    0, 7, 0, '<', '/', 'T', 'D', '>', 10,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f134 NAME=l ... =16 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 16, 0, '(', 'f', '1', '3', '4', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD BOOLEAN f135 NAME=e ... 1 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '1', '3', '5', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD SELECT f136 NAME=cy ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 15, 0, 1, 1, 5, 'f', '1', '3', '6', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  </TR>                                                                */
    0, 4, 1, 0, 4, 'G',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 151,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 4, 'V',
    /*  !--FIELD TEXTUAL f137 NAME=l ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 7, 1, 0, 0, 15, 0, 15, 'f', '1', '3', '7', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD TEXTUAL f138 NAME=l ... =16 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 16, 0, '(', 'f', '1', '3', '8', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD BOOLEAN f139 NAME=e ... 2 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '1', '3', '9', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD SELECT f140 NAME=cy ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 15, 0, 1, 1, 5, 'f', '1', '4', '0', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  </TR>                                                                */
    0, 4, 1, 0, 4, 'G',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 151,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 4, 'V',
    /*  !--FIELD TEXTUAL f141 NAME=l ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 7, 1, 0, 0, 15, 0, 15, 'f', '1', '4', '1', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD TEXTUAL f142 NAME=l ... =16 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 16, 0, '(', 'f', '1', '4', '2', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD BOOLEAN f143 NAME=e ... 3 TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '1', '4', '3', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 4, 141,
    /*  !--FIELD SELECT f144 NAME=cy ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 15, 0, 1, 1, 5, 'f', '1', '4', '4', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 132,
    /*  </TR>                                                                */
    0, 4, 1, 0, 4, 'G',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 144,
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 4, 1, 0, 2, 13,
    /*  <TR><TD></TD><TD>                                                    */
    0, 19, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>', 10,
    /*  <P>                                                                  */
    0, 4, 1, 0, 6, 137,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f145 NAME=L ... UE="Actions for this page:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '1', '4', '5', 0, 'A', 'c',
    't', 'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's',
    32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 9, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 10, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 144,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 144,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm08_fields [] = {
    { 0, 113, 80 },                     /*  message_to_user                 */
    { 82, 412, 4 },                     /*  main_config                     */
    { 88, 996, 9 },                     /*  l_logfile                       */
    { 99, 1036, 3 },                    /*  l_enabled                       */
    { 104, 1067, 6 },                   /*  l_cycle                         */
    { 112, 1140, 15 },                  /*  logtype_1                       */
    { 129, 1197, 40 },                  /*  logfile_1                       */
    { 171, 1225, 1 },                   /*  enabled_1                       */
    { 174, 1256, 3 },                   /*  cycle_1                         */
    { 179, 1339, 15 },                  /*  logtype_2                       */
    { 196, 1367, 40 },                  /*  logfile_2                       */
    { 238, 1395, 1 },                   /*  enabled_2                       */
    { 241, 1426, 3 },                   /*  cycle_2                         */
    { 246, 1509, 15 },                  /*  logtype_3                       */
    { 263, 1537, 40 },                  /*  logfile_3                       */
    { 305, 1565, 1 },                   /*  enabled_3                       */
    { 308, 1596, 3 },                   /*  cycle_3                         */
    { 313, 1754, 22 },                  /*  l_noname7                       */
    { 337, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   main_config_a        ;
    char   main_config          [4 + 1];
    byte   l_logfile_a          ;
    char   l_logfile            [9 + 1];
    byte   l_enabled_a          ;
    char   l_enabled            [3 + 1];
    byte   l_cycle_a            ;
    char   l_cycle              [6 + 1];
    byte   logtype_1_a          ;
    char   logtype_1            [15 + 1];
    byte   logfile_1_a          ;
    char   logfile_1            [40 + 1];
    byte   enabled_1_a          ;
    char   enabled_1            [1 + 1];
    byte   cycle_1_a            ;
    char   cycle_1              [3 + 1];
    byte   logtype_2_a          ;
    char   logtype_2            [15 + 1];
    byte   logfile_2_a          ;
    char   logfile_2            [40 + 1];
    byte   enabled_2_a          ;
    char   enabled_2            [1 + 1];
    byte   cycle_2_a            ;
    char   cycle_2              [3 + 1];
    byte   logtype_3_a          ;
    char   logtype_3            [15 + 1];
    byte   logfile_3_a          ;
    char   logfile_3            [40 + 1];
    byte   enabled_3_a          ;
    char   enabled_3            [1 + 1];
    byte   cycle_3_a            ;
    char   cycle_3              [3 + 1];
    byte   l_noname7_a          ;
    char   l_noname7            [22 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   server_a;
    byte   aliases_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   ftp_a;
    byte   mime_a;
    byte   defaults_a;
    byte   undo_a;
    } XIADM08_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm08 = {
    xiadm08_blocks,
    xiadm08_fields,
    106,                                /*  Number of blocks in form        */
    18,                                 /*  Number of fields in form        */
    11,                                 /*  Number of actions in form       */
    337,                                /*  Size of fields                  */
    "xiadm08",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
