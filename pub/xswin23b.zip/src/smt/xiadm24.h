/*---------------------------------------------------------------------------
 *  xiadm24.h - HTML form definition
 *
 *  Generated 1998/05/21, 11:01:06 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM24__
#define __FORM_XIADM24__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define CLIENT_LIST_MAX                     16
#define XIADM24_MESSAGE_TO_USER             0
#define XIADM24_REFRESH_ON                  1
#define XIADM24_L_TYPE                      2
#define XIADM24_L_IPADDRESS                 3
#define XIADM24_L_USERNAME                  4
#define XIADM24_TYPE                        5
#define XIADM24_IPADDRESS                   6
#define XIADM24_USERNAME                    7
#define XIADM24_CLIENT_LIST                 8

/*  This table contains each block in the form                               */

static byte xiadm24_blocks [] = {
    /*  <HTML><HEAD><TITLE>Current HTTP & FTP Connections</TITLE>            */
    0, 59, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'C', 'u', 'r', 'r', 'e',
    'n', 't', 32, 'H', 'T', 'T', 'P', 32, '&', 32, 'F', 'T', 'P', 32,
    'C', 'o', 'n', 'n', 'e', 'c', 't', 'i', 'o', 'n', 's', '<', '/',
    'T', 'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 134, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  Current HTTP & FTP Connections                                       */
    0, 32, 0, 'C', 'u', 'r', 'r', 'e', 'n', 't', 32, 'H', 'T', 'T', 'P',
    32, '&', 32, 'F', 'T', 'P', 32, 'C', 'o', 'n', 'n', 'e', 'c', 't',
    'i', 'o', 'n', 's', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  !--FIELD NUMERIC refresh_on SIZE=4 VALUE=1                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r',
    'e', 's', 'h', '_', 'o', 'n', 0, '1', 0,
    /*  !--IF refresh_on                                                     */
    0, 5, 2, 0, 1, 0, 1,
    /*  <META HTTP-EQUIV="REFRESH" CONTENT="#(rate)">                        */
    0, 47, 0, '<', 'M', 'E', 'T', 'A', 32, 'H', 'T', 'T', 'P', 45, 'E',
    'Q', 'U', 'I', 'V', '=', '"', 'R', 'E', 'F', 'R', 'E', 'S', 'H',
    '"', 32, 'C', 'O', 'N', 'T', 'E', 'N', 'T', '=', '"', '#', '(', 'r',
    'a', 't', 'e', ')', '"', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 138,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 52, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD ALIGN=LEFT>                                                      */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>', 10,
    /*  !--ACTION close  LABEL="Close" EVENT=ok_event TYPE=BUTTON            */
    0, 23, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'c', 'l', 'o', 's', 'e', 0,
    'C', 'l', 'o', 's', 'e', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  <TABLE NOWRAP WIDTH=50% >                                            */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, 'W', 'I', 'D', 'T', 'H', '=', '5', '0', '%', 32, '>', 10,
    /*  <TR>                                                                 */
    0, 6, 0, '<', 'T', 'R', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f325 NAME=L_type VALUE="Type:"                      */
    0, 19, 10, 6, 1, 0, 0, 5, 0, 5, 'f', '3', '2', '5', 0, 'T', 'y',
    'p', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 7, 0, '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 241,
    /*  !--FIELD TEXTUAL f326 NAME=L ...  VALUE="Client IP address:"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '3', '2', '6', 0, 'C', 'l',
    'i', 'e', 'n', 't', 32, 'I', 'P', 32, 'a', 'd', 'd', 'r', 'e', 's',
    's', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, '&',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 241,
    /*  !--FIELD TEXTUAL f327 NAME=L_username VALUE="User name:"             */
    0, 24, 10, 6, 1, 0, 0, 10, 0, 10, 'f', '3', '2', '7', 0, 'U', 's',
    'e', 'r', 32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, '&',
    /*  !--REPEAT client_list  ROWS=16                                       */
    0, 7, 4, 0, 8, 0, 12, 0, 16,
    /*  </TR>                                                                */
    0, 7, 0, '<', '/', 'T', 'R', '>', 10,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 233,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f328 NAME=type SIZE=4 MAX=? UPPER=0 VALUE=""        */
    0, 14, 10, 0, 16, 0, 0, 4, 0, 4, 'f', '3', '2', '8', 0, 0,
    /*  </TD>                                                                */
    0, 7, 0, '<', '/', 'T', 'D', '>', 10,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 155,
    /*  !--FIELD TEXTUAL f329 NAME=i ... E=15 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 16, 0, 0, 15, 0, 15, 'f', '3', '2', '9', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 203,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 155,
    /*  !--FIELD TEXTUAL f330 NAME=u ... E=20 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 16, 0, 0, 20, 0, 20, 'f', '3', '3', '0', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 203,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 140,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 138,
    /*  !--ACTION refresh  LABEL="Re ... T=refresh_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) refresh_event / 256), (byte) ((word)
    refresh_event & 255), 0, 1, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r', 'e',
    's', 'h', 0, 'R', 'e', 'f', 'r', 'e', 's', 'h', 0,
    /*  !--FIELD NUMERIC client_list SIZE=4 VALUE=16                         */
    0, 28, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'c', 'l', 'i', 'e',
    'n', 't', '_', 'l', 'i', 's', 't', 0, '1', '6', 0,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 138,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm24_fields [] = {
    { 0, 122, 80 },                     /*  message_to_user                 */
    { 82, 406, 4 },                     /*  refresh_on                      */
    { 88, 785, 5 },                     /*  l_type                          */
    { 95, 821, 18 },                    /*  l_ipaddress                     */
    { 115, 867, 10 },                   /*  l_username                      */
    { 127, 955, 4 },                    /*  type                            */
    { 223, 986, 15 },                   /*  ipaddress                       */
    { 495, 1014, 20 },                  /*  username                        */
    { 847, 1077, 4 },                   /*  client_list                     */
    { 853, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   refresh_on_a         ;
    char   refresh_on           [4 + 1];
    byte   l_type_a             ;
    char   l_type               [5 + 1];
    byte   l_ipaddress_a        ;
    char   l_ipaddress          [18 + 1];
    byte   l_username_a         ;
    char   l_username           [10 + 1];
    byte   type_a               [16] ;
    char   type                 [16] [4 + 1];
    byte   ipaddress_a          [16] ;
    char   ipaddress            [16] [15 + 1];
    byte   username_a           [16] ;
    char   username             [16] [20 + 1];
    byte   client_list_a        ;
    char   client_list          [4 + 1];
    byte   close_a;
    byte   refresh_a;
    } XIADM24_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm24 = {
    xiadm24_blocks,
    xiadm24_fields,
    58,                                 /*  Number of blocks in form        */
    9,                                  /*  Number of fields in form        */
    2,                                  /*  Number of actions in form       */
    853,                                /*  Size of fields                  */
    "xiadm24",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
