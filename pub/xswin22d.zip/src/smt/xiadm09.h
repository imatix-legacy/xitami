/*---------------------------------------------------------------------------
 *  xiadm09.h - HTML form definition
 *
 *  Generated 1998/02/23,  8:49:03 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM09__
#define __FORM_XIADM09__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define MIME_LIST_MAX                       12
#define XIADM09_MESSAGE_TO_USER             0
#define XIADM09_L_MIME_EXT                  1
#define XIADM09_L_MIME_TYPE                 2
#define XIADM09_KEY                         3
#define XIADM09_MIME_EXT                    4
#define XIADM09_MIME_TYPE                   5
#define XIADM09_L_NONAME9                   6
#define XIADM09_MIME_LIST                   7

/*  This table contains each block in the form                               */

static byte xiadm09_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - MIME Types</TITLE>                    */
    0, 50, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'M', 'I', 'M', 'E', 32, 'T', 'y',
    'p', 'e', 's', '<', '/', 'T', 'I', 'T', 'L', 'E', '>',
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 31, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - MIME Types                                               */
    0, 23, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'M', 'I', 'M', 'E', 32, 'T', 'y', 'p', 'e', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 43, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, 'L',
    /*  !--ACTION server  LABEL="Ser ... ENT=server_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 2, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  !--ACTION aliases  LABEL="Al ... NT=aliases_event TYPE=PLAIN         */
    0, 27, 20, 1, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 3, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  !--ACTION vhosts  LABEL="Vho ... ENT=vhosts_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 4, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 5, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... T=security_event TYPE=PLAIN         */
    0, 29, 20, 1, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 6, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  !--ACTION logging  LABEL="Lo ... NT=logging_event TYPE=PLAIN         */
    0, 27, 20, 1, (byte) ((word) logging_event / 256), (byte) ((word)
    logging_event & 255), 0, 7, 0, 0, 0, 0, 0, 'l', 'o', 'g', 'g', 'i',
    'n', 'g', 0, 'L', 'o', 'g', 'g', 'i', 'n', 'g', 0,
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 8, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  <EM>MIME</EM>                                                        */
    0, 14, 0, '<', 'E', 'M', '>', 'M', 'I', 'M', 'E', '<', '/', 'E',
    'M', '>',
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <P>MIME types defined in addition to those in xitami.cfg:            */
    0, 58, 0, '<', 'P', '>', 'M', 'I', 'M', 'E', 32, 't', 'y', 'p', 'e',
    's', 32, 'd', 'e', 'f', 'i', 'n', 'e', 'd', 32, 'i', 'n', 32, 'a',
    'd', 'd', 'i', 't', 'i', 'o', 'n', 32, 't', 'o', 32, 't', 'h', 'o',
    's', 'e', 32, 'i', 'n', 32, 'x', 'i', 't', 'a', 'm', 'i', '.', 'c',
    'f', 'g', ':',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, '}', 0, 28,
    /*  !--FIELD TEXTUAL f141 NAME=L_mime-ext VALUE="File extension:"        */
    0, 28, 10, 6, 1, 0, 15, 0, 15, 'f', '1', '4', '1', 0, 'F', 'i', 'l',
    'e', 32, 'e', 'x', 't', 'e', 'n', 's', 'i', 'o', 'n', ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, '}', 0, 28,
    /*  !--FIELD TEXTUAL f142 NAME=L_mime-type VALUE="MIME type:"            */
    0, 23, 10, 6, 1, 0, 10, 0, 10, 'f', '1', '4', '2', 0, 'M', 'I', 'M',
    'E', 32, 't', 'y', 'p', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, 199,
    /*  !--REPEAT mime_list  ROWS=12                                         */
    0, 7, 4, 0, 7, 0, 12, 0, 12,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, 'v',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL f143 NAME=key SIZE=10 MAX=? VALUE=""                */
    0, 13, 10, 4, 12, 0, 10, 0, 10, 'f', '1', '4', '3', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL f144 NAME=mime-ext SIZE=10 MAX=? VALUE=""           */
    0, 13, 10, 0, 12, 0, 10, 0, 10, 'f', '1', '4', '4', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, ';',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 4, 'C',
    /*  !--FIELD TEXTUAL f145 NAME=mime-type SIZE=50 MAX=? VALUE=""          */
    0, 13, 10, 0, 12, 0, '2', 0, '2', 'f', '1', '4', '5', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, ';',
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 255,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'x',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  <TABLE WIDTH=100%>                                                   */
    0, 6, 1, 1, 0, 144, 0, 18,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL f146 NAME=L ... UE="Actions for this page:"         */
    0, 35, 10, 6, 1, 0, 22, 0, 22, 'f', '1', '4', '6', 0, 'A', 'c', 't',
    'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32,
    'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 9, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 10, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 11, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 12, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't',
    0, 'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'x',
    /*  !--FIELD NUMERIC mime_list SIZE=4 VALUE=12                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e',
    '_', 'l', 'i', 's', 't', 0, '1', '2', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <SCRIPT>                                                             */
    0, 9, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 194, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', '.',
    'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32, 'a',
    'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 'd', 'o', 'c', 'u',
    'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']',
    '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, '}', 10, 'f',
    'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o', 'c', 'u', 's', '(',
    ')', 32, '{', 10, 'i', 'f', 32, '(', '"', '#', '(', '_', 'f', 'o',
    'c', 'u', 's', ')', '"', 32, '!', '=', 32, '"', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '"', ')', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n',
    't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', '#', '(',
    '_', 'f', 'o', 'c', 'u', 's', ')', '.', 'f', 'o', 'c', 'u', 's',
    '(', ')', ';', 10, '}',
    /*  </SCRIPT>                                                            */
    0, 10, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 173, 0, 13,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 63, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'x',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm09_fields [] = {
    { 0, 111, 80 },                     /*  message_to_user                 */
    { 82, 937, 15 },                    /*  l_mime_ext                      */
    { 99, 983, 10 },                    /*  l_mime_type                     */
    { 111, 1068, 10 },                  /*  key                             */
    { 255, 1120, 10 },                  /*  mime_ext                        */
    { 399, 1147, 50 },                  /*  mime_type                       */
    { 1023, 1234, 22 },                 /*  l_noname9                       */
    { 1047, 1431, 4 },                  /*  mime_list                       */
    { 1053, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_mime_ext_a         ;
    char   l_mime_ext           [15 + 1];
    byte   l_mime_type_a        ;
    char   l_mime_type          [10 + 1];
    byte   key_a                [12] ;
    char   key                  [12] [10 + 1];
    byte   mime_ext_a           [12] ;
    char   mime_ext             [12] [10 + 1];
    byte   mime_type_a          [12] ;
    char   mime_type            [12] [50 + 1];
    byte   l_noname9_a          ;
    char   l_noname9            [22 + 1];
    byte   mime_list_a          ;
    char   mime_list            [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   server_a;
    byte   aliases_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   logging_a;
    byte   ftp_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM09_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm09 = {
    xiadm09_blocks,
    xiadm09_fields,
    71,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    13,                                 /*  Number of actions in form       */
    1053,                               /*  Size of fields                  */
    "xiadm09",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
