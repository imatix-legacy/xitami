/*---------------------------------------------------------------------------
 *  xiadm25.h - HTML form definition
 *
 *  Generated 1998/02/23,  8:49:03 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM25__
#define __FORM_XIADM25__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM25_MESSAGE_TO_USER             0
#define XIADM25_L_HOST_FILE                 1
#define XIADM25_HOST_FILE                   2
#define XIADM25_L_OVERWRITE                 3
#define XIADM25_OVERWRITE                   4
#define XIADM25_L_HOST_ADDR                 5
#define XIADM25_HOST_ADDR                   6
#define XIADM25_L_HOST_NAME                 7
#define XIADM25_HOST_NAME                   8
#define XIADM25_L_WEBPAGES                  9
#define XIADM25_WEBPAGES                    10
#define XIADM25_L_CGI_BIN                   11
#define XIADM25_CGI_BIN                     12
#define XIADM25_L_SUPERUSER                 13
#define XIADM25_SUPERUSER                   14
#define XIADM25_L_SHARELOGS                 15
#define XIADM25_SHARELOGS                   16
#define XIADM25_L_USE_ADMIN                 17
#define XIADM25_USE_ADMIN                   18
#define XIADM25_L_ADMIN_USER                19
#define XIADM25_ADMIN_USER                  20
#define XIADM25_L_ADMIN_PASS                21
#define XIADM25_ADMIN_PASS                  22

/*  This table contains each block in the form                               */

static byte xiadm25_blocks [] = {
    /*  <HTML><HEAD><TITLE>Virtual Host Wizard</TITLE>                       */
    0, 47, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'V', 'i', 'r', 't', 'u',
    'a', 'l', 32, 'H', 'o', 's', 't', 32, 'W', 'i', 'z', 'a', 'r', 'd',
    '<', '/', 'T', 'I', 'T', 'L', 'E', '>',
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 31, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  Virtual Host Wizard                                                  */
    0, 20, 0, 'V', 'i', 'r', 't', 'u', 'a', 'l', 32, 'H', 'o', 's', 't',
    32, 'W', 'i', 'z', 'a', 'r', 'd',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <HR><H2><A NAME="TOC2">Virtual Host Wizard</A></H2>                  */
    0, 52, 0, '<', 'H', 'R', '>', '<', 'H', '2', '>', '<', 'A', 32, 'N',
    'A', 'M', 'E', '=', '"', 'T', 'O', 'C', '2', '"', '>', 'V', 'i',
    'r', 't', 'u', 'a', 'l', 32, 'H', 'o', 's', 't', 32, 'W', 'i', 'z',
    'a', 'r', 'd', '<', '/', 'A', '>', '<', '/', 'H', '2', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 43, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>',
    /*  <TABLE WIDTH=100%>                                                   */
    0, 6, 1, 1, 0, 141, 0, 18,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL f321 NAME=L ... eate virtual host profile:"         */
    0, 41, 10, 6, 1, 0, 28, 0, 28, 'f', '3', '2', '1', 0, 'C', 'r', 'e',
    'a', 't', 'e', 32, 'v', 'i', 'r', 't', 'u', 'a', 'l', 32, 'h', 'o',
    's', 't', 32, 'p', 'r', 'o', 'f', 'i', 'l', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--FIELD TEXTUAL f322 NAME=host-file SIZE=12 MAX=40 VALUE=""         */
    0, 13, 10, 0, 1, 0, 12, 0, '(', 'f', '3', '2', '2', 0, 0,
    /*  .cfg extension is assumed                                            */
    0, 26, 0, '.', 'c', 'f', 'g', 32, 'e', 'x', 't', 'e', 'n', 's', 'i',
    'o', 'n', 32, 'i', 's', 32, 'a', 's', 's', 'u', 'm', 'e', 'd',
    /*  !--FIELD TEXTUAL f323 NAME=L ... ;&nbsp;Overwrite existing?"         */
    0, 44, 10, 6, 1, 0, 31, 0, 31, 'f', '3', '2', '3', 0, '&', 'n', 'b',
    's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', 'O', 'v', 'e', 'r',
    'w', 'r', 'i', 't', 'e', 32, 'e', 'x', 'i', 's', 't', 'i', 'n', 'g',
    '?', 0,
    /*  !--FIELD BOOLEAN f324 NAME=o ... e TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '2', '4', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 18, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>',
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 134,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f325 NAME=L ...  VALUE="Select IP address:"         */
    0, 31, 10, 6, 1, 0, 18, 0, 18, 'f', '3', '2', '5', 0, 'S', 'e', 'l',
    'e', 'c', 't', 32, 'I', 'P', 32, 'a', 'd', 'd', 'r', 'e', 's', 's',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD SELECT f326 NAME=ho ... pe=dynamic 0="No selection"         */
    0, 25, 15, 0, 1, 1, 0, 'f', '3', '2', '6', 0, '0', 0, 'N', 'o', 32,
    's', 'e', 'l', 'e', 'c', 't', 'i', 'o', 'n', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f327 NAME=L ... ="Or, enter DNS host name:"         */
    0, 37, 10, 6, 1, 0, 24, 0, 24, 'f', '3', '2', '7', 0, 'O', 'r', ',',
    32, 'e', 'n', 't', 'e', 'r', 32, 'D', 'N', 'S', 32, 'h', 'o', 's',
    't', 32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD TEXTUAL f328 NAME=host-name SIZE=50 MAX=? VALUE=""          */
    0, 13, 10, 0, 1, 0, '2', 0, '2', 'f', '3', '2', '8', 0, 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 2, 246,
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 134,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f329 NAME=L ... ="Web page root directory:"         */
    0, 37, 10, 6, 1, 0, 24, 0, 24, 'f', '3', '2', '9', 0, 'W', 'e', 'b',
    32, 'p', 'a', 'g', 'e', 32, 'r', 'o', 'o', 't', 32, 'd', 'i', 'r',
    'e', 'c', 't', 'o', 'r', 'y', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD TEXTUAL f330 NAME=webpages SIZE=50 MAX=? VALUE=""           */
    0, 13, 10, 0, 1, 0, '2', 0, '2', 'f', '3', '3', '0', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f331 NAME=L ...  VALUE="CGI-bin directory:"         */
    0, 31, 10, 6, 1, 0, 18, 0, 18, 'f', '3', '3', '1', 0, 'C', 'G', 'I',
    45, 'b', 'i', 'n', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o', 'r', 'y',
    ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD TEXTUAL f332 NAME=cgi-bin SIZE=50 MAX=? VALUE=""            */
    0, 13, 10, 0, 1, 0, '2', 0, '2', 'f', '3', '3', '2', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f333 NAME=L ... VALUE="Superuser password:"         */
    0, 32, 10, 6, 1, 0, 19, 0, 19, 'f', '3', '3', '3', 0, 'S', 'u', 'p',
    'e', 'r', 'u', 's', 'e', 'r', 32, 'p', 'a', 's', 's', 'w', 'o', 'r',
    'd', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD TEXTUAL f334 NAME=superuser SIZE=20 MAX=? VALUE=""          */
    0, 13, 10, 0, 1, 0, 20, 0, 20, 'f', '3', '3', '4', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f335 NAME=L ... LUE="Uses shared logfiles?"         */
    0, 34, 10, 6, 1, 0, 21, 0, 21, 'f', '3', '3', '5', 0, 'U', 's', 'e',
    's', 32, 's', 'h', 'a', 'r', 'e', 'd', 32, 'l', 'o', 'g', 'f', 'i',
    'l', 'e', 's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD BOOLEAN f336 NAME=s ... s TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '3', '6', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f337 NAME=L ... n use Browser-Based Admin?"         */
    0, 41, 10, 6, 1, 0, 28, 0, 28, 'f', '3', '3', '7', 0, 'C', 'a', 'n',
    32, 'u', 's', 'e', 32, 'B', 'r', 'o', 'w', 's', 'e', 'r', 45, 'B',
    'a', 's', 'e', 'd', 32, 'A', 'd', 'm', 'i', 'n', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD BOOLEAN f338 NAME=u ...  TRUE=yes FALSE=no VALUE=no         */
    0, 17, 14, 0, 1, 'f', '3', '3', '8', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 13,
    /*  !--FIELD TEXTUAL f339 NAME=L ... ser VALUE="If so, user id:"         */
    0, 28, 10, 6, 1, 0, 15, 0, 15, 'f', '3', '3', '9', 0, 'I', 'f', 32,
    's', 'o', ',', 32, 'u', 's', 'e', 'r', 32, 'i', 'd', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, '`',
    /*  !--FIELD TEXTUAL f340 NAME=admin-user SIZE=20 MAX=? VALUE=""         */
    0, 13, 10, 0, 1, 0, 20, 0, 20, 'f', '3', '4', '0', 0, 0,
    /*  !--FIELD TEXTUAL f341 NAME=L ... "&nbsp;&nbsp;and password:"         */
    0, 38, 10, 6, 1, 0, 25, 0, 25, 'f', '3', '4', '1', 0, '&', 'n', 'b',
    's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', 'a', 'n', 'd', 32, 'p',
    'a', 's', 's', 'w', 'o', 'r', 'd', ':', 0,
    /*  !--FIELD TEXTUAL f342 NAME=admin-pass SIZE=20 MAX=? VALUE=""         */
    0, 13, 10, 0, 1, 0, 20, 0, 20, 'f', '3', '4', '2', 0, 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 2, 246,
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  <TR><TD></TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                      */
    0, 48, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P', 32, 'W', 'I', 'D', 'T',
    'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION create  LABEL="Cre ... NT=define_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 0, 0, 0, 0, 0, 0, 'c', 'r', 'e', 'a', 't',
    'e', 0, 'C', 'r', 'e', 'a', 't', 'e', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 16,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <SCRIPT>                                                             */
    0, 9, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 194, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', '.',
    'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32, 'a',
    'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 'd', 'o', 'c', 'u',
    'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']',
    '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, '}', 10, 'f',
    'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o', 'c', 'u', 's', '(',
    ')', 32, '{', 10, 'i', 'f', 32, '(', '"', '#', '(', '_', 'f', 'o',
    'c', 'u', 's', ')', '"', 32, '!', '=', 32, '"', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '"', ')', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n',
    't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', '#', '(',
    '_', 'f', 'o', 'c', 'u', 's', ')', '.', 'f', 'o', 'c', 'u', 's',
    '(', ')', ';', 10, '}',
    /*  </SCRIPT>                                                            */
    0, 10, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 170, 0, 13,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 63, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'r',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm25_fields [] = {
    { 0, 108, 80 },                     /*  message_to_user                 */
    { 82, 565, 28 },                    /*  l_host_file                     */
    { 112, 650, 40 },                   /*  host_file                       */
    { 154, 693, 31 },                   /*  l_overwrite                     */
    { 187, 739, 1 },                    /*  overwrite                       */
    { 190, 803, 18 },                   /*  l_host_addr                     */
    { 210, 842, 3 },                    /*  host_addr                       */
    { 215, 881, 24 },                   /*  l_host_name                     */
    { 241, 926, 50 },                   /*  host_name                       */
    { 293, 965, 24 },                   /*  l_webpages                      */
    { 319, 1010, 50 },                  /*  webpages                        */
    { 371, 1037, 18 },                  /*  l_cgi_bin                       */
    { 391, 1076, 50 },                  /*  cgi_bin                         */
    { 443, 1103, 19 },                  /*  l_superuser                     */
    { 464, 1143, 20 },                  /*  superuser                       */
    { 486, 1170, 21 },                  /*  l_sharelogs                     */
    { 509, 1212, 1 },                   /*  sharelogs                       */
    { 512, 1243, 28 },                  /*  l_use_admin                     */
    { 542, 1292, 1 },                   /*  use_admin                       */
    { 545, 1323, 15 },                  /*  l_admin_user                    */
    { 562, 1359, 20 },                  /*  admin_user                      */
    { 584, 1374, 25 },                  /*  l_admin_pass                    */
    { 611, 1414, 20 },                  /*  admin_pass                      */
    { 633, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_host_file_a        ;
    char   l_host_file          [28 + 1];
    byte   host_file_a          ;
    char   host_file            [40 + 1];
    byte   l_overwrite_a        ;
    char   l_overwrite          [31 + 1];
    byte   overwrite_a          ;
    char   overwrite            [1 + 1];
    byte   l_host_addr_a        ;
    char   l_host_addr          [18 + 1];
    byte   host_addr_a          ;
    char   host_addr            [3 + 1];
    byte   l_host_name_a        ;
    char   l_host_name          [24 + 1];
    byte   host_name_a          ;
    char   host_name            [50 + 1];
    byte   l_webpages_a         ;
    char   l_webpages           [24 + 1];
    byte   webpages_a           ;
    char   webpages             [50 + 1];
    byte   l_cgi_bin_a          ;
    char   l_cgi_bin            [18 + 1];
    byte   cgi_bin_a            ;
    char   cgi_bin              [50 + 1];
    byte   l_superuser_a        ;
    char   l_superuser          [19 + 1];
    byte   superuser_a          ;
    char   superuser            [20 + 1];
    byte   l_sharelogs_a        ;
    char   l_sharelogs          [21 + 1];
    byte   sharelogs_a          ;
    char   sharelogs            [1 + 1];
    byte   l_use_admin_a        ;
    char   l_use_admin          [28 + 1];
    byte   use_admin_a          ;
    char   use_admin            [1 + 1];
    byte   l_admin_user_a       ;
    char   l_admin_user         [15 + 1];
    byte   admin_user_a         ;
    char   admin_user           [20 + 1];
    byte   l_admin_pass_a       ;
    char   l_admin_pass         [25 + 1];
    byte   admin_pass_a         ;
    char   admin_pass           [20 + 1];
    byte   create_a;
    byte   cancel_a;
    } XIADM25_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm25 = {
    xiadm25_blocks,
    xiadm25_fields,
    84,                                 /*  Number of blocks in form        */
    23,                                 /*  Number of fields in form        */
    2,                                  /*  Number of actions in form       */
    633,                                /*  Size of fields                  */
    "xiadm25",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
