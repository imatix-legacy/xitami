/*---------------------------------------------------------------------------
 *  xiadm11.h - HTML form definition
 *
 *  Generated 1998/02/23,  8:49:03 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM11__
#define __FORM_XIADM11__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define CGI_ENVIR_LIST_MAX                  10
#define XIADM11_MESSAGE_TO_USER             0
#define XIADM11_L_CGI_ENVIR_NAME            1
#define XIADM11_L_CGI_ENVIR_VALUE           2
#define XIADM11_KEY                         3
#define XIADM11_CGI_ENVIR_NAME              4
#define XIADM11_CGI_ENVIR_VALUE             5
#define XIADM11_L_NONAME11                  6
#define XIADM11_CGI_ENVIR_LIST              7

/*  This table contains each block in the form                               */

static byte xiadm11_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) ... ific CGI Environment</TITLE>        */
    0, 64, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'S', 'p', 'e', 'c', 'i', 'f', 'i',
    'c', 32, 'C', 'G', 'I', 32, 'E', 'n', 'v', 'i', 'r', 'o', 'n', 'm',
    'e', 'n', 't', '<', '/', 'T', 'I', 'T', 'L', 'E', '>',
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 31, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - Specific CGI Environment                                 */
    0, 37, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'S', 'p', 'e', 'c', 'i', 'f', 'i', 'c', 32, 'C', 'G', 'I', 32, 'E',
    'n', 'v', 'i', 'r', 'o', 'n', 'm', 'e', 'n', 't',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 47, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>',
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 20, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 43, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, 142, 0, 28,
    /*  !--FIELD TEXTUAL f171 NAME=L_cgi-envir-name VALUE="Variable:"        */
    0, 22, 10, 6, 1, 0, 9, 0, 9, 'f', '1', '7', '1', 0, 'V', 'a', 'r',
    'i', 'a', 'b', 'l', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, 142, 0, 28,
    /*  !--FIELD TEXTUAL f172 NAME=L ... lue VALUE="Has this value:"         */
    0, 28, 10, 6, 1, 0, 15, 0, 15, 'f', '1', '7', '2', 0, 'H', 'a', 's',
    32, 't', 'h', 'i', 's', 32, 'v', 'a', 'l', 'u', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 210,
    /*  !--REPEAT cgi_envir_list  ROWS=10                                    */
    0, 7, 4, 0, 7, 0, 12, 0, 10,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 135,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL f173 NAME=key SIZE=20 MAX=? VALUE=""                */
    0, 13, 10, 4, 10, 0, 20, 0, 20, 'f', '1', '7', '3', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL f174 NAME=c ... name SIZE=20 MAX=? VALUE=""         */
    0, 13, 10, 0, 10, 0, 20, 0, 20, 'f', '1', '7', '4', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'K',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 3, 'S',
    /*  !--FIELD TEXTUAL f175 NAME=c ... ue SIZE=40 MAX=120 VALUE=""         */
    0, 13, 10, 0, 10, 0, '(', 0, 'x', 'f', '1', '7', '5', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'K',
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 15,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  <TABLE WIDTH=100%>                                                   */
    0, 6, 1, 1, 0, 158, 0, 18,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL f176 NAME=L ... UE="Actions for this page:"         */
    0, 35, 10, 6, 1, 0, 22, 0, 22, 'f', '1', '7', '6', 0, 'A', 'c', 't',
    'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32,
    'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 2, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 4, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 5, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't', 0,
    'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  !--FIELD NUMERIC cgi_envir_list SIZE=4 VALUE=10                      */
    0, 31, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'c', 'g', 'i', '_',
    'e', 'n', 'v', 'i', 'r', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <SCRIPT>                                                             */
    0, 9, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 194, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', '.',
    'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32, 'a',
    'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 'd', 'o', 'c', 'u',
    'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']',
    '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, '}', 10, 'f',
    'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o', 'c', 'u', 's', '(',
    ')', 32, '{', 10, 'i', 'f', 32, '(', '"', '#', '(', '_', 'f', 'o',
    'c', 'u', 's', ')', '"', 32, '!', '=', 32, '"', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '"', ')', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n',
    't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', '#', '(',
    '_', 'f', 'o', 'c', 'u', 's', ')', '.', 'f', 'o', 'c', 'u', 's',
    '(', ')', ';', 10, '}',
    /*  </SCRIPT>                                                            */
    0, 10, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 187, 0, 13,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 63, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 148,
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm11_fields [] = {
    { 0, 125, 80 },                     /*  message_to_user                 */
    { 82, 698, 9 },                     /*  l_cgi_envir_name                */
    { 93, 738, 15 },                    /*  l_cgi_envir_value               */
    { 110, 828, 20 },                   /*  key                             */
    { 330, 880, 20 },                   /*  cgi_envir_name                  */
    { 550, 907, 120 },                  /*  cgi_envir_value                 */
    { 1770, 994, 22 },                  /*  l_noname11                      */
    { 1794, 1191, 4 },                  /*  cgi_envir_list                  */
    { 1800, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_cgi_envir_name_a   ;
    char   l_cgi_envir_name     [9 + 1];
    byte   l_cgi_envir_value_a  ;
    char   l_cgi_envir_value    [15 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [20 + 1];
    byte   cgi_envir_name_a     [10] ;
    char   cgi_envir_name       [10] [20 + 1];
    byte   cgi_envir_value_a    [10] ;
    char   cgi_envir_value      [10] [120 + 1];
    byte   l_noname11_a         ;
    char   l_noname11           [22 + 1];
    byte   cgi_envir_list_a     ;
    char   cgi_envir_list       [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM11_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm11 = {
    xiadm11_blocks,
    xiadm11_fields,
    61,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    6,                                  /*  Number of actions in form       */
    1800,                               /*  Size of fields                  */
    "xiadm11",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
