/*---------------------------------------------------------------------------
 *  xiadm19.h - HTML form definition
 *
 *  Generated 1998/02/23,  8:49:03 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM19__
#define __FORM_XIADM19__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define FTP_DIR_USER_LIST_MAX               10
#define XIADM19_MESSAGE_TO_USER             0
#define XIADM19_L_USER_NAME                 1
#define XIADM19_L_ACCESSES                  2
#define XIADM19_KEY                         3
#define XIADM19_USER_NAME                   4
#define XIADM19_ACCESSES                    5
#define XIADM19_L_NONAME17                  6
#define XIADM19_FTP_DIR_USER_LIST           7

/*  This table contains each block in the form                               */

static byte xiadm19_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - User list for directory</TITLE>       */
    0, 63, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'U', 's', 'e', 'r', 32, 'l', 'i',
    's', 't', 32, 'f', 'o', 'r', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o',
    'r', 'y', '<', '/', 'T', 'I', 'T', 'L', 'E', '>',
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 31, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - User list for directory                                  */
    0, 36, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'U', 's', 'e', 'r', 32, 'l', 'i', 's', 't', 32, 'f', 'o', 'r', 32,
    'd', 'i', 'r', 'e', 'c', 't', 'o', 'r', 'y',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%>                       */
    0, 47, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>',
    /*  <TR><TD ALIGN=LEFT>                                                  */
    0, 20, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 43, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, 140, 0, 28,
    /*  !--FIELD TEXTUAL f272 NAME=L_user-name VALUE="User name:"            */
    0, 23, 10, 6, 1, 0, 10, 0, 10, 'f', '2', '7', '2', 0, 'U', 's', 'e',
    'r', 32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 2, 140, 0, 28,
    /*  !--FIELD TEXTUAL f273 NAME=L_accesses VALUE="Access rights:"         */
    0, 27, 10, 6, 1, 0, 14, 0, 14, 'f', '2', '7', '3', 0, 'A', 'c', 'c',
    'e', 's', 's', 32, 'r', 'i', 'g', 'h', 't', 's', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 209,
    /*  !--REPEAT ftp_dir_user_list  ROWS=10                                 */
    0, 7, 4, 0, 7, 0, 13, 0, 10,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 133,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL f274 NAME=key SIZE=20 MAX=? VALUE=""                */
    0, 13, 10, 4, 10, 0, 20, 0, 20, 'f', '2', '7', '4', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL f275 NAME=user-name SIZE=20 MAX=? VALUE=""          */
    0, 13, 10, 0, 10, 0, 20, 0, 20, 'f', '2', '7', '5', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'I',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 27,
    /*  !--FIELD TEXTUAL f276 NAME=accesses SIZE=5 MAX=? VALUE=""            */
    0, 13, 10, 0, 10, 0, 5, 0, 5, 'f', '2', '7', '6', 0, 0,
    /*  GPDMR, or *                                                          */
    0, 12, 0, 'G', 'P', 'D', 'M', 'R', ',', 32, 'o', 'r', 32, '*',
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'I',
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 13,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 146,
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  <TABLE WIDTH=100%>                                                   */
    0, 6, 1, 1, 0, 157, 0, 18,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL f277 NAME=L ... UE="Actions for this page:"         */
    0, 35, 10, 6, 1, 0, 22, 0, 22, 'f', '2', '7', '7', 0, 'A', 'c', 't',
    'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32,
    'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 2, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 4, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 5, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't', 0,
    'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 146,
    /*  !--FIELD NUMERIC ftp_dir_user_list SIZE=4 VALUE=10                   */
    0, 34, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'f', 't', 'p', '_',
    'd', 'i', 'r', '_', 'u', 's', 'e', 'r', '_', 'l', 'i', 's', 't', 0,
    '1', '0', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <SCRIPT>                                                             */
    0, 9, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 194, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', '.',
    'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32, 'a',
    'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 'd', 'o', 'c', 'u',
    'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']',
    '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, '}', 10, 'f',
    'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o', 'c', 'u', 's', '(',
    ')', 32, '{', 10, 'i', 'f', 32, '(', '"', '#', '(', '_', 'f', 'o',
    'c', 'u', 's', ')', '"', 32, '!', '=', 32, '"', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '"', ')', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n',
    't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', '#', '(',
    '_', 'f', 'o', 'c', 'u', 's', ')', '.', 'f', 'o', 'c', 'u', 's',
    '(', ')', ';', 10, '}',
    /*  </SCRIPT>                                                            */
    0, 10, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 186, 0, 13,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 63, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 146,
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm19_fields [] = {
    { 0, 124, 80 },                     /*  message_to_user                 */
    { 82, 696, 10 },                    /*  l_user_name                     */
    { 94, 737, 14 },                    /*  l_accesses                      */
    { 110, 826, 20 },                   /*  key                             */
    { 330, 878, 20 },                   /*  user_name                       */
    { 550, 905, 5 },                    /*  accesses                        */
    { 620, 1006, 22 },                  /*  l_noname17                      */
    { 644, 1203, 4 },                   /*  ftp_dir_user_list               */
    { 650, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_user_name_a        ;
    char   l_user_name          [10 + 1];
    byte   l_accesses_a         ;
    char   l_accesses           [14 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [20 + 1];
    byte   user_name_a          [10] ;
    char   user_name            [10] [20 + 1];
    byte   accesses_a           [10] ;
    char   accesses             [10] [5 + 1];
    byte   l_noname17_a         ;
    char   l_noname17           [22 + 1];
    byte   ftp_dir_user_list_a  ;
    char   ftp_dir_user_list    [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM19_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm19 = {
    xiadm19_blocks,
    xiadm19_fields,
    62,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    6,                                  /*  Number of actions in form       */
    650,                                /*  Size of fields                  */
    "xiadm19",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
