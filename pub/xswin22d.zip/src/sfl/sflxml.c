/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflxml.c
    Title:      XML (Extensible Markup Language) access functions
    Package:    Standard Function Library (SFL)

    Written:    98/02/25  iMatix SFL project team <sfl@imatix.com>
    Revised:    98/03/02

    Copyright:  Copyright (c) 1998 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflstr.h"                     /*  String functions                 */
#include "sfllist.h"                    /*  List access functions            */
#include "sflmem.h"                     /*  Memory access functions          */
#include "sflfile.h"                    /*  File access functions            */
#include "sfldate.h"                    /*  Date and time functions          */
#include "sflxml.h"                     /*  Prototypes for functions         */


/*- Local functions ---------------------------------------------------------*/

static int xml_save_item (FILE *xmlfile, XML_ITEM *item);


/*  ---------------------------------------------------------------------[<]-
    Function: xml_new

    Synopsis: Creates and initialises a new XML_ITEM item.  The item is set
    to link to itself, and its sublists are initialised to be empty.
    Returns the address of the created XML_ITEM item or NULL if there was
    not enough memory.  Sets the new item's name and value as specified;
    either of these arguments may be null.  If the parent argument is not
    null, attaches the new item to the end of the parent item list.
    ---------------------------------------------------------------------[>]-*/

XML_ITEM *
xml_new (
    XML_ITEM   *parent,
    const char *name,
    const char *value)
{
    XML_ITEM
        *item;

    list_create (item, sizeof (XML_ITEM));
    if (item)
      {
        list_reset (&item-> attrs);
        list_reset (&item-> children);
        item-> name  = mem_strdup (name);
        item-> value = mem_strdup (value);
        if (parent)
            list_relink_before (item, &parent-> children);

        return (item);
      }
    else
        return (NULL);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_free

    Synopsis: Frees all memory used by an XML_ITEM item and its children.
    ---------------------------------------------------------------------[>]-*/

void
xml_free (
    XML_ITEM *item)
{
    ASSERT (item);

    /*  Free attribute nodes for the item                                    */
    while (!list_empty (&item-> attrs))
        xml_free_attr (item-> attrs.next);

    /*  Free child nodes for the item                                        */
    while (!list_empty (&item-> children))
        xml_free (item-> children.next);

    /*  Now free this item itself                                            */
    list_unlink (item);                 /*  Unlink from its parent list      */
    mem_strfree (&item-> name);         /*  Free strings, if not null        */
    mem_strfree (&item-> value);
    mem_free    (item);                 /*  And free the item itself         */
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_attr

    Synopsis: Searches for the attribute with the specified name; if found,
    returns the address of the attribute node, otherwise returns NULL.
    ---------------------------------------------------------------------[>]-*/

XML_ATTR *
xml_attr (
    XML_ITEM   *item,
    const char *name)
{
    XML_ATTR
        *attr;

    ASSERT (item);
    ASSERT (name);

    FORLIST (attr, item-> attrs)
        if (streq (attr-> name, name))
            return (attr);

    return (NULL);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_put_attr

    Synopsis: Sets, modifies, or deletes an attribute for the specified item.
    The attribute name must be supplied.  If the value is NULL, any attribute
    with the specified name is deleted.  Otherwise the specified attribute is
    either created or modified accordingly.  Returns the number of attribute
    nodes created (-1, 0, or 1).
    ---------------------------------------------------------------------[>]-*/

int
xml_put_attr (
    XML_ITEM   *item,
    const char *name,
    const char *value)
{
    int
        feedback = 0;
    XML_ATTR
        *attr;

    ASSERT (item);
    ASSERT (name);

    attr = xml_attr (item, name);
    if (attr)
        if (value)                      /*  Value specified - update attr    */
          {
            mem_strfree (&attr-> value);
            attr-> value = mem_strdup (value);
          }
        else
          {
            xml_free_attr (attr);       /*  No value - delete attribute      */
            feedback = -1;
          }
    else
        if (value)                      /*  Value specified - update attr    */
          {
            list_create (attr, sizeof (XML_ATTR));
            if (attr)
              {
                attr-> name  = mem_strdup (name);
                attr-> value = mem_strdup (value);
                list_relink_before (attr, &item-> attrs);
                feedback = 0;
              }
          }
    return (feedback);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_get_attr

    Synopsis: Returns the value for the specified attribute, if it exists.
    Otherwise returns the default value.
    ---------------------------------------------------------------------[>]-*/

char *
xml_get_attr (
    XML_ITEM   *item,
    const char *name,
    const char *deflt)
{
    XML_ATTR
        *attr;

    ASSERT (item);
    ASSERT (name);

    attr = xml_attr (item, name);
    if (attr)
        return (attr-> value);
    else
        return (deflt);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_free_attr

    Synopsis: Frees all memory used by an XML_ATTR node.
    ---------------------------------------------------------------------[>]-*/

void
xml_free_attr (
    XML_ATTR *attr)
{
    ASSERT (attr);

    list_unlink (attr);
    mem_strfree (&attr-> name);
    mem_strfree (&attr-> value);
    mem_free (attr);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_load

    Synopsis: Loads the contents of an XML file into a new XML tree.  The XML
    data is not checked against a DTD.  Returns NULL if there was insufficient
    memory, or the XML file could not be read.  The XML tree always starts with
    a top-level item called 'XML' with these attributes:
    <TABLE>
    filename        Name of the XML input file
    filetime        Modification time of the file, "HHMMSSCC"
    filedate        Modification date of input file, "YYYYMMDD"
    </TABLE>
    Looks for the XML file on the specified path symbol, unless that is NULL.
    ---------------------------------------------------------------------[>]-*/

XML_ITEM *
xml_load (
    const char *pathsym,
    const char *filename)
{
    FILE
        *xmlfile;

    ASSERT (filename);
    if ((xmlfile = file_locate (pathsym, filename, NULL)) == NULL)
        return (NULL);                  /*  File not found                   */

#if UNDER_DEVELOPMENT
    /*  Store control variables in symbol table                              */
    if (xmlfile || load_symtab == NULL)
      {
        sym_assume_symbol (symtab, "filename", filename);
        sprintf (iniline, "%ld", timer_to_date (get_file_time (filename)));
        sym_assume_symbol (symtab, "filedate", iniline);
        sprintf (iniline, "%ld", timer_to_time (get_file_time (filename)));
        sym_assume_symbol (symtab, "filetime", iniline);
      }
    if (!xmlfile)
        return (symtab);                /*  File not found; empty table      */

    /*  Now load the ini file, starting from the beginning                   */
    fseek (xmlfile, 0, SEEK_SET);
    FOREVER
      {
        if (ini_scan_section (xmlfile, &keyword, &value))
          {
            if (section)
              {
                section_end = strchr (section, '\0');
                ASSERT (section_end);
                xstrcat (section, ":", keyword, NULL);
                sym_assume_symbol (symtab, section, value);
                *section_end = '\0';
              }
          }
        else
        if (keyword)                    /*  Found new section                */
          {
            section = keyword;
            sym_assume_symbol (symtab, section, "");
          }
        else
            break;
      }
    file_close (xmlfile);
    sym_sort_table (symtab, NULL);      /*  Sort table by symbol name        */
    return (symtab);
#endif
    return (NULL);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_save

    Synopsis: Saves an XML tree to the specified file.  Returns the number
    of items saved, or -1 if there was an error.
    ---------------------------------------------------------------------[>]-*/

int
xml_save (
    XML_ITEM   *item,
    const char *filename)
{
    FILE
        *xmlfile;                       /*  XML output stream                */
    int
        count;                          /*  How many symbols did we save?    */

    ASSERT (item);
    ASSERT (filename);

    if ((xmlfile = file_open (filename, 'w')) == NULL)
        return (-1);                    /*  No permission to write file      */

    /*  Write XML file header                                                */
    fprintf (xmlfile, "<?XML VERSION=\"1.0\"?>\n");

    /*  Output XML items and values using a recursive function               */
    count = xml_save_item (xmlfile, item);
    file_close (xmlfile);
    return (count);
}


static int
xml_save_item (FILE *xmlfile, XML_ITEM *item)
{
    int
        count = 1;                      /*  Count 1 for current item         */
    XML_ITEM
        *child;
    XML_ATTR
        *attr;

    /*  First output item name and attributes                                */
    fprintf (xmlfile, "<%s", item-> name);
    FORLIST (attr, item-> attrs)
        fprintf (xmlfile, " %s=\"%s\"", attr-> name, attr-> value);
    fprintf (xmlfile, ">%s", item-> value);

    /*  Now output each child item                                           */
    if (!list_empty (&item-> children))
      {
        fprintf (xmlfile, "\n");
        FORLIST (child, item-> children)
            count += xml_save_item (xmlfile, child);
      }
    fprintf (xmlfile, "</%s>\n", item-> name);
    return (count);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_changed

    Synopsis: Returns TRUE if the XML file loaded into the specified list
    has in the meantime been changed.  Returns FALSE if not.
    ---------------------------------------------------------------------[>]-*/

Bool
xml_changed (
    XML_ITEM *item)
{
    char
        *filename;

    ASSERT (item);

    /*  Date, time, and name of original XML file are in the list            */
    filename = xml_get_attr (item, "filename", NULL);
    if (filename
    &&  file_has_changed (filename,
                          atol (xml_get_attr (item, "filedate", "0")),
                          atol (xml_get_attr (item, "filetime", "0"))))
        return (TRUE);
    else
        return (FALSE);
}


/*  ---------------------------------------------------------------------[<]-
    Function: xml_refresh

    Synopsis: Refreshes an XML tree created by xml_load ().  If the original
    file (as specified by the 'filename' attribute of the root item) has
    been modified, reloads the whole XML file.  Returns TRUE if the XML file
    was actually reloaded, or FALSE if the file had not changed or could not
    be accessed, or if the XML tree was incorrectly created.
    ---------------------------------------------------------------------[>]-*/

Bool
xml_refresh (
    XML_ITEM *item)
{
    char
        *filename,
        *pathsym;

    ASSERT (item);
    if (ini_dyn_changed (item))
      {
        pathsym  = mem_strdup (xml_get_attr (item, "pathsym",  NULL));
        filename = mem_strdup (xml_get_attr (item, "filename", NULL));
        xml_free (item);                /*  Delete previous XML tree         */
        xml_load (pathsym, filename);
        mem_free (pathsym);
        mem_free (filename);
        return (TRUE);
      }
    return (FALSE);
}
