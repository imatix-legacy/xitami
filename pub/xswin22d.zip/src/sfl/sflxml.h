/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflxml.h
    Title:      XML (Extensible Markup Language) access functions
    Package:    Standard Function Library (SFL)

    Written:    98/02/25  iMatix SFL project team <sfl@imatix.com>
    Revised:    98/02/27

    Synopsis:   Provides functions to read and write XML files, and manipulate
                XML data in memory as list structures.  XML is the Extensible
                Markup Language.  Accepts this XML syntax:
                <item [attr=["]value["]]...>value [child]</item>

    Copyright:  Copyright (c) 1998 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SLFXML_INCLUDED                /*  Allow multiple inclusions        */
#define _SLFXML_INCLUDED

/* -------------------------------------------------------------------------
    An XML tree is built as the following recursive structure:

                   .---------.    .----------.
                 .-:  Attr   :<-->:   0..n   :  Attributes are not sorted.
    .----------. : :  Head   :    :   attrs  :
    :   Item   :-' `---------'    `----------'
    :   node   :-. .---------.    .----------.
    `----------' : :  Child  :<-->:   0..n   :  Each child node is the root
                 `-:  Head   :    : children :  of its own tree of nodes.
                   `---------'    `----------'
   ------------------------------------------------------------------------- */


/*- Structure definitions -------------------------------------------------- */

typedef struct _XML_ITEM {              /*  Item node definition             */
    struct _XML_ITEM
        *next,                          /*  Next item in list                */
        *prev;                          /*  Previous item in list            */
    LIST
        attrs,                          /*  List of attributes, 0 or more    */
        children;                       /*  List of children, 0 or more      */
    char
        *name,                          /*  Item name, allocated string      */
        *value;                         /*  Item value, allocated string     */
} XML_ITEM;

typedef struct _XML_ATTR {              /*  Attribute node definition        */
    struct _XML_ATTR
        *next,                          /*  Next attr in list                */
        *prev;                          /*  Previous attr in list            */
    char
        *name,                          /*  Attribute name                   */
        *value;                         /*  Attribute value, may be null     */
} XML_ATTR;


/*- Function prototypes ---------------------------------------------------- */

#ifdef __cplusplus
extern "C" {
#endif

XML_ITEM *xml_new       (XML_ITEM *parent, const char *name, const char *value);
void      xml_free      (XML_ITEM *item);
XML_ATTR *xml_attr      (XML_ITEM *item, const char *name);
int       xml_put_attr  (XML_ITEM *item, const char *name, const char *value);
char     *xml_get_attr  (XML_ITEM *item, const char *name, const char *deflt);
void      xml_free_attr (XML_ATTR *attr);
XML_ITEM *xml_load      (const char *pathsym, const char *filename);
int       xml_save      (XML_ITEM *item, const char *filename);
Bool      xml_changed   (XML_ITEM *item);
Bool      xml_refresh   (XML_ITEM *item);

#ifdef __cplusplus
}
#endif


#endif
