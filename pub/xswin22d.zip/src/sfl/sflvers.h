/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflvers.h
    Title:      Define SFL version
    Package:    Standard Function Library (SFL)

    Written:    96/11/21  iMatix SFL project team <sfl@imatix.com>
    Revised:    97/12/09

    Synopsis:   Defines the SFL_VERSION constant.
    Copyright:  Copyright (c) 1991-98 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLVERS_INCLUDED               /*  Allow multiple inclusions        */
#define _SFLVERS_INCLUDED

#define SFL_VERSION     "1.80"          /*  Main SFL version                 */

#endif
