/*  ----------------------------------------------------------------<Prolog>-
    Name:       testxml.c
    Title:      Test program for XML functions
    Package:    Standard Function Library (SFL)

    Written:    98/02/27  iMatix SFL project team <sfl@imatix.com>
    Revised:    98/02/27

    Copyright:  Copyright (c) 1998 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "sfl.h"

int main (int argc, char *argv [])
{
    XML_ITEM
        *root,
        *item;

    root = xml_new (NULL, "dialog", "some dialog");
    item = xml_new (root, "option-list", "");
    xml_new (item, "option", "schema=lrschema.c");
    xml_new (item, "option", "animate");
    xml_new (item, "option", "nosort");

    item = xml_new (root, "state", "After-Init");
    xml_put_attr (item, "first", "1");

    item = xml_new (root, "state", "Showing-Screen");

    item = xml_new (root, "state", "Defaults");
    xml_put_attr (item, "defaults", "1");

    xml_save (root, "test.xml");
    xml_free (root);
    mem_assert ();
    return (EXIT_SUCCESS);
}
