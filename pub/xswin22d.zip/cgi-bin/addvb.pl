#! d:\perl\bin\perl.exe

# adds messages to messageboard
# Robert C. Robinson
# 8 October 1997

# now get the URL to the cgi-bin
$CGIDIR = "http://127.0.0.1/cgi-bin";

# now get the URL to the NOHTML.HTM page
$NOHTML = "http://127.0.0.1/pbvbdev/nohtml.htm";

# Send E-Mail upon each addition, 1 = yes, 0 = no
$SENDEMAIL=0;

# where to send e-mail to
$EMAILTO = "ph\@imatix.com";

# from whom to send e-mail
$EMAILFROM = "ph\@imatix.com";

# location of blat
$BLAT = "d:\\blat\\blat";

# name of temporary text file used for email
$text = "temp.txt";

# now get the header page
$HEADER = "d:\\xiwin\\webpages\\pbvbdev\\msgbdhd.htm";

# now get the directory containing the messages
$MSGDIR = "d:\\xiwin\\webpages\\pbvbdev";

# now get the maximum number of primary messages
$MAXMSG = 100;

# now get the counter data file
$COUNTER = "d:\\xiwin\\webpages\\pbvbdev\\msgcount.dat";

#  -- end of constants, change anything below here at your own risk --

# now open up the message counter file and get the number of possible messages
open (FILE,"$COUNTER");

  @LINES=<FILE>;
  close(FILE);

  $SIZE=@LINES;

  $MAXmessages = $SIZE - $MAXMSG;
  if ($MAXmessages <=0)
  {
	$MAXmessages = 1;
  }


#  process info from form
read(STDIN,$in,$ENV{'CONTENT_LENGTH'});
  @in = split(/[&;]/,$in); 

  foreach $i (0 .. $#in) {
    # Convert plus's to spaces
    $in[$i] =~ s/\+/ /g;

    # Split into key and value.  
    ($key, $val) = split(/=/,$in[$i],2); # splits on the first =.

    # Convert %XX from hex numbers to alphanumeric
    $key =~ s/%(..)/pack("c",hex($1))/ge;
    $val =~ s/%(..)/pack("c",hex($1))/ge;

    # Associate key and value
    $in{$key} .= "\0" if (defined($in{$key})); # \0 is the multiple separator
    $in{$key} .= $val;

  }

# check against HTML code within the message
if (($in{'FROM'} =~ /</) || ($in{'SUBJECT'} =~ /</) || ($in{'MESSAGE'} =~/</) || ($in{'EMAIL'} =~ /</)) 
{
	printf "Location: $NOHTML\n\n";
}else{

# send e-mail
if ($SENDEMAIL==1)
{
	open (TEMP,">$text");
	printf TEMP "FROM: $in{'FROM'} ($in{'EMAIL'} \n";	
	printf TEMP "SUBJECT: $in{'SUBJECT'}\n";
	printf TEMP "MESSAGE:\n";
	printf TEMP "$in{'MESSAGE'}";
	close(TEMP);

#send the e-mail 
open (BLAT,"|$BLAT $text -t $EMAILTO -f $EMAILFROM -s \"$in{'SUBJECT'}\" -q");
close (BLAT);

unlink("$text");

}

# now open up the message counter file and get a new number for this message
open (FILE,"$COUNTER");

  @LINES=<FILE>;
  close(FILE);

  $SIZE=@LINES;

$counter = $SIZE + 1;


# now add a new counter to the message count
open (FILE,">>$COUNTER");
printf FILE "$counter\n";
close(FILE);

# now add the new message to the messages
$messagefile = "$MSGDIR\\$counter.msg";
open (FILE,">$messagefile");
printf FILE "FROM: <B><A HREF=\"mailto:$in{'EMAIL'}\">$in{'FROM'}</A></B>\n";
printf FILE "SUBJECT: $in{'SUBJECT'}\n";
printf FILE "MESSAGE:\n";
printf FILE "$in{'MESSAGE'}";
close(FILE);

# all done for this one
#Send them back to the messageboard

printf "Location: $CGIDIR/vbmsg.pl\n\n"
}
