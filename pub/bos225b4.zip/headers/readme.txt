Header file directory

To change the location of header files, modify the server:header-dir option.
