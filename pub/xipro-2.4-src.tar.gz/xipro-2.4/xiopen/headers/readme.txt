Header file directory

To change the location of heaer files, modify the server:header-dir option.
