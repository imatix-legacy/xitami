Readme.txt

Bootstrap is a simple project that provides the binaries you need to
install Xitami on a bare system.  This must be the first project
installed if you are doing a project-by-project installation.

