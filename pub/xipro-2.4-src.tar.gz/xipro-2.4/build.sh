#!/bin/sh
#
# Xitami/2.4 source package build script
#

# Check that IBASE is set
if [ -z "$IBASE" ]; then
    echo "build.sh E: Please set the IBASE environment variable to"
    echo "build.sh E: the directory where you wish to install Xitami"
    exit 1
fi

# If BOOM_MODEL is not set, set to release,st as default
if [ -z "$BOOM_MODEL" ]; then
    BOOM_MODEL=st,release
fi

# Build it
export IBASE
export BOOM_MODEL
echo "build.sh I: Building Xitami..."
sh ./boomake build
if [ $? -ne 0 ]; then
    echo "build.sh E: Failure building Xitami, Stop."
    exit 1
fi

# Install it
echo "build.sh I: Installing Xitami into $IBASE..."
sh ./boomake install
if [ $? -ne 0 ]; then
    echo "build.sh E: Failure installing Xitami, Stop."
    exit 1
fi
echo "build.sh I: Xitami successfully built and installed in $IBASE/xitami-24/app"

