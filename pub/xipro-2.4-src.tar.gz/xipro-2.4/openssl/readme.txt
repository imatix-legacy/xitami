This is OpenSSL compiled for Win32 and Linux.
