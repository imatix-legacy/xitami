/*===========================================================================*
 *                                                                           *
 *  smtssl.c - SMTSSL layer                                                  *
 *                                                                           *
 *  Copyright (c) 1991-2003 iMatix Corporation                               *
 *                                                                           *
 *  -------------- Commercially Licensed Source Code -------------           *
 *                                                                           *
 *  The source code you are now reading has been published under             *
 *  the iMatix General Terms of Business and you may only use it as          *
 *  described in the file 'license.gtb' accompanying this product.           *
 *                                                                           *
 *  This program is NOT licensed under the GPL and you may NOT use           *
 *  it in free software, nor redistribute it under any conditions            *
 *  except those set out in the iMatix General Terms of Business,            *
 *  Article 3.                                                               *
 *                                                                           *
 *  Contact iMatix Corporation by email at info@imatix.com, or by            *
 *  paper mail at iMatix Corporation, rue des Ateliers 13-15, 1080           *
 *  Bruxelles, Belgium.                                                      *
 *                                                                           *
 *  --------------------------------------------------------------           *
 *  This program is published under a dual license model.  It is             *
 *  published as free software under the GNU Public License, and             *
 *  as commercial software under the iMatix General Terms of                 *
 *  Business.                                                                *
 *  --------------------------------------------------------------           *
 *===========================================================================*/

#include "smtdefn.h"                    /*  SMT definitions                  */
#include "smtmsg.h"                     /*  SMT message functions            */
#include "smtsslm.h"                    /*  SMT SSL message functions        */

#if defined (USE_SSLEAY)
#   include "ssl_locl.h"                /*  SSLeay functions                 */
#   include "rand.h"                    /*  Random number functions          */
#   include "pem.h"                     /*  Certificate functions            */
#else
#   include <openssl/ssl.h>             /*  OpenSSL functions                */
#   include <openssl/err.h>             /*  Error functions                  */
#   include <openssl/rsa.h>             /*  RSA functions                    */
#   include <openssl/rand.h>            /*  Random number functions          */
#   include <openssl/pem.h>             /*  Certificate functions            */
#endif


/*- Definitions -------------------------------------------------------------*/

#if defined (AGENT_NAME)
#  undef AGENT_NAME
#endif

#define AGENT_NAME   "smtssl"           /*  Our public name                  */

#define BUFFER_SIZE  8192
#define MSG_MAX      BUFFER_SIZE + 64
#define BLOCK_SIZE   16384L

#define VHOST_ANY    "<any>"            /*  Basic non-virtual host           */

#define VERIFY_NONE             0
#define VERIFY_OPTIONAL         1
#define VERIFY_REQUIRED         2
#define VERIFY_OPTIONAL_NO_CA   3

#define SSLCONFIG(key)  sym_get_value (tcb-> config, key, "")

#define SSL_DEFAULT_CIPHERS "ALL:!LOW"


/*- Structures --------------------------------------------------------------*/

typedef struct {                        /*  Virtual host resources           */
    SYMTAB                              /*                                   */
        *config;                        /*    Configuration for host         */
    char
        *name;                          /*    Virtual host name              */
    SSL_CTX
        *ssl_context;                   /*    SSL context                    */
    SSL_METHOD
        *ssl_method;                    /*    SSL method                     */
} VHOST;

typedef struct                          /*  Thread context block:            */
{
    event_t thread_type;                /*    Thread type indicator          */
    SSL     *ssl;                       /*    SSL handle                     */
    QID      reply_to;                  /*    Message Queue to reply         */
    sock_t   handle;                    /*    Handle for i/o                 */
    char    *data;                      /*    Data buffer                    */
    char    *port;                      /*    Port to open                   */
    qbyte    user_tag;                  /*    Tag to return to user          */
    qbyte    read_size;                 /*    Read size                      */
    qbyte    write_size;                /*    Write size                     */
    qbyte    max_size;                  /*    Maximum data size              */
    char    *file_name;                 /*    File name                      */
    int      stream;                    /*    File i/o handle, if used       */
    long     file_size;                 /*    Size of file                   */
    long     start_slice;               /*    Start of slice, if any         */
    long     end_slice;                 /*    End slice, if any              */
    char    *f_config;                  /*    Configuration file name        */
    SYMTAB  *config;                    /*    Configuration value            */
    SYMTAB  *vhosts;                    /*    Virtual hosts table            */
    VHOST   *vhost;                     /*    Current virtual host           */
    SSL_CTX *ssl_context;               /*    SSL context                    */
} TCB;


/*- Function prototypes -----------------------------------------------------*/

#if defined (USE_SSLEAY)
static RSA  *tmp_rsa_cb        (SSL *ssl, int is_export);
#else
static RSA  *tmp_rsa_cb        (SSL *ssl, int is_export, int keylength);
#endif

static void  sendfmt_ssl_error (void);
static void  set_vhost_name    (SYMTAB *table, const char *name);
static void  free_vhost        (VHOST *host);
static char *get_asn1_utctime  (ASN1_UTCTIME *tm);
int          verify_callback   (int ok, X509_STORE_CTX *ctx);
void         ssl_info_callback (const SSL *s, int where, int ret);
static void  show_addresses    (void);
static void  set_timer_refresh (THREAD *thread);
static void  handle_ssl_error  (THREAD *thread, int feedback, char *action);


/*- Global variables used in this source file only --------------------------*/

static TCB
    *tcb;                               /*  Address thread contect block     */
static QID
    operq,                              /*  Operator console event queue     */
    timeq,                              /*  Timer agent event queue          */
    sockq;                              /*  Socket agent event queue         */
static byte
    msg_body [MSG_MAX];                 /*  Messages sent to other agents    */
static int
    msg_size;                           /*  Size of formatted msg_body       */
static DESCR                            /*  Descriptor for exdr_writed()     */
    msg = { MSG_MAX,  msg_body };
static char
    buffer [BUFFER_SIZE + 1];           /*  General-use string buffer        */
static int
    verify_depth = 10,
    verify_error = X509_V_OK;
static AGENT
    *this_agent;

#include "smtssl.d"                     /*  Include dialog data              */


/********************   INITIALISE AGENT - ENTRY POINT   *********************/

int smtssl_init (void)
{
    AGENT *agent;                       /*  Handle for our agent             */
    THREAD *thread;                     /*  Handle to various threads        */

#   include "smtssl.i"                  /*  Include dialog interpreter       */

    /*                      Method name      Event value     Priority        */
    /*  Shutdown event comes from Kernel                                     */
    method_declare (agent, "SHUTDOWN",       shutdown_event,
                                             SMT_PRIORITY_MAX);

    /*  Reply events from socket agent                                       */
    method_declare (agent, "SOCK_INPUT_OK",  ok_event,           0);
    method_declare (agent, "SOCK_OUTPUT_OK", ok_event,           0);
    method_declare (agent, "SOCK_READ_OK",   ok_event,           0);
    method_declare (agent, "SOCK_WRITE_OK",  ok_event,           0);
    method_declare (agent, "SOCK_CLOSED",    sock_closed_event,  0);
    method_declare (agent, "SOCK_ERROR",     sock_error_event,   0);
    method_declare (agent, "SOCK_TIMEOUT",   sock_timeout_event, 0);

    /*  Reply events from timer agent                                        */
    method_declare (agent, "TIME_ALARM",     timer_event, SMT_PRIORITY_LOW);

    /*  SSL methods                                                          */
    declare_ssl_open          (open_event,     0);
    declare_ssl_close         (close_event,    0);
    declare_ssl_restart       (restart_event,  SMT_PRIORITY_MAX);
    declare_ssl_read_request  (read_event,     0);
    declare_ssl_write_request (write_event,    0);
    declare_ssl_put_slice     (put_file_event, 0);

    /*  Private methods used between threads                                 */
    method_declare (agent, "_RELOAD",        timer_event,     0);

    /*  Private methods used to pass initial thread events                   */
    method_declare (agent, "_MASTER",        master_event,    0);
    method_declare (agent, "_OPEN",          open_event,      0);
    method_declare (agent, "_CLIENT",        client_event,    0);
    method_declare (agent, "_CANCEL",        cancel_event,    0);


    /*  Ensure that operator console is running, else start it up            */
    smtoper_init ();
    if ((thread = thread_lookup (SMT_OPERATOR, "")) != NULL)
        operq = thread-> queue-> qid;
    else
        return (-1);

    /*  Ensure that timer agent is running, else start it up                 */
    smttime_init ();
    if ((thread = thread_lookup (SMT_TIMER, "")) != NULL)
        timeq = thread-> queue-> qid;
    else
        return (-1);

    /*  Ensure that socket i/o agent is running, else start it up            */
    smtsock_init ();
    if ((thread = thread_lookup (SMT_SOCKET, "")) != NULL)
        sockq = thread-> queue-> qid;
    else
        return (-1);

    /*  Create initial thread to manage master port                          */
    if ((thread = thread_create (AGENT_NAME, "main")) != NULL)
      {
        SEND (&thread-> queue-> qid, "_MASTER", "");
        ((TCB *) thread-> tcb)-> thread_type = master_event;
        ((TCB *) thread-> tcb)-> handle      = 0;
      }
    else
        return (-1);

    this_agent = agent;                 /*  Handle to ourselves              */

    CRYPTO_mem_ctrl (CRYPTO_MEM_CHECK_ON);

    /*  Signal okay to caller that we initialised okay                       */
    return (0);
}


/*************************   INITIALISE THE THREAD   *************************/

MODULE initialise_the_thread (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    tcb-> ssl         = NULL;
    tcb-> data        = NULL;
    tcb-> file_name   = NULL;
    tcb-> ssl_context = NULL;
    tcb-> port        = NULL;
    tcb-> stream      = -1;

    if (tcb-> thread_type != open_event)
        tcb-> f_config = NULL;
    if (tcb-> thread_type != client_event)
        tcb-> vhosts = NULL;

}


/***************************   LOAD VIRTUAL HOSTS   **************************/

MODULE load_virtual_hosts (THREAD *thread)
{
    SYMBOL
        *vhsym,                         /*  Virtual host entry in table      */
        *symbol;                        /*  Virtual host name in config      */
    char
        *vhost_name,                    /*  Virtual host name, if any        */
        *vhost_file;                    /*  Virtual host config file         */
    VHOST
        *vhost;                         /*  Virtual host resource block      */
    SYMTAB
        *config;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    config = ini_dyn_load (NULL, tcb-> f_config);

    /*  Find and process all virtual host definitions.  For each virtual
     *  host, we create an entry in the vhosts table, and create the various
     *  resources that a virtual host needs (config table, logger, etc.)
     */
    if (tcb-> vhosts == NULL)
        tcb-> vhosts = sym_create_table ();

    for (symbol = config-> symbols; symbol; symbol = symbol-> next)
      {
        if (strprefixed (symbol-> name, "virtual-hosts:"))
          {
            /*  Get virtual host name, and required config file              */
            vhost_name = symbol-> name + strlen ("virtual-hosts:");
            vhost_file = symbol-> value;
            trace ("Loading SSL VH data for %s from %s",
                   vhost_name, vhost_file);

            if (file_is_readable (vhost_file))
              {
                /*  Host configuration already exist                         */
                vhsym = sym_lookup_symbol (tcb-> vhosts, vhost_name);
                if (vhsym != NULL)
                  {
                    vhost = vhsym-> data;
                    sym_empty_table  (vhost-> config);
                    if (vhost-> ssl_context != NULL)
                        SSL_CTX_free (vhost-> ssl_context);
                  }
                else
                  {
                    /*  Create new symbol for virtual host                   */
                    vhsym = sym_create_symbol (tcb-> vhosts, vhost_name, NULL);
                    vhost = mem_alloc (sizeof (VHOST));
                    vhsym-> data = vhost;
                    vhost-> name = mem_strdup (vhost_name);
                    vhost-> config = sym_create_table ();
                  }
                vhost-> ssl_context = NULL;
                vhost-> ssl_method  = NULL;
                ini_dyn_load (vhost-> config, tcb-> f_config);
                ini_dyn_load (vhost-> config, vhost_file);
                set_vhost_name   (vhost-> config, vhost-> name);
                trace ("- loading config data from %s", vhost_file);
              }
            else
              {
                sendfmt (&operq, "ERROR",
                                 "smtssl: config file '%s' not found - %s",
                                  vhost_file, strerror (errno));
              }
          }
      }
    trace ("Loading VH data for base host");

    vhsym = sym_lookup_symbol (tcb-> vhosts, VHOST_ANY);
    if (vhsym != NULL)
      {
        vhost = vhsym-> data;
        sym_empty_table  (vhost-> config);
      }
    else
      {
        /*  Create new symbol for virtual host                   */
        vhsym = sym_create_symbol (tcb-> vhosts, VHOST_ANY, NULL);
        vhost = mem_alloc (sizeof (VHOST));
        vhsym-> data = vhost;
        vhost-> name = mem_strdup (VHOST_ANY);
        vhost-> config = sym_create_table ();
      }
    ini_dyn_load (vhost-> config, tcb-> f_config);
    vhost-> ssl_context = NULL;
    vhost-> ssl_method  = NULL;

    /*  Set TCB for master thread to use default resources                   */
    tcb-> config = vhost-> config;

    if (*SSLCONFIG ("server:debug") == '1')
        enable_trace ();

    /*  Set verify depth default for all virtual host                        */
    verify_depth = atoi (SSLCONFIG ("ssl:verify-depth"));

    sym_delete_table (config);

    set_timer_refresh (thread);
}


/***********************   VERIFY SERVER CERTIFICATE   ***********************/

MODULE verify_server_certificate (THREAD *thread)
{
    char
        *key_file,                      /*  Private key file name            */
        *certificate_file;              /*  Server certificate file name     */
    SYMBOL
        *vhost_sym = NULL;              /*  Virtual host entry in table      */
    VHOST
        *vhost;                         /*  Virtual host resource block      */
    FILE
        *key;
    Bool
        private_key;                    /*  TRUE when read private key       */

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    /*  Verify server certificate for all virtual hosting                    */
    for (vhost_sym = tcb-> vhosts-> symbols;
         vhost_sym;
         vhost_sym = vhost_sym-> next)
      {
        vhost = (VHOST *) vhost_sym-> data;
        certificate_file = sym_get_value (vhost-> config, "ssl:cert-file",
                                                          NULL);
        if (certificate_file == NULL)
          {
            sendfmt (&operq, "ERROR",
                     "smtssl: no server certificate specified");
            raise_exception (fatal_event);
            return;
          }
        else
        if (!file_exists (certificate_file))
          {
            sendfmt (&operq, "ERROR",
                     "smtssl: server certificate '%s' not found",
                     certificate_file);
            raise_exception (fatal_event);
            return;
          }
        private_key = FALSE;
        key_file = sym_get_value (vhost-> config, "ssl:cert-key", NULL);
        if (key_file)
          {
            key = file_open (key_file, 'r');
            if (key)
              {
#if defined (USE_SSLEAY)
                if (PEM_read_RSAPrivateKey (key, NULL, NULL) != NULL)
#else
                if (PEM_read_RSAPrivateKey (key, NULL, NULL, NULL) != NULL)
#endif
                    private_key = TRUE;
                fclose (key);
              }
          }
        if (private_key == FALSE)
          {
            sendfmt (&operq, "ERROR", "smtssl: missing server private key");
            raise_exception (fatal_event);
            return;
          }
      }
}


/***************************   OPEN MASTER SOCKET   **************************/

MODULE open_master_socket (THREAD *thread)
{
    int
        old_portbase;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    if (*SSLCONFIG ("server:ipaddress") == '*')
        ip_passive = INADDR_ANY;
    else
        ip_passive = inet_addr (SSLCONFIG ("server:ipaddress"));

    tcb-> port  = mem_strdup (SSLCONFIG ("server:port"));

    /* Don't use port base for ssl                                           */
    old_portbase = ip_portbase;
    ip_portbase  = 0;

    tcb-> handle = passive_TCP (tcb-> port, 5);
    ip_portbase = old_portbase;

    sendfmt (&operq, "INFO",
                     "smtssl: preparing for connections on port %s",
                      tcb-> port);

    if (tcb-> handle != INVALID_SOCKET)
      {
        sendfmt (&operq, "INFO",
                 "smtssl: ready for SSL connections on port %s",
                 tcb-> port);
        send_ssl_open_ok (&tcb-> reply_to, (dbyte) atoi (tcb-> port));
        show_addresses ();
      }
    else
      {
        sendfmt (&operq, "ERROR",
                 "smtssl: could not open SSL port %s", tcb-> port);
        sendfmt (&operq, "ERROR",
                 "smtssl: %s", connect_errlist [connect_error ()]);
        sendfmt (&operq, "ERROR",
                 "smtssl: %s", sockmsg ());
        raise_exception (exception_event);
      }
}

/*************************   WAIT FOR SOCKET INPUT   *************************/

MODULE wait_for_socket_input (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    msg_size = exdr_writed (&msg, SMT_SOCK_INPUT, 0,
                            tcb-> handle, (qbyte) 0);
    event_send (
        &sockq,                         /*  Send to specified queue          */
        &thread-> queue-> qid,          /*  Queue for reply                  */
        "INPUT",                        /*  Name of event to send            */
        msg_body, msg_size,             /*  Event body and size              */
        NULL, NULL, NULL,               /*  No response events               */
        0);                             /*  No timeout                       */

    event_wait ();
}


/************************   ACCEPT CLIENT CONNECTION   ***********************/

MODULE accept_client_connection (THREAD *thread)
{
    sock_t
        slave_socket;                   /*  Connected socket                 */
    THREAD
        *child_thread;                  /*  Handle to child threads          */
    TCB
        *child_tcb;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    slave_socket = accept_socket (tcb-> handle);
    if (slave_socket != INVALID_SOCKET)
      {
        child_thread = thread_create (AGENT_NAME, "");
        if (child_thread)
          {
            SEND (&child_thread-> queue-> qid, "_CLIENT", "");
            child_tcb = (TCB *) child_thread-> tcb;
            child_tcb-> thread_type = client_event;
            child_tcb-> handle      = slave_socket;
            child_tcb-> reply_to    = tcb-> reply_to;
            child_tcb-> vhosts      = tcb-> vhosts;
          }
        else
            close_socket (slave_socket);
      }
    else
    if (sockerrno != EAGAIN && sockerrno != EWOULDBLOCK)
      {
        sendfmt (&operq, "ERROR",
                 "smtssl: could not accept connection: %s", sockmsg ());
        raise_exception (exception_event);
      }
}


/***************************   CHECK THREAD TYPE   ***************************/

MODULE check_thread_type (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    the_next_event = tcb-> thread_type;
}


/***************************   CREATE OPEN THREAD   **************************/

MODULE create_open_thread (THREAD *thread)
{
    THREAD
        *child_thread;                  /*  Handle to child threads          */
    struct_ssl_open
        *open;                          /*  Open message value               */
    TCB
        *child_tcb;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    child_thread = thread_create (AGENT_NAME, "");
    if (child_thread)
      {
        SEND (&child_thread-> queue-> qid, "_OPEN", "");
        child_tcb = (TCB *) child_thread-> tcb;
        child_tcb-> thread_type = open_event;
        child_tcb-> reply_to    = thread-> event-> sender;
        get_ssl_open (thread-> event-> body, &open);
        if (open)
          {
            child_tcb-> f_config = mem_strdup (open-> config);
            free_ssl_open (&open);
          }
      }
}


/***************************   CREATE NEW HANDLE   ***************************/

MODULE create_new_handle (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    tcb-> ssl = SSL_new (tcb-> ssl_context);
    if (tcb-> ssl)
        SSL_set_fd (tcb-> ssl, tcb-> handle);
    else
        raise_exception (exception_event);
}


/***************************   FREE ALL RESOURCES   **************************/

MODULE free_all_resources (THREAD *thread)
{
    SYMBOL
        *symbol;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    if (tcb-> vhosts)
      {
        for (symbol = tcb-> vhosts-> symbols; symbol; symbol = symbol-> next)
            free_vhost (symbol-> data);
        sym_delete_table (tcb-> vhosts);
      }

    ERR_remove_state (0);
    EVP_cleanup ();
}


/**************************   GET READ PARAMETERS   **************************/

MODULE get_read_parameters (THREAD *thread)
{
    struct_ssl_read_request
        *request;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    tcb-> read_size = 0;
    tcb-> reply_to  = thread-> event-> sender;

    get_ssl_read_request (thread-> event-> body, &request);
    if (request)
      {
        mem_strfree (&tcb-> data);
        tcb-> data = mem_alloc (request-> size);
        if (tcb-> data)
          {
            tcb-> max_size = request-> size;
            free_ssl_read_request (&request);
          }
        else
            raise_exception (exception_event);
      }
    else
      {
        sendfmt (&operq, "ERROR", "smtssl: out of memory");
        raise_exception (exception_event);
      }
}


/**************************   GET WRITE PARAMETERS   *************************/

MODULE get_write_parameters (THREAD *thread)
{
    struct_ssl_write_request
        *request;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    tcb-> read_size  = 0;
    tcb-> write_size = 0;
    tcb-> reply_to   = thread-> event-> sender;

    get_ssl_write_request (thread-> event-> body, &request);
    if (request)
      {
        mem_strfree (&tcb-> data);
        tcb-> data = mem_alloc (request-> size);
        if (tcb-> data)
          {
            tcb-> max_size = request-> size;
            tcb-> user_tag = request-> tag;
            memcpy (tcb-> data, request-> data, request-> size);
            free_ssl_write_request (&request);
          }
        else
            raise_exception (exception_event);
      }
    else
      {
        sendfmt (&operq, "ERROR", "smtssl: out of memory");
        raise_exception (exception_event);
      }
}


/****************************   LOAD SSL CONFIG   ****************************/

MODULE load_ssl_config (THREAD *thread)
{
    int
        server_verify;
    int
        length,
        verify_level;
    char
        *protocol,
        *required_ciphers,
        *ca_certificate;

    tcb = thread-> tcb;                 /*  Point to thread's context        */
    if (tcb-> vhost-> ssl_context == NULL)
      {
        SSLeay_add_ssl_algorithms ();
        SSL_load_error_strings    ();

        protocol = SSLCONFIG ("server:protocol");
        if (streq (protocol, "tlsv1"))
          {
            tcb-> vhost-> ssl_method  = TLSv1_server_method ();
            sendfmt (&operq, "INFO",
                     "smtssl: accepting only TLSv1 connections");
          }
        else
        if (streq (protocol, "sslv3"))
          {
            tcb-> vhost-> ssl_method  = SSLv3_server_method ();
            sendfmt (&operq, "INFO",
                     "smtssl: accepting only SSLv3 connections");
          }
        else
          {
            /*  Default is TLSv1 falling-back to SSLv3                       */
            tcb-> vhost-> ssl_method  = SSLv23_server_method ();
            sendfmt (&operq, "INFO",
                     "smtssl: accepting TLSv1/SSLv3 connections");
          }
        
        tcb-> vhost-> ssl_context = SSL_CTX_new (tcb-> vhost-> ssl_method);
        if (tcb-> vhost-> ssl_context == NULL)
            sendfmt_ssl_error ();

        if(!SSL_CTX_set_options (tcb-> vhost-> ssl_context,
                                 SSL_OP_ALL | SSL_OP_NO_SSLv2))
            sendfmt_ssl_error ();

        tcb-> ssl_context = tcb-> vhost-> ssl_context;

        /* Set verification level                                            */
        server_verify = 0;
        verify_level = atoi (SSLCONFIG ("ssl:verify-client"));
        switch (verify_level)
          {
            case VERIFY_REQUIRED:
                server_verify |= SSL_VERIFY_PEER
                                |SSL_VERIFY_FAIL_IF_NO_PEER_CERT;
                break;
            case VERIFY_OPTIONAL:
            case VERIFY_OPTIONAL_NO_CA:
                server_verify |= SSL_VERIFY_PEER;
                break;
          }

        SSL_CTX_set_verify (tcb-> ssl_context, server_verify, verify_callback);

        if (*SSLCONFIG ("server:debug") == '1')
            SSL_CTX_set_info_callback (tcb-> ssl_context, ssl_info_callback);

        SSL_CTX_set_tmp_rsa_callback (tcb-> ssl_context, tmp_rsa_cb);

        if (!SSL_CTX_use_certificate_file (tcb-> ssl_context,
                                           SSLCONFIG ("ssl:cert-file"),
                                           SSL_FILETYPE_PEM))
          {
            sendfmt (&operq, "ERROR",
                     "smtssl: certificate not found, or expired");
            sendfmt_ssl_error ();
            raise_exception (fatal_event);
            return;
          }
        if (!SSL_CTX_use_PrivateKey_file (tcb-> ssl_context,
                                          SSLCONFIG ("ssl:cert-key"),
                                          SSL_FILETYPE_PEM))
          {
            sendfmt (&operq, "ERROR",
                     "smtssl: private key file not found, or expired");
            sendfmt_ssl_error ();
            raise_exception (fatal_event);
            return;
          }
        ca_certificate = SSLCONFIG ("ssl:ca-cert-file");
        if (ca_certificate
        &&  strused (ca_certificate))
          {
            strcpy (buffer, SSLCONFIG ("ssl:ca-cert-path"));
            length = strlen (buffer);
            if (buffer [length - 1] != PATHEND)
                buffer [length++] = PATHEND;
            strcpy (&buffer [length], ca_certificate);
          }

        if (!SSL_CTX_load_verify_locations (tcb-> ssl_context,
                                            buffer,
                                            NULL)
            ||
            (!SSL_CTX_set_default_verify_paths (tcb-> ssl_context)))
          {
            sendfmt (&operq, "ERROR",
                     "smtssl: cannot locate Certificate Authority certificate");
            sendfmt_ssl_error ();
          }
        if (strused (buffer))
            SSL_CTX_set_client_CA_list (tcb-> ssl_context,
                                        SSL_load_client_CA_file (buffer));

        required_ciphers = SSLCONFIG ("ssl:required-ciphers");
        if (required_ciphers
        &&  strused (required_ciphers))
          {
            /* By default use all ciphers except insecure export versions   */
            if (strlen (required_ciphers) == 0)
              {
                xstrcpy (buffer, required_ciphers, SSL_DEFAULT_CIPHERS, NULL);
                required_ciphers = buffer;
              }
            if (!SSL_CTX_set_cipher_list (tcb-> ssl_context, required_ciphers))
              {
                sendfmt (&operq, "ERROR",
                         "smtssl: cannot set cipher list to '%s'",
                         required_ciphers);
                sendfmt_ssl_error ();
              }
          }

      }

    tcb-> ssl_context = tcb-> vhost-> ssl_context;
}


/**********************   RELOAD SSL CONFIG IF NEEDED   **********************/

MODULE reload_ssl_config_if_needed (THREAD *thread)
{
    SYMBOL
        *symbol;                        /*  Pointer to symbol                */
    VHOST
        *vhost;
    char
        *vhost_file;

    tcb = thread-> tcb;                 /*  Point to thread's context        */
    for (symbol = tcb-> vhosts-> symbols; symbol; symbol = symbol-> next)
      {
        vhost = symbol-> data;
        if (ini_dyn_changed (vhost-> config))
          {
            vhost_file = mem_strdup (sym_get_value
                             (vhost-> config, "filename", NULL));
            sym_empty_table  (vhost-> config);
            ini_dyn_load (vhost-> config, tcb-> f_config);
            ini_dyn_load (vhost-> config, vhost_file);
            set_vhost_name   (vhost-> config, vhost-> name);
            if (vhost-> ssl_context)
                SSL_CTX_free (vhost-> ssl_context);

            vhost-> ssl_context = NULL;
            vhost-> ssl_method  = NULL;
            mem_free (vhost_file);
            if (streq (vhost-> name, VHOST_ANY))
                set_timer_refresh (thread);
          }
      }
}


/*******************************   SEND DATA   *******************************/

MODULE send_data (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    send_ssl_read_ok (&tcb-> reply_to,
                     (word) tcb-> read_size, (byte *) tcb-> data);
}


/***************************   SIGNAL CONNECTION   ***************************/

MODULE signal_connection (THREAD *thread)
{
    const char
        *cipher,                        /*  Cipher used for this connection  */
        *version;
    char
        *user_name = NULL;              /*  User name in client certificate  */
    X509
        *certificate;                   /*  User certificate                 */

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    certificate = SSL_get_peer_certificate (tcb-> ssl);
    if (certificate)
        user_name = X509_NAME_oneline (X509_get_subject_name (certificate),
                                       NULL,0);
    cipher  = SSL_get_cipher  (tcb-> ssl);
    version = SSL_get_version (tcb-> ssl);
    xstrcpy (buffer, version, ": ", cipher, NULL);

    trace ("Connection: %s, %s", buffer, user_name? user_name: "none");
    send_ssl_accepted (&tcb-> reply_to, tcb-> handle, user_name, buffer, 0);

    if (user_name)
        free (user_name);
}


/***************************   SIGNAL DATA WRITED   **************************/

MODULE signal_data_writed (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    send_ssl_write_ok(&tcb-> reply_to, tcb-> handle, tcb-> user_tag);
}


/****************************   SIGNAL SSL ERROR   ***************************/

MODULE signal_ssl_error (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    sendfmt_ssl_error ();
    send_ssl_error (&tcb-> reply_to, 0);
}


/*******************************   SSL ACCEPT   ******************************/

MODULE ssl_accept (THREAD *thread)
{
    int
        feedback;                       /*  Return from SSL i/o operation    */
       
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    errno = 0;                          /*  Clear errno value before ssl     */
    tcb-> ssl-> rwstate = 0;
    feedback = SSL_accept (tcb-> ssl);

    if (feedback > 0)
      {
        if (SSL_is_init_finished (tcb-> ssl))
            the_next_event = ok_event;
        else
            the_next_event = retry_event;
      }
    else
        handle_ssl_error (thread, feedback, "accept");
}


/*  General error-handler for SSL i/o functions                              */

static void
handle_ssl_error (THREAD *thread, int feedback, char *action)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    switch (SSL_get_error (tcb-> ssl, feedback))
      {
        case SSL_ERROR_NONE:
            the_next_event = retry_event;
            break;
        case SSL_ERROR_WANT_READ:
            the_next_event = need_read_event;
            break;
        case SSL_ERROR_WANT_WRITE:
            the_next_event = need_write_event;
            break;

        case SSL_ERROR_SYSCALL:
            if (errno > 0 && errno != EACCES)
                sendfmt (&operq, "ERROR",
                    "smtssl: error on %s %d: %s", action, errno, strerror (errno));
            sendfmt_ssl_error ();
            raise_exception (exception_event);
            break;
        default:
            sendfmt_ssl_error ();
            raise_exception (exception_event);
            break;
      }
}


/********************************   SSL READ   *******************************/

MODULE ssl_read (THREAD *thread)
{
    int
        feedback;                       /*  Return code from read            */

    tcb = thread-> tcb;                 /*  Point to thread's context        */
    errno = 0;                          /*  Clear errno value before ssl     */

    feedback = SSL_read (tcb-> ssl, tcb-> data, tcb-> max_size);
    if (feedback > 0)
      {
        the_next_event  = ok_event;
        tcb-> read_size = feedback;
        if (feedback < (int)tcb-> max_size)
            tcb-> data [feedback] = '\0';
      }
    else
        handle_ssl_error (thread, feedback, "read");
}


/*******************************   SSL WRITE   *******************************/

MODULE ssl_write (THREAD *thread)
{
    int
        feedback;                       /*  Return code from read            */

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    errno = 0;                          /*  Clear errno value before ssl     */
    feedback = SSL_write (tcb-> ssl, tcb-> data, tcb-> max_size);
    if (feedback > 0)
      {
        the_next_event  = ok_event;
        tcb-> write_size += feedback;
      }
    else
        handle_ssl_error (thread, feedback, "write");
}


/*************************   WAIT FOR SOCKET OUTPUT   ************************/

MODULE wait_for_socket_output (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    msg_size = exdr_writed (&msg, SMT_SOCK_OUTPUT, 0,
                            tcb-> handle, (qbyte) 0);
    event_send (
        &sockq,                         /*  Send to specified queue          */
        &thread-> queue-> qid,          /*  Queue for reply                  */
        "OUTPUT",                       /*  Name of event to send            */
        msg_body, msg_size,             /*  Event body and size              */
        NULL, NULL, NULL,               /*  No response events               */
        0);                             /*  No timeout                       */

    event_wait ();
}


/**************************   OPEN FILE FOR INPUT   **************************/

MODULE open_file_for_input (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    tcb-> file_size = 0;
    tcb-> stream = lazy_open (tcb-> file_name, O_RDONLY);
    if (io_completed)
      {
        if (tcb-> stream < 0)           /*  If the open failed, send error   */
          {                             /*    to console, and terminate      */
            sendfmt (&operq, "ERROR",
                     "smtssl: could not open %s for input", tcb-> file_name);
            raise_exception (exception_event);
          }
        else
          {
            mem_strfree (&tcb-> data);
            tcb-> data = mem_alloc (BLOCK_SIZE);
            if (tcb-> start_slice > 0)  /*  Position at start of slice?      */
                lseek (tcb-> stream, tcb-> start_slice, SEEK_SET);
          }
      }
}


/*************************   READ FILE DATA BUFFER   *************************/

MODULE read_file_data_buffer (THREAD *thread)
{
    long
        read_size;                      /*  Amount of data read/to read      */

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    if (tcb-> end_slice > 0)            /*  End at end of slice?             */
      {
        read_size = tcb-> end_slice - tcb-> file_size;
        if (read_size < 0)
            read_size = 0;
        else
        if (read_size > BLOCK_SIZE)
            read_size = BLOCK_SIZE;
      }
    else
        read_size = BLOCK_SIZE;

    read_size = lazy_read (tcb-> stream, tcb-> data, (int) read_size);
    if (io_completed)
      {
        if (read_size == 0)
            raise_exception (end_of_file_event);
        else
        if (read_size == -1)            /*  If the read failed, send error   */
          {                             /*    to console, and terminate      */
            sendfmt (&operq, "ERROR",
                     "smtssl: could not read from %s", tcb-> file_name);
            raise_exception (exception_event);
          }
        else
            tcb-> max_size = read_size;
      }
}


/***************************   SIGNAL PUT FILE OK   **************************/

MODULE signal_put_file_ok (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    send_ssl_put_slice_ok (&tcb-> reply_to, tcb-> write_size);
}



/*******************************   CLOSE FILE   ******************************/

MODULE close_file (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    lazy_close (tcb-> stream);
    if (io_completed)
        tcb-> stream = -1;
}


/************************   GET PUT FILE PARAMETERS   ************************/

MODULE get_put_file_parameters (THREAD *thread)
{
    struct_ssl_put_slice
        *data;

    tcb = thread-> tcb;                 /*  Point to thread's context        */
    tcb-> write_size = 0;

    get_ssl_put_slice (thread-> event-> body, &data);
    if (data)
      {
        mem_strfree (&tcb-> file_name);
        tcb-> file_name = mem_strdup (data-> filename);
        tcb-> start_slice = data-> start;
        tcb-> end_slice   = data-> end;
        free_ssl_put_slice (&data);
      }
    else
        raise_exception (exception_event);
}


/*************************   PARTIAL CLEAR CONTEXT   *************************/

MODULE partial_clear_context (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    mem_strfree (&tcb-> data);
    mem_strfree (&tcb-> file_name);
}


/****************************   GET VIRTUAL HOST   ***************************/

MODULE get_virtual_host (THREAD *thread)
{
    char
        *vhost_name;                    /*  Name of virtual host             */
    SYMBOL
        *vhost_sym = NULL;              /*  Virtual host entry in table      */
    VHOST
        *vhost;                         /*  Virtual host resource block      */
    Bool
        uses_vhost = TRUE;              /*  Did we use a virtual host?       */

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    vhost_name = socket_localaddr  (tcb-> handle);
    vhost_sym  = sym_lookup_symbol (tcb-> vhosts, vhost_name);
    trace ("SSL looking for VH using IP address: %s", vhost_name);

    /*  If that failed, use VHOST_ANY host name                              */
    if (!vhost_sym)
      {
        vhost_sym = sym_lookup_symbol (tcb-> vhosts, VHOST_ANY);
        trace ("- using default virtual host values");
        uses_vhost = FALSE;
      }
    ASSERT (vhost_sym);
    vhost = vhost_sym-> data;

    /*  Use virtual host resources                                           */
    tcb-> vhost       = vhost;
    tcb-> config      = vhost-> config;
    tcb-> ssl_context = vhost-> ssl_context;
}


/************************   SHUTDOWN THE APPLICATION   ***********************/

MODULE shutdown_the_application (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    smt_shutdown ();                    /*  Halt the application             */
}


/***********************   KILL ALL ACTIVE CONNECTION   **********************/

MODULE kill_all_active_connection (THREAD *thread)
{
    QUEUE
        *queue;                         /*  Task control block               */

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    /*  We send a CANCEL event to all threads; the master thread ignores it  */
    for (queue = this_agent-> queues.next;
        (void *) queue != &(this_agent-> queues.next);
         queue = queue-> next)
        SEND (&queue-> qid, "_CANCEL", "");
}


/*************************   TERMINATE THE THREAD   **************************/

MODULE terminate_the_thread (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    if (tcb-> handle)
      {
        if (tcb-> thread_type == open_event
        &&  tcb-> port)
            sendfmt (&operq, "INFO",
                     "smtssl: closing SSL connections on port %s",
                     tcb-> port);
        close_socket (tcb-> handle);
        tcb-> handle = 0;
      }
    if (tcb-> ssl)
      {
        SSL_free (tcb-> ssl);
        tcb-> ssl = NULL;
      }
    mem_strfree (&tcb-> port);
    mem_strfree (&tcb-> data);
    mem_strfree (&tcb-> file_name);
    mem_strfree (&tcb-> f_config);

    if (tcb-> stream >= 0)
      {
        lazy_close (tcb-> stream);
        if (io_completed)
            tcb-> stream = -1;
      }

    if (tcb->stream < 0)
      {
        the_next_event = terminate_event;
      }
}







/*###########################################################################*/
/*#                        I N T E R N A L  F U N C T I O N                 #*/
/*###########################################################################*/

/*  -------------------------------------------------------------------------
 *  tmp_rsa_cb
 *
 *  A call back function for temporary RSA key generation
 */

#if defined (USE_SSLEAY)
static RSA*
tmp_rsa_cb (SSL *ssl, int is_export)
{
    static RSA *rsa_tmp=NULL;

    if (rsa_tmp == NULL)
        rsa_tmp = RSA_generate_key (512, RSA_F4, NULL, NULL);
    return (rsa_tmp);
}
#else
static RSA *
tmp_rsa_cb (SSL *ssl, int is_export, int keylength)
{
    static RSA *rsa_tmp=NULL;

    if (rsa_tmp == NULL)
        rsa_tmp = RSA_generate_key (keylength, RSA_F4, NULL, NULL);
    return (rsa_tmp);
}
#endif

/*  -------------------------------------------------------------------------
 *  set_vhost_name
 *
 *  If the configuration does not define a server:hostname, inserts the
 *  specified hostname symbol.
 */

static void
set_vhost_name (SYMTAB *table, const char *name)
{
    /*  We do not do this if the name starts with a letter                   */
    if (isalpha (*name)
    &&  sym_lookup_symbol (table, "server:hostname") == NULL)
        sym_assume_symbol (table, "server:hostname", name);
}


/*  -------------------------------------------------------------------------
 *  free_vhost
 *
 *  Free all memory allocated for Virtual Host
 */

static void
free_vhost (VHOST *host)
{
    if (host-> config)
        sym_delete_table (host-> config);

    mem_strfree (&host-> name);

    if (host-> ssl_context != NULL)
        SSL_CTX_free (host-> ssl_context);

    mem_free (host);
}



/*  -------------------------------------------------------------------------
 *  get_asn1_utctime
 *
 *  Format a string from a ASN1 (certificate) time format
 */

static char *
get_asn1_utctime (ASN1_UTCTIME *tm)
{
    char
        *data;
    int
        gmt = 0;
    static char
        *mon [12]={
            "Jan","Feb","Mar","Apr","May","Jun",
            "Jul","Aug","Sep","Oct","Nov","Dec"};
    static char
       buffer [LINE_MAX];
    int
        index;
    int
        year = 0,
        month = 0,
        day = 0,
        hour = 0,
        minute = 0,
        second = 0;

    index = tm->length;
    data = (char *)tm->data;

    if (index < 10)
      {
        sprintf (buffer, "ASN1: Bad time value");
        return  (buffer);
      }
    if (data [index - 1] == 'Z')
        gmt = 1;
    for (index = 0; index < 10; index++)
        if (data [index] > '9'
        ||  data[index] < '0')
          {
            sprintf (buffer, "ASN1: Bad time value");
            return  (buffer);
          }
    year = (data [0] - '0') * 10 + (data [1] - '0');
    if (year < 50)
        year += 100;
    month = (data [2] - '0') * 10 + (data [3] - '0');
    if (month > 12
    ||  month < 1)
      {
        sprintf (buffer, "ASN1: Bad time value");
        return  (buffer);
      }
    day    = (data [4] - '0') * 10 + (data [5] - '0');
    hour   = (data [6] - '0') * 10 + (data [7] - '0');
    minute = (data [8] - '0') * 10 + (data [9] - '0');
    if (data[10] >= '0'
    &&  data[10] <= '9'
    &&  data[11] >= '0'
    &&  data[11] <= '9')
        second = (data [10] - '0') * 10 + (data [11] - '0');

    sprintf (buffer, "%s %2d %02d:%02d:%02d %d%s",
                     mon [month - 1],
                     day, hour, minute,
                     second,
                     year + 1900,
                     gmt?" GMT":"");
    return (buffer);
}


/*  -------------------------------------------------------------------------
 *  verify_callback
 *
 *  Callback function to verify certificate
 */

int
verify_callback (int ok, X509_STORE_CTX *ctx)
{
    char
        buf[256];
    X509
        *err_cert;
    int
        err,
        depth;

    err_cert = X509_STORE_CTX_get_current_cert (ctx);
    err      = X509_STORE_CTX_get_error        (ctx);
    depth    = X509_STORE_CTX_get_error_depth  (ctx);

    X509_NAME_oneline (X509_get_subject_name (err_cert), buf, 256);
    trace ("depth = %d %s", depth, buf);
    if (!ok)
      {
        trace ("verify error:num = %d:%s",
               err,
               X509_verify_cert_error_string (err));
        if (verify_depth >= depth)
          {
            ok = 1;
            verify_error = X509_V_OK;
          }
        else
          {
            ok = 0;
            verify_error = X509_V_ERR_CERT_CHAIN_TOO_LONG;
          }
      }
    switch (ctx->error)
      {
        case X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT:
            X509_NAME_oneline (X509_get_issuer_name (ctx->current_cert),
                               buf, 256);
            trace ("issuer= %s",buf);
            break;
        case X509_V_ERR_CERT_NOT_YET_VALID:
        case X509_V_ERR_ERROR_IN_CERT_NOT_BEFORE_FIELD:
             trace ("notBefore=%s",
                    get_asn1_utctime (X509_get_notBefore (ctx->current_cert)));
             break;
        case X509_V_ERR_CERT_HAS_EXPIRED:
        case X509_V_ERR_ERROR_IN_CERT_NOT_AFTER_FIELD:
             trace ("notAfter=%s",
                    get_asn1_utctime (X509_get_notAfter (ctx->current_cert)));
             break;
      }
    trace ("verify return:%d\n", ok);

    return(ok);
}

/*  -------------------------------------------------------------------------
 *  ssl_info_callback
 *
 *  Save ssl information with trace
 */

void
ssl_info_callback (const SSL *s, int where, int ret)
{
    char
        *state_name;
    int
        state_mask;

    state_mask = where & ~SSL_ST_MASK;

    if (state_mask & SSL_ST_CONNECT)
        state_name = "SSL_connect";
    else
    if (state_mask & SSL_ST_ACCEPT)
        state_name = "SSL_accept";
    else
        state_name = "undefined";

    if (where & SSL_CB_LOOP)
        trace ("%s:%s", state_name, SSL_state_string_long (s));
    else
    if (where & SSL_CB_ALERT)
      {
        state_name = (where & SSL_CB_READ)? "read": "write";
        trace ("SSL3 alert %s:%s:%s", state_name,
                                      SSL_alert_type_string_long (ret),
                                      SSL_alert_desc_string_long (ret));
      }
    else
    if (where & SSL_CB_EXIT)
      {
        if (ret <= 0)
          {
            trace ("%s:%s in %s", state_name,
                                 (ret == 0)? "failed": "error",
                                  SSL_state_string_long (s));
          }
      }
}


/*  -------------------------------------------------------------------------
 *  sendfmt_ssl_error
 *
 *  Send ssl error to operator console
 */

static void
sendfmt_ssl_error (void)
{
    static char
        buffer [256];
    unsigned long
        error_code;
    const char
        *file,
        *data;
    int
        line,
        flags;

    error_code = ERR_get_error_line_data (&file, &line, &data, &flags);
    if (error_code != 0)
        sendfmt (&operq, "ERROR", "smtssl: %s: %s",
                          ERR_error_string (error_code, buffer),
                          (flags & ERR_TXT_STRING)? data: "");
}


/*  -------------------------------------------------------------------------
 *  show_addresses
 *
 *  Show IP address accepted
 */

static void
show_addresses (void)
{
    qbyte
        *address;                       /*  Address table, ends in zero      */
    int
        index;                          /*  Index into the table             */

    if (*SSLCONFIG ("server:ipaddress") == '*')
      {
        address = get_hostaddrs ();
        if (address)
            for (index = 0; address [index]; index++)
                sendfmt (&operq, "INFO",
                                 "smtssl: accepting connections on %s",
                                  sock_ntoa (address [index]));
        sendfmt (&operq, "INFO", "smtssl: accepting connections on 127.0.0.1");
        mem_free (address);
      }
    else
        sendfmt (&operq, "INFO", "smtssl: accepting connections on %s",
                                  SSLCONFIG ("server:ipaddress"));
}

/*  -------------------------------------------------------------------------
 *  set_timer_refresh
 *
 *  Tell timer to send us an alarm every so often, so we can check for
 *  modified configuration files and/or log files that need to be
 *  cycled.  Config refresh rate is in seconds; we need centiseconds.
 */

static void
set_timer_refresh (THREAD *thread)
{
    qbyte
        refresh;                        /*  Server refresh rate              */

    refresh = atol (SSLCONFIG ("server:refresh")) * 100;
    if (refresh == 0)
        return;                         /*  Then do nothing                  */

    if (refresh < 1000)
        refresh = 1000;                 /*  10 seconds minimum rate          */

    event_send (
        &timeq,                         /*  Send to specified queue          */
        &thread-> queue-> qid,          /*  Queue for reply                  */
        "FLUSH",                        /*  Name of event to send            */
        NULL, 0,                        /*  No event body                    */
        NULL, NULL, NULL,               /*  No response events               */
        0);                             /*  No timeout                       */

    msg_size = exdr_writed (&msg, SMT_TIME_CLOCK,
                           (qbyte) 0, refresh, (word) 0, 0, NULL);
    event_send (
        &timeq,                         /*  Send to specified queue          */
        &thread-> queue-> qid,          /*  Queue for reply                  */
        "CLOCK",                        /*  Name of event to send            */
        msg_body, msg_size,             /*  Event body and size              */
        NULL, NULL, NULL,               /*  No response events               */
        0);                             /*  No timeout                       */
}

