#! perl
print<<".";
Line 1111
Line 2222
Line 3333
.
