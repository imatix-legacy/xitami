#! perl
print<<".";
Content-Type: text/html

<HTML>Line 1111
Line 2222
Line 3333
.
