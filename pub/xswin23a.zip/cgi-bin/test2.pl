#! perl
open (INPUT, "image.gif");
while (<INPUT>) {
    print $_;
}
