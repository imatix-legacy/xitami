/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflmail.c
    Title:      SMTP mailer functions
    Package:    standard function library (sfl)

    Written:    06/18/97 Scott Beasley <jscottb@infoave.com>
    Revised:    98-03-17

    Synopsis:   Functions to format and send SMTP messages.  Messages
                can contain attachments, and be sent with "cc"'s "bcc"'s as
                well as the normal "to" receivers.
            
    Copyright:  Copyright (C) 1991-97 Imatix
    License:    this is free software; you can redistribute it and/or modify
                it under the terms of the sfl license agreement as provided
                in the file license.txt.  this software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflstr.h"
#include "sflsock.h"
#include "sflmail.h"

static char strlast_smtp_message[513];

/*  ---------------------------------------------------------------------[<]-
    Function: smtp_send_mail

    Synopsis:
    Format and send a SMTP message.  This function gives you the
    options of sneding to multi receivers, CC's, Bcc's and also send 
    UUencoded attachments. Receivers and files are ";" or "," 
    terminated.

    NOTE: The sock_init function should be called before use of this 
          function.
    ---------------------------------------------------------------------[>]-*/

int smtp_send_mail (
   char *strSmtpServer,  
   char *strMessageBody,
   char *strSubject,
   char *strSenderUserId,
   char *strDestUserIds,
   char *strCcUserIds,
   char *strBccUserIds,
   char *strRetPathUserId,
   char *strRrcpUserId,
   char *strMsgComment,
   char *strMailerName,
   char *strBinFiles,
   char *strTxtFiles)
{
   FILE *fpin;
   int iCnt;
   sock_t iSocket;
   char strOut[514], strFile[256], strRetBuff[513];
   char strUUEFile[256], *strRcptUserIds;
   int iOld_ip_nonblock = ip_nonblock;

   /* Make sure we do not block. */
   ip_nonblock = FALSE;

   /* Open up the SMTP port (25 most of the time). */
   iSocket = connect_TCP (strSmtpServer, "smtp");

   if (getreply (iSocket) > 400 || iSocket < 1)
     {
       return -1;
     }

   /* Format a SMTP meassage header.  */
   /* Just say hello to the mail server. */
   xstrcpy (strOut, "HELO ", strSmtpServer, "\n", NULL);
   smtp_send_data (iSocket, strOut);
   if (getreply (iSocket) > 400)
       return -2;

   /* Tell the mail server who the message is from. */
   xstrcpy (strOut, "MAIL FROM:<", strSenderUserId, ">\n", NULL);
   smtp_send_data (iSocket, strOut);
   if (getreply (iSocket) > 400)
       return -3;

   strRcptUserIds = (char *) malloc (strlen (strDestUserIds) + 
                                     strlen (strCcUserIds) +
                                     strlen (strBccUserIds) + 1);
   sprintf (strRcptUserIds, "%s;%s;%s", strDestUserIds, 
             strCcUserIds, strBccUserIds);
   /* The following tells the mail server who to send it to. */   
   iCnt = 0;
   while (1)
     {
       getstrfld (strRcptUserIds, iCnt++, 0, ",;", strRetBuff);

       if (*strRetBuff)
         {
           xstrcpy (strOut, "RCPT TO:<", strRetBuff, ">\r\n", NULL);
           smtp_send_data (iSocket, strOut);
           if (getreply (iSocket) > 400)
               return -4;
         }

       else
           break;
     }

   free (strRcptUserIds);

   /* Now give it the Subject and the message to send. */
   smtp_send_data (iSocket, "DATA\r\n");
   if (getreply (iSocket) > 400)
       return -5;

   /* The following shows all who it was sent to. */   
   replacechrswith (strDestUserIds, ";", ',');
   xstrcpy (strOut, "TO: ", strDestUserIds, "\r\n", NULL);

   /* Set up the Reply-To path. */   
   if (!strRetPathUserId || !*strRetPathUserId)
     {
       strRetPathUserId = strSenderUserId;
     }
   xstrcat (strOut, "Reply-To:<", strRetPathUserId, ">\r\n", NULL);
   smtp_send_data (iSocket, strOut);

   *strOut = '\0';

   /* Post any CC's. */   
   if (strCcUserIds && *strCcUserIds)
     {
       replacechrswith (strCcUserIds, ";", ',');
       xstrcat (strOut, "Cc:", strCcUserIds, "\r\n", NULL );
     }

   /* Post any BCC's. */   
   if (strBccUserIds && *strBccUserIds)
     {
       replacechrswith (strBccUserIds, ";", ',');
       xstrcat (strOut, "Bcc:", strBccUserIds, "\r\n", NULL);
     }
   /* Post any Return-Receipt-To. */   
   if (strRrcpUserId && *strRrcpUserId)
     {
       xstrcat (strOut, "Return-Receipt-To:", strRrcpUserId,
                 ">\r\n", NULL);
     }

   if (strMailerName && *strMailerName)
     {
       xstrcat (strOut, "X-Mailer: ", strMailerName, "\r\n", NULL);
     }

   else 
     {
       strcat (strOut, "X-Mailer: sflmail function\r\n");
     }

   /* Set the mime version. */
   strcat (strOut, "MIME-Version: 1.0\r\n");
   strcat (strOut, 
   "Content-Type: Multipart/Mixed; boundary=Message-Boundary-21132\r\n");

   smtp_send_data (iSocket, strOut);

   /* Write out any message comment included. */
   xstrcpy (strOut, "Comments: ", strMsgComment, "\r\n", NULL);

   /* Send the subject and message body. */   
   xstrcat (strOut, "Subject:", strSubject, "\n\r\n", NULL);

   /* Keep rfc822 in mind with all the sections. */
   if (strMessageBody && *strMessageBody)
     {
       strcat (strOut, "\r\n--Message-Boundary-21132\r\n");
       strcat (strOut, "Content-Type: text/plain; charset=US-ASCII\r\n");
       strcat (strOut, "Content-Transfer-Encoding: 7BIT\r\n");
       strcat (strOut, "Content-description: Body of message\r\n");
       xstrcat (strOut, "\r\n", strMessageBody, "\r\n", NULL);
     }
   smtp_send_data (iSocket, strOut);

   /* Include any Text type files and Attach them to the message. */   
   if (strTxtFiles && *strTxtFiles)
     {
       iCnt = 0; 
       while (1)
         {
           getstrfld (strTxtFiles, iCnt++, 0, ",;", strFile);
           trim (strFile);
           if (*strFile)
             {
               fpin = fopen (strFile, "rb");
               if (!fpin)
                 {
                   return -6;
                 }

               strcpy (strOut, "\r\n--Message-Boundary-21132\r\n");
               strcat (strOut, 
               "Content-Type: text/plain; charset=US-ASCII\r\n");
               strcat (strOut, "Content-Transfer-Encoding: 7BIT\r\n");
               xstrcat (strOut, "Content-Disposition: attachment; filename=",
               getfilename (strFile), "\r\n\n", NULL);
               smtp_send_data (iSocket, strOut);
               while (!feof (fpin))
                 {
                   memset (strRetBuff, 0, 513);
                   fread (strRetBuff, sizeof (char), 512, fpin);
                   smtp_send_data (iSocket, strRetBuff);
                 }
   
               fclose (fpin);
             }
           else
               break;
         }
     }

   /* UUencode any bin files and Attach them to the message. */   
   if (strBinFiles && *strBinFiles)
     {
       iCnt = 0; 
       while (1)
         {
           getstrfld (strBinFiles, iCnt++, 0, ",;", strFile);
           trim (strFile);
           if (*strFile)
             {
               strcpy (strUUEFile, strFile);
               if (strchr (strUUEFile, '.'))
                   *((strchr (strUUEFile, '.')))= (char)NULL;
               strcat (strUUEFile, ".uue");
               uuencode (strFile, strUUEFile);
               fpin = fopen (strUUEFile, "rb");
               if (!fpin)
                 {
                   return -6;
                 }

               strcpy (strOut, "\r\n--Message-Boundary-21132\r\n");
               xstrcat (strOut, 
               "Content-Type: application/octet-stream; name=",
               getfilename (strFile), "\r\n", NULL);
               strcat (strOut, "Content-Transfer-Encoding: x-uuencode\r\n");
               xstrcat (strOut, "Content-Disposition: attachment; filename=",
               strFile, "\r\n\n", NULL);
               smtp_send_data (iSocket, strOut);
               while (!feof (fpin))
                 {
                   memset (strRetBuff, 0, 513);
                   fread (strRetBuff, sizeof (char), 512, fpin);
                   smtp_send_data (iSocket, strRetBuff);
                 }
   
               fclose (fpin);
               unlink (strUUEFile);
             }
           else
               break;
         }
     }

   /* This ends the message. */
   smtp_send_data (iSocket, ".\r\n");
   if (getreply (iSocket) > 400)
        return -7;

   /* Now log off the SMTP port. */  
   smtp_send_data (iSocket, "QUIT\n");
   if (getreply (iSocket) > 400)
        return -8;

   /* 
      Clean-up.
   */
   /* Close the port up. */
   close_socket (iSocket);

   /* If a clean send, then reset and leave. */
   ip_nonblock = iOld_ip_nonblock;

   return 0;
}

/*  ---------------------------------------------------------------------[<]-
    Function: uuencode

    Synopsis:
    Uuendcode a file, with the output going to a new file.  This
    function is used by smtp_send_mail.
    ---------------------------------------------------------------------[>]-*/

static int uuencode (
   char *strIn, 
   char *strOut)
{
   char strLine[46];
   int iCnt, iLineLen;
   FILE *fpin, *fpout;

   if (!(fpin = fopen (strIn, "rb")))
     {
       return 1;
     }

   if (!(fpout = fopen (strOut, "wb")))
     {
       return 1;
     }
   
   fprintf (fpout, "begin 666 %s\n", getfilename (strIn));

   while (1)
     {
       iLineLen = fread (strLine, sizeof (char), 45, fpin);
       if (iLineLen <= 0)
           break;

       fputc (ENC (iLineLen), fpout);

       for (iCnt = 0; iCnt < iLineLen; iCnt += 3)
         {
           putgroup (&strLine[iCnt], fpout);
         }

       fputc ('\n', fpout);
     }

   fprintf (fpout, "end\n");

   fclose (fpin);
   fclose (fpout);
   return 0;
}

/*  ---------------------------------------------------------------------[<]-
    Function: putgroup

    Synopsis:
    Write out 3 char group to uuendcoded file making it printable  This
    function is used by uuencode.
    ---------------------------------------------------------------------[>]-*/

static void putgroup (
   char *strgroup, 
   FILE *fp)
{
   int ichr1, ichr2, ichr3, ichr4;

   ichr1 = *strgroup >> 2;
   ichr2 = (*strgroup << 4)& 0x030 | (strgroup[1] >> 4)& 0x00f;
   ichr3 = (strgroup[1] << 2)& 0x03c | (strgroup[2] >> 6)& 0x003;
   ichr4 = strgroup[2] & 0x03f;

   fputc (ENC (ichr1), fp);
   fputc (ENC (ichr2), fp);
   fputc (ENC (ichr3), fp);
   fputc (ENC (ichr4), fp);
}

/*  ---------------------------------------------------------------------[<]-
    Function: getreply

    Synopsis:
    Get a reply from the SMTP server and see thats it's not an error. This
    function is used by smtp_send_mail.
    ---------------------------------------------------------------------[>]-*/

static int getreply (
   int iSocket)
{

   char strRetBuff[513];

   *strRetBuff = 0;
   read_TCP ((sock_t)iSocket, strRetBuff, 512);

   /* See if we have not gotten a responce back from the mail server. */
   if (!*strRetBuff){
      return 777;
   }

   /* Save off server reply. */
   strcpy (strlast_smtp_message, strRetBuff);

   trim (strRetBuff);
   strRetBuff[3] = (char)0;
   return atoi (strRetBuff);
}

/*  ---------------------------------------------------------------------[<]-
    Function: getfilename

    Synopsis:
    Get's the name from the full path of a file. This function is used 
    by smtp_send_mail.
    ---------------------------------------------------------------------[>]-*/

static char *getfilename (
   char *strFullPath)
{
   int iLen;
   char *strTmp;

   iLen = strlen (strFullPath);
   strTmp = (strFullPath + iLen);
   while (1)
     {
       if (*strTmp == '\\' || *strTmp == '/' || !iLen)
           break;
       strTmp--;
       iLen--;
     }

   if (*strTmp == '\\' || *strTmp == '/')
       strTmp++;

   return strTmp;
}

/*  ---------------------------------------------------------------------[<]-
    Function: get_last_smtp_message

    Synopsis:
    Get's the last message the smtp server submited. 
    ---------------------------------------------------------------------[>]-*/

char *get_last_smtp_message (void)
{
   return strlast_smtp_message;
}

