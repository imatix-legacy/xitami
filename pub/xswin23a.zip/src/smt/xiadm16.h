/*---------------------------------------------------------------------------
 *  xiadm16.h - HTML form definition
 *
 *  Generated 1998/04/25,  9:11:48 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM16__
#define __FORM_XIADM16__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM16_MESSAGE_TO_USER             0
#define XIADM16_L_ENABLED                   1
#define XIADM16_ENABLED                     2
#define XIADM16_L_ROOTDIR                   3
#define XIADM16_ROOTDIR                     4
#define XIADM16_L_PORT                      5
#define XIADM16_PORT                        6
#define XIADM16_L_TIMEOUT                   7
#define XIADM16_TIMEOUT                     8
#define XIADM16_L_LIMIT                     9
#define XIADM16_LIMIT                       10
#define XIADM16_L_USER_FILE                 11
#define XIADM16_USER_FILE                   12
#define XIADM16_L_DIRECTORY_FILE            13
#define XIADM16_DIRECTORY_FILE              14
#define XIADM16_L_WELCOME                   15
#define XIADM16_WELCOME                     16
#define XIADM16_L_EMAIL_CHECK               17
#define XIADM16_EMAIL_CHECK                 18
#define XIADM16_L_HTTP_ALIASES              19
#define XIADM16_HTTP_ALIASES                20
#define XIADM16_L_WEBMASK                   21
#define XIADM16_WEBMASK                     22
#define XIADM16_L_DATA_PORT                 23
#define XIADM16_DATA_PORT                   24
#define XIADM16_L_IPADDRESS                 25
#define XIADM16_IPADDRESS                   26
#define XIADM16_L_ALOG_ENABLED              27
#define XIADM16_ALOG_ENABLED                28
#define XIADM16_L_ALOG_FILENAME             29
#define XIADM16_ALOG_FILENAME               30
#define XIADM16_L_ALOG_CYCLE                31
#define XIADM16_ALOG_CYCLE                  32
#define XIADM16_L_ELOG_ENABLED              33
#define XIADM16_ELOG_ENABLED                34
#define XIADM16_L_ELOG_FILENAME             35
#define XIADM16_ELOG_FILENAME               36
#define XIADM16_L_ELOG_CYCLE                37
#define XIADM16_ELOG_CYCLE                  38
#define XIADM16_L_NONAME14                  39

/*  This table contains each block in the form                               */

static byte xiadm16_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - FTP configuration</TITLE>             */
    0, 58, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'F', 'T', 'P', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 'u', 'r', 'a', 't', 'i', 'o', 'n', '<', '/', 'T',
    'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 158, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  #(config) - FTP configuration                                        */
    0, 31, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'F', 'T', 'P', 32, 'c', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't',
    'i', 'o', 'n', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 160,
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 52, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', 10,
    /*  <TD ALIGN=LEFT>                                                      */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>', 10,
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, 'k',
    /*  !--ACTION server  LABEL="Ser ... ENT=server_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 2, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  !--ACTION aliases  LABEL="Al ... NT=aliases_event TYPE=PLAIN         */
    0, 27, 20, 1, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 3, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  !--ACTION vhosts  LABEL="Vho ... ENT=vhosts_event TYPE=PLAIN         */
    0, 25, 20, 1, (byte) ((word) vhosts_event / 256), (byte) ((word)
    vhosts_event & 255), 0, 4, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's', 't',
    's', 0, 'V', 'h', 'o', 's', 't', 's', 0,
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=PLAIN                */
    0, 19, 20, 1, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 5, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... T=security_event TYPE=PLAIN         */
    0, 29, 20, 1, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 6, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  !--ACTION logging  LABEL="Lo ... NT=logging_event TYPE=PLAIN         */
    0, 27, 20, 1, (byte) ((word) logging_event / 256), (byte) ((word)
    logging_event & 255), 0, 7, 0, 0, 0, 0, 0, 'l', 'o', 'g', 'g', 'i',
    'n', 'g', 0, 'L', 'o', 'g', 'g', 'i', 'n', 'g', 0,
    /*  <EM>FTP</EM>                                                         */
    0, 14, 0, '<', 'E', 'M', '>', 'F', 'T', 'P', '<', '/', 'E', 'M',
    '>', 10,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=PLAIN            */
    0, 21, 20, 1, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 8, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0, 'M',
    'I', 'M', 'E', 0,
    /*  </TABLE><HR>                                                         */
    0, 14, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 4, 1, 0, 2, 0,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f212 NAME=L ...  VALUE="Enable FTP server?"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '2', '1', '2', 0, 'E', 'n',
    'a', 'b', 'l', 'e', 32, 'F', 'T', 'P', 32, 's', 'e', 'r', 'v', 'e',
    'r', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD BOOLEAN f213 NAME=enabled TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '2', '1', '3', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f214 NAME=L ... VALUE="FTP root directory:"         */
    0, 33, 10, 6, 1, 0, 0, 19, 0, 19, 'f', '2', '1', '4', 0, 'F', 'T',
    'P', 32, 'r', 'o', 'o', 't', 32, 'd', 'i', 'r', 'e', 'c', 't', 'o',
    'r', 'y', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD TEXTUAL f215 NAME=r ... 40 MAX=100 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, 'd', 'f', '2', '1', '5', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f216 NAME=L ... "Port for FTP connections:"         */
    0, 39, 10, 6, 1, 0, 0, 25, 0, 25, 'f', '2', '1', '6', 0, 'P', 'o',
    'r', 't', 32, 'f', 'o', 'r', 32, 'F', 'T', 'P', 32, 'c', 'o', 'n',
    'n', 'e', 'c', 't', 'i', 'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD NUMERIC f217 NAME=p ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'f', '2', '1', '7',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f218 NAME=L ... ="Timeout for connections:"         */
    0, 38, 10, 6, 1, 0, 0, 24, 0, 24, 'f', '2', '1', '8', 0, 'T', 'i',
    'm', 'e', 'o', 'u', 't', 32, 'f', 'o', 'r', 32, 'c', 'o', 'n', 'n',
    'e', 'c', 't', 'i', 'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD NUMERIC f219 NAME=t ... MMA=0 SIZE=6 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 6, 0, 6, 0, 0, 0, 0, 0, 0, 'f', '2', '1', '9',
    0, 0,
    /*  seconds                                                              */
    0, 9, 0, 's', 'e', 'c', 'o', 'n', 'd', 's', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f220 NAME=L ... ALUE="Maximum connections:"         */
    0, 34, 10, 6, 1, 0, 0, 20, 0, 20, 'f', '2', '2', '0', 0, 'M', 'a',
    'x', 'i', 'm', 'u', 'm', 32, 'c', 'o', 'n', 'n', 'e', 'c', 't', 'i',
    'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD NUMERIC f221 NAME=l ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 1, 0, 'f', '2', '2', '1',
    0, 0,
    /*  if any                                                               */
    0, 8, 0, 'i', 'f', 32, 'a', 'n', 'y', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f222 NAME=L ... ="User configuration file:"         */
    0, 38, 10, 6, 1, 0, 0, 24, 0, 24, 'f', '2', '2', '2', 0, 'U', 's',
    'e', 'r', 32, 'c', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't', 'i',
    'o', 'n', 32, 'f', 'i', 'l', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD TEXTUAL f223 NAME=u ... E=40 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, '(', 'f', '2', '2', '3', 0, 0,
    /*  !--ACTION define_users  LABE ... ine_users_event TYPE=BUTTON         */
    0, 34, 20, 0, (byte) ((word) define_users_event / 256), (byte)
    ((word) define_users_event & 255), 0, 9, 0, 0, 0, 0, 0, 'd', 'e',
    'f', 'i', 'n', 'e', '_', 'u', 's', 'e', 'r', 's', 0, 'D', 'e', 'f',
    'i', 'n', 'e', '.', '.', '.', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f224 NAME=L ... UE="Directory access file:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '2', '2', '4', 0, 'D', 'i',
    'r', 'e', 'c', 't', 'o', 'r', 'y', 32, 'a', 'c', 'c', 'e', 's', 's',
    32, 'f', 'i', 'l', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD TEXTUAL f225 NAME=d ... E=40 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, '(', 'f', '2', '2', '5', 0, 0,
    /*  !--ACTION define_dirs  LABEL ... fine_dirs_event TYPE=BUTTON         */
    0, 33, 20, 0, (byte) ((word) define_dirs_event / 256), (byte)
    ((word) define_dirs_event & 255), 0, 10, 0, 0, 0, 0, 0, 'd', 'e',
    'f', 'i', 'n', 'e', '_', 'd', 'i', 'r', 's', 0, 'D', 'e', 'f', 'i',
    'n', 'e', '.', '.', '.', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f226 NAME=L_welcome VALUE="Welcome message:"        */
    0, 30, 10, 6, 1, 0, 0, 16, 0, 16, 'f', '2', '2', '6', 0, 'W', 'e',
    'l', 'c', 'o', 'm', 'e', 32, 'm', 'e', 's', 's', 'a', 'g', 'e', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD TEXTBOX f227 NAME=w ... 60 MAX=240 UPPER=0 VALUE=""         */
    0, 14, 13, 0, 1, 3, '<', 0, 0, 240, 'f', '2', '2', '7', 0, 0,
    /*  text or @filename                                                    */
    0, 19, 0, 't', 'e', 'x', 't', 32, 'o', 'r', 32, '@', 'f', 'i', 'l',
    'e', 'n', 'a', 'm', 'e', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f228 NAME=L ... nonymous e-mail addresses?"         */
    0, 47, 10, 6, 1, 0, 0, '!', 0, '!', 'f', '2', '2', '8', 0, 'C', 'h',
    'e', 'c', 'k', 32, 'a', 'n', 'o', 'n', 'y', 'm', 'o', 'u', 's', 32,
    'e', 45, 'm', 'a', 'i', 'l', 32, 'a', 'd', 'd', 'r', 'e', 's', 's',
    'e', 's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD BOOLEAN f229 NAME=e ... k TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '2', '2', '9', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f230 NAME=L ... VALUE="Share HTTP aliases?"         */
    0, 33, 10, 6, 1, 0, 0, 19, 0, 19, 'f', '2', '3', '0', 0, 'S', 'h',
    'a', 'r', 'e', 32, 'H', 'T', 'T', 'P', 32, 'a', 'l', 'i', 'a', 's',
    'e', 's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD BOOLEAN f231 NAME=h ... s TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '2', '3', '1', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  !--ACTION ftp_aliases  LABEL ... e_aliases_event TYPE=BUTTON         */
    0, 45, 20, 0, (byte) ((word) define_aliases_event / 256), (byte)
    ((word) define_aliases_event & 255), 0, 11, 0, 0, 0, 0, 0, 'f', 't',
    'p', '_', 'a', 'l', 'i', 'a', 's', 'e', 's', 0, 'D', 'e', 'f', 'i',
    'n', 'e', 32, 'F', 'T', 'P', 32, 'a', 'l', 'i', 'a', 's', 'e', 's',
    '.', '.', '.', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f232 NAME=L_webmask VALUE="IP address mask:"        */
    0, 30, 10, 6, 1, 0, 0, 16, 0, 16, 'f', '2', '3', '2', 0, 'I', 'P',
    32, 'a', 'd', 'd', 'r', 'e', 's', 's', 32, 'm', 'a', 's', 'k', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD TEXTUAL f233 NAME=w ... =40 MAX=80 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, '(', 0, 'P', 'f', '2', '3', '3', 0, 0,
    /*  - eg. 111.222.333.*                                                  */
    0, 21, 0, 45, 32, 'e', 'g', '.', 32, '1', '1', '1', '.', '2', '2',
    '2', '.', '3', '3', '3', '.', '*', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f234 NAME=L ... LUE="Data connection port:"         */
    0, 35, 10, 6, 1, 0, 0, 21, 0, 21, 'f', '2', '3', '4', 0, 'D', 'a',
    't', 'a', 32, 'c', 'o', 'n', 'n', 'e', 'c', 't', 'i', 'o', 'n', 32,
    'p', 'o', 'r', 't', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD NUMERIC f235 NAME=d ... MMA=0 SIZE=4 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'f', '2', '3', '5',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f236 NAME=L ... VALUE="Passive IP address:"         */
    0, 33, 10, 6, 1, 0, 0, 19, 0, 19, 'f', '2', '3', '6', 0, 'P', 'a',
    's', 's', 'i', 'v', 'e', 32, 'I', 'P', 32, 'a', 'd', 'd', 'r', 'e',
    's', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD SELECT f237 NAME=ip ... pe=dynamic 0="No selection"         */
    0, 25, 15, 0, 1, 1, 0, 'f', '2', '3', '7', 0, '0', 0, 'N', 'o', 32,
    's', 'e', 'l', 'e', 'c', 't', 'i', 'o', 'n', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 19, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>', 10,
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f238 NAME=L ... d VALUE="Log all accesses?"         */
    0, 31, 10, 6, 1, 0, 0, 17, 0, 17, 'f', '2', '3', '8', 0, 'L', 'o',
    'g', 32, 'a', 'l', 'l', 32, 'a', 'c', 'c', 'e', 's', 's', 'e', 's',
    '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD BOOLEAN f239 NAME=a ... d TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '2', '3', '9', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  !--FIELD TEXTUAL f240 NAME=L ... ALUE="&nbsp;&nbsp;to file:"         */
    0, 34, 10, 6, 1, 0, 0, 20, 0, 20, 'f', '2', '4', '0', 0, '&', 'n',
    'b', 's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', 't', 'o', 32, 'f',
    'i', 'l', 'e', ':', 0,
    /*  !--FIELD TEXTUAL f241 NAME=a ... =20 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 20, 0, '(', 'f', '2', '4', '1', 0, 0,
    /*  !--FIELD TEXTUAL f242 NAME=L ...  VALUE="&nbsp;&nbsp;cycle:"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '2', '4', '2', 0, '&', 'n',
    'b', 's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', 'c', 'y', 'c',
    'l', 'e', ':', 0,
    /*  !--FIELD SELECT f243 NAME=al ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 15, 0, 1, 1, 5, 'f', '2', '4', '3', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f244 NAME=L ... led VALUE="Log all errors?"         */
    0, 29, 10, 6, 1, 0, 0, 15, 0, 15, 'f', '2', '4', '4', 0, 'L', 'o',
    'g', 32, 'a', 'l', 'l', 32, 'e', 'r', 'r', 'o', 'r', 's', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--FIELD BOOLEAN f245 NAME=e ... d TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '2', '4', '5', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  !--FIELD TEXTUAL f246 NAME=L ... ALUE="&nbsp;&nbsp;to file:"         */
    0, 34, 10, 6, 1, 0, 0, 20, 0, 20, 'f', '2', '4', '6', 0, '&', 'n',
    'b', 's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', 't', 'o', 32, 'f',
    'i', 'l', 'e', ':', 0,
    /*  !--FIELD TEXTUAL f247 NAME=e ... =20 MAX=40 UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 20, 0, '(', 'f', '2', '4', '7', 0, 0,
    /*  !--FIELD TEXTUAL f248 NAME=L ...  VALUE="&nbsp;&nbsp;cycle:"         */
    0, 32, 10, 6, 1, 0, 0, 18, 0, 18, 'f', '2', '4', '8', 0, '&', 'n',
    'b', 's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', 'c', 'y', 'c',
    'l', 'e', ':', 0,
    /*  !--FIELD SELECT f249 NAME=el ... ekly" 4="Monthly" 5="Never"         */
    0, 57, 15, 0, 1, 1, 5, 'f', '2', '4', '9', 0, '0', 0, 'A', 't', 32,
    's', 't', 'a', 'r', 't', 'u', 'p', 0, 'H', 'o', 'u', 'r', 'l', 'y',
    0, 'D', 'a', 'i', 'l', 'y', 0, 'W', 'e', 'e', 'k', 'l', 'y', 0, 'M',
    'o', 'n', 't', 'h', 'l', 'y', 0, 'N', 'e', 'v', 'e', 'r', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 4, 1, 0, 8, 'A',
    /*  <P>                                                                  */
    0, 4, 1, 0, 8, 'V',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 3, 'z',
    /*  !--FIELD TEXTUAL f250 NAME=L ... UE="Actions for this page:"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '2', '5', '0', 0, 'A', 'c',
    't', 'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's',
    32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 3, 197,
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 12, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a',
    'u', 'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 13, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 4, 3,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 160,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 160,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm16_fields [] = {
    { 0, 121, 80 },                     /*  message_to_user                 */
    { 82, 931, 18 },                    /*  l_enabled                       */
    { 102, 1008, 1 },                   /*  enabled                         */
    { 105, 1047, 19 },                  /*  l_rootdir                       */
    { 126, 1088, 100 },                 /*  rootdir                         */
    { 228, 1116, 25 },                  /*  l_port                          */
    { 255, 1163, 4 },                   /*  port                            */
    { 261, 1196, 24 },                  /*  l_timeout                       */
    { 287, 1242, 6 },                   /*  timeout                         */
    { 295, 1286, 20 },                  /*  l_limit                         */
    { 317, 1328, 4 },                   /*  limit                           */
    { 323, 1371, 24 },                  /*  l_user_file                     */
    { 349, 1417, 40 },                  /*  user_file                       */
    { 391, 1481, 22 },                  /*  l_directory_file                */
    { 415, 1525, 40 },                  /*  directory_file                  */
    { 457, 1588, 16 },                  /*  l_welcome                       */
    { 475, 1626, 240 },                 /*  welcome                         */
    { 717, 1675, 33 },                  /*  l_email_check                   */
    { 752, 1730, 1 },                   /*  email_check                     */
    { 755, 1761, 19 },                  /*  l_http_aliases                  */
    { 776, 1802, 1 },                   /*  http_aliases                    */
    { 779, 1880, 16 },                  /*  l_webmask                       */
    { 797, 1918, 80 },                  /*  webmask                         */
    { 879, 1969, 21 },                  /*  l_data_port                     */
    { 902, 2012, 4 },                   /*  data_port                       */
    { 908, 2045, 19 },                  /*  l_ipaddress                     */
    { 929, 2086, 3 },                   /*  ipaddress                       */
    { 934, 2153, 17 },                  /*  l_alog_enabled                  */
    { 953, 2192, 1 },                   /*  alog_enabled                    */
    { 956, 2211, 20 },                  /*  l_alog_filename                 */
    { 978, 2247, 40 },                  /*  alog_filename                   */
    { 1020, 2263, 18 },                 /*  l_alog_cycle                    */
    { 1040, 2297, 3 },                  /*  alog_cycle                      */
    { 1045, 2368, 15 },                 /*  l_elog_enabled                  */
    { 1062, 2405, 1 },                  /*  elog_enabled                    */
    { 1065, 2424, 20 },                 /*  l_elog_filename                 */
    { 1087, 2460, 40 },                 /*  elog_filename                   */
    { 1129, 2476, 18 },                 /*  l_elog_cycle                    */
    { 1149, 2510, 3 },                  /*  elog_cycle                      */
    { 1154, 2593, 22 },                 /*  l_noname14                      */
    { 1178, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_enabled_a          ;
    char   l_enabled            [18 + 1];
    byte   enabled_a            ;
    char   enabled              [1 + 1];
    byte   l_rootdir_a          ;
    char   l_rootdir            [19 + 1];
    byte   rootdir_a            ;
    char   rootdir              [100 + 1];
    byte   l_port_a             ;
    char   l_port               [25 + 1];
    byte   port_a               ;
    char   port                 [4 + 1];
    byte   l_timeout_a          ;
    char   l_timeout            [24 + 1];
    byte   timeout_a            ;
    char   timeout              [6 + 1];
    byte   l_limit_a            ;
    char   l_limit              [20 + 1];
    byte   limit_a              ;
    char   limit                [4 + 1];
    byte   l_user_file_a        ;
    char   l_user_file          [24 + 1];
    byte   user_file_a          ;
    char   user_file            [40 + 1];
    byte   l_directory_file_a   ;
    char   l_directory_file     [22 + 1];
    byte   directory_file_a     ;
    char   directory_file       [40 + 1];
    byte   l_welcome_a          ;
    char   l_welcome            [16 + 1];
    byte   welcome_a            ;
    char   welcome              [240 + 1];
    byte   l_email_check_a      ;
    char   l_email_check        [33 + 1];
    byte   email_check_a        ;
    char   email_check          [1 + 1];
    byte   l_http_aliases_a     ;
    char   l_http_aliases       [19 + 1];
    byte   http_aliases_a       ;
    char   http_aliases         [1 + 1];
    byte   l_webmask_a          ;
    char   l_webmask            [16 + 1];
    byte   webmask_a            ;
    char   webmask              [80 + 1];
    byte   l_data_port_a        ;
    char   l_data_port          [21 + 1];
    byte   data_port_a          ;
    char   data_port            [4 + 1];
    byte   l_ipaddress_a        ;
    char   l_ipaddress          [19 + 1];
    byte   ipaddress_a          ;
    char   ipaddress            [3 + 1];
    byte   l_alog_enabled_a     ;
    char   l_alog_enabled       [17 + 1];
    byte   alog_enabled_a       ;
    char   alog_enabled         [1 + 1];
    byte   l_alog_filename_a    ;
    char   l_alog_filename      [20 + 1];
    byte   alog_filename_a      ;
    char   alog_filename        [40 + 1];
    byte   l_alog_cycle_a       ;
    char   l_alog_cycle         [18 + 1];
    byte   alog_cycle_a         ;
    char   alog_cycle           [3 + 1];
    byte   l_elog_enabled_a     ;
    char   l_elog_enabled       [15 + 1];
    byte   elog_enabled_a       ;
    char   elog_enabled         [1 + 1];
    byte   l_elog_filename_a    ;
    char   l_elog_filename      [20 + 1];
    byte   elog_filename_a      ;
    char   elog_filename        [40 + 1];
    byte   l_elog_cycle_a       ;
    char   l_elog_cycle         [18 + 1];
    byte   elog_cycle_a         ;
    char   elog_cycle           [3 + 1];
    byte   l_noname14_a         ;
    char   l_noname14           [22 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   server_a;
    byte   aliases_a;
    byte   vhosts_a;
    byte   cgi_a;
    byte   security_a;
    byte   logging_a;
    byte   mime_a;
    byte   define_users_a;
    byte   define_dirs_a;
    byte   ftp_aliases_a;
    byte   defaults_a;
    byte   undo_a;
    } XIADM16_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm16 = {
    xiadm16_blocks,
    xiadm16_fields,
    140,                                /*  Number of blocks in form        */
    40,                                 /*  Number of fields in form        */
    14,                                 /*  Number of actions in form       */
    1178,                               /*  Size of fields                  */
    "xiadm16",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
