Log file directory

To change the location of log files, modify the server:log-dir option.
