This file holds debug trace files created by Xitami.  You can change the
location Xitami uses by modifying the server:debug_dir option, for instance
to use an environment variable like $(TEMP).
