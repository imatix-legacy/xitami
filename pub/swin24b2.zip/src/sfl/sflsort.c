/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflsort.c
    Title:      List sorting functions
    Package:    Standard Function Library (SFL)

    Written:    98/07/07  Jonathan Schultz <jonathan@imatix.com>
    Revised:    98/07/07  Jonathan Schultz <jonathan@imatix.com>

    Copyright:  Copyright (c) 1991-98 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sfllist.h"                    /*  List declarations                */
#include "sflsort.h"                    /*  Prototypes for functions         */


/*  ---------------------------------------------------------------------[<]-
    Function: comb_sort

    Synopsis: Sorts a list using the "comb-sort" algorithm
    ---------------------------------------------------------------------[>]-*/

void comb_sort (void *list, LIST_COMPARE *comp)
{
    size_t
        jump_size,
        i;
    LIST
        *base,
        *swap,
        *temp;
    Bool
        stop;

    jump_size = 0;
    FORLIST (base, (* (LIST *) list))
        jump_size++;

    stop = FALSE;
    while ((jump_size >= 1) && (!stop))
      {
        jump_size = (10 * jump_size + 3) / 13;
        base = ((LIST *) list)-> next;
        swap = base;
        for (i = 0; i < jump_size; i++)
            swap = swap-> next;

        stop = TRUE;
        while (swap != (LIST *) list)
          {
            if (comp (base, swap) > 0)
              {
                temp = base-> prev;
                list_unlink (base);
                list_relink_after (base, swap);
                list_unlink (swap);
                list_relink_after (swap, temp);
                temp = base;
                base = swap;
                swap = temp;
                stop = FALSE;
              }
            base = base-> next;
            swap = swap-> next;
          }
      }
}
