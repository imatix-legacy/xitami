/*  --------------------------- N O T I C E ------------------------------
    This file has been stripped of symbolic information in order to protect
    trade secrets and protected and/or confidential source code.  This file
    remains Copyright (c) 1997 iMatix and is subject to the following terms
    and conditions in addition to the license terms agreed-on between the
    user and iMatix:
    1.  All reverse-engineering, reconstruction, or partial reuse of this
        source code is forbidden.
    2.  Any modification of this source code will consitute a violation of
        the license and guarantee terms agreed between the user and iMatix.
    3.  Distribution of this source code is allowed only according to the
        terms of the respective product license agreement.
    ---------------------------------------------------------------------- */
#include "sfl.h"
#include "formio.h"
char
*form_strerror;
RANGE
range_all = { 0, -1 },
range_none = { -1, 0 };
static FORM_ITEM
*_3655;
static SYMTAB
*_3656;
static int
_3657;
enum {
_3658 = 1,
focus_field = 2,
_3659 = 3
};
static char
*_3660 = "<TABLE><TR><TD BGCOLOR=\"#FF0000\">&gt;",
*_3661 = "</TABLE>";
static FORM_ITEM *_3662 (FORM_DEFN *defn);
static char *_3663 (byte *_3664);
static void _3665 (VDESCR *stream, byte *block, int field, int _3666);
static void _3667 (VDESCR *stream, char *source, int size);
static void _3668 (VDESCR *stream, char *source);
static void _3669 (VDESCR *stream, char *format, ...);
static void _3670 (VDESCR *stream, byte *block);
static void _3671 (VDESCR *stream, byte *block);
static void _3672 (VDESCR *stream, byte *block, int field, int _3666);
static void _3673 (VDESCR *stream, byte *block, int field, int _3666);
static void _3674 (VDESCR *stream, byte *block, int field, int _3666);
static void _3675 (VDESCR *stream, byte *block, int field, int _3666);
static void _3676 (VDESCR *stream, byte *block, int field, int _3666);
static void _3677 (VDESCR *stream, byte *block, int field, int _3666);
static void _3678 (VDESCR *stream, byte *block, int field, int _3666);
static void _3679 (VDESCR *stream, byte *block, int field, int _3666);
static void _3680 (VDESCR *stream, byte *block, int field, int _3666);
static void _3681 (VDESCR *stream, byte *block, int index);
static void _3682 (VDESCR *stream, byte *block);
static void _3683 (VDESCR *stream, char *value, int field, int _3666);
static void _3684 (byte *block, int field, int index, byte attr);
static Bool _3685 (int field);
static Bool _3686 (int field, int index);
static Bool _3687 (RANGE *range, int field);
static byte *_3688 (int field, int index);
static char *_3689 (int field, int index);
static char *_3690 (byte *block, int index);
static void _3691 (byte *block, int *flags, int *_3692, int *_3693,
int *width);
static int _3694 (byte *block, int field, int index, char *value);
static void _3695 (int field, int index);
static int _3696 (byte *block, int field, int index, char *value);
static int _3697 (byte *block, int field, int index, char *value);
static int _3698 (byte *block, int field, int index, char *value);
static int _3699 (byte *block, int field, int index, char *value);
static int _3700 (byte *block, int field, int index, char *value);
static void _3701 (SYMTAB *symtab, byte *block);
static Bool _3702 (char *value);
static char *_3703 (int field, int index, int item, char _3704);
static char *_3705 (int field, int index, int item, char _3704);
static Bool _3706 (FORM_ITEM *form, byte *_3664,
int _3707, va_list _3708);
static Bool _3709 (FORM_ITEM *form, byte *_3664,
int _3707, va_list _3708);
static Bool _3710 (FORM_ITEM *form, byte *_3664,
int _3707, va_list _3708);
static Bool _3711 (FORM_ITEM *form, byte *_3664,
int _3707, va_list _3708);
static Bool _3712 (SYMBOL *symbol, ...);
static void _3713 (SYMTAB *symtab);
#define _3714(b) ((b) [0] << 8) + ((b) [1])
#define _3715(b) ((b) [2])
#define _3716(b) ((b) [3])
#define _3717(b) ((b) [4])
#define _3718(b) ((char *) ((b) + 3))
#define _3719(b) ((b) [3])
#define _3720(b) ((b) [4] << 8) + ((b) [5])
#define _3721(b) ((b) [6] << 8) + ((b) [7])
#define _3722(b) ((b) [3] << 8) + ((b) [4])
#define _3723(b) ((b) [5] << 8) + ((b) [6])
#define _3724(b) ((b) [3] << 8) + ((b) [4])
#define _3725(b) ((b) [5] << 8) + ((b) [6])
#define _3726(b) ((b) [3] << 8) + ((b) [4])
#define _3727(b) ((b) [5] << 8) + ((b) [6])
#define _3728(b) ((b) [7] << 8) + ((b) [8])
#define _3729(b) ((b) [3])
#define _3730(b) ((b) [4])
#define _3731(b) ((b) [5])
#define _3732(b) ((b) [6] << 8) + ((b) [7])
#define _3733(b) ((b) [8] << 8) + ((b) [9])
#define _3734(b) ((char *) ((b) + 10))
#define _3735(b) (_3734 (b) + strlen (_3734 (b)) + 1)
#define _3736(b) ((b) [3])
#define _3737(b) ((b) [4])
#define _3738(b) ((b) [5] << 8) + ((b) [6])
#define _3739(b) ((b) [7] << 8) + ((b) [8])
#define _3740(b) ((char *) ((b) + 9))
#define _3741(b) (_3740 (b) + strlen (_3740 (b)) + 1)
#define _3742(b) ((b) [3])
#define _3743(b) ((b) [4])
#define _3744(b) ((b) [5] << 8) + ((b) [6])
#define _3745(b) ((b) [7] << 8) + ((b) [8])
#define _3746(b) ((b) [9])
#define _3747(b) ((b) [10])
#define _3748(b) ((b) [11])
#define _3749(b) ((b) [12])
#define _3750(b) ((b) [13])
#define _3751(b) ((b) [14])
#define _3752(b) ((char *) ((b) + 15))
#define _3753(b) (_3752 (b) + strlen (_3752 (b)) + 1)
#define _3754(b) ((b) [3])
#define _3755(b) ((b) [4])
#define _3756(b) ((b) [5] << 8) + ((b) [6])
#define _3757(b) ((b) [7])
#define _3758(b) ((b) [8])
#define _3759(b) ((b) [9])
#define _3760(b) ((b) [10])
#define _3761(b) ((b) [11])
#define _3762(b) (char *) ((b) + 12)
#define _3763(b) (_3762 (b) + strlen (_3762 (b)) + 1)
#define _3764(b) (_3763 (b) + strlen (_3763 (b)) + 1)
#define _3765(b) ((b) [3])
#define _3766(b) ((b) [4])
#define _3767(b) ((b) [5] << 8) + ((b) [6])
#define _3768(b) (char *) ((b) + 7)
#define _3769(b) (_3768 (b) + strlen (_3768 (b)) + 1)
#define _3770(b) (_3769 (b) + strlen (_3769 (b)) + 1)
#define _3771(b) ((b) [3])
#define _3772(b) ((b) [4])
#define _3773(b) ((b) [5])
#define _3774(b) ((b) [6])
#define _3775(b) ((b) [7])
#define _3776(b) ((b) [8] << 8) + ((b) [9])
#define _3777(b) ((char *) ((b) + 10))
#define _3778(b) (_3777 (b) + strlen (_3777 (b)) + 1)
#define _3779(b) ((b) [3])
#define _3780(b) ((b) [4])
#define _3781(b) ((char *) ((b) + 5))
#define _3782(b) (_3781 (b) + strlen (_3781 (b)) + 1)
#define _3783(b) (_3782 (b) + strlen (_3782 (b)) + 1)
#define _3784(b) (_3783 (b) + strlen (_3783 (b)) + 1)
#define _3785(b) ((b) [3])
#define _3786(b) ((b) [4])
#define _3787(b) ((b) [5])
#define _3788(b) ((b) [6])
#define _3789(b) ((char *) ((b) + 7))
#define _3790(b) (_3789 (b) + strlen (_3789 (b)) + 1)
#define _3791(b) (_3790 (b) + strlen (_3790 (b)) + 1)
#define _3792(b) (_3791 (b) + strlen (_3791 (b)) + 1)
#define _3793(b) ((b) [3])
#define _3794(b) ((b) [4])
#define _3795(b) ((b) [5])
#define _3796(b) ((b) [6])
#define _3797(b) ((char *) ((b) + 7))
#define _3798(b) (_3797 (b) + strlen (_3797 (b)) + 1)
#define _3799(b) (_3798 (b) + strlen (_3798 (b)) + 1)
#define _3800(b) ((b) [3] << 8) + ((b) [4])
#define _3801(b) ((b) [5])
#define _3802(b) ((char *) ((b) + 6))
#define _3803(b) ((b) [3])
#define _3804(b) ((b) [4] << 8) + ((b) [5])
#define _3805(b) ((b) [6] << 8) + ((b) [7])
#define _3806(b) ((b) [8])
#define _3807(b) ((b) [9] << 8) + ((b) [10])
#define _3808(b) ((b) [11] << 8) + ((b) [12])
#define _3809(b) ((char *) ((b) + 13))
#define _3810(b) (_3809 (b) + strlen (_3809 (b)) + 1)
#define _3811(t) ((t) == BLOCK_TEXTUAL || \
(t) == BLOCK_NUMERIC || \
(t) == BLOCK_DATE || \
(t) == BLOCK_TIME || \
(t) == BLOCK_TEXTBOX || \
(t) == BLOCK_BOOLEAN || \
(t) == BLOCK_SELECT || \
(t) == BLOCK_FILE || \
(t) == BLOCK_RADIO )
#define _3812(f) ((char *) _3655-> data + \
_3655-> defn-> fields [f].data)
#define _3813(f) (_3655-> defn-> blocks + \
_3655-> defn-> fields [f].block)
#define _3814(f) (_3655-> defn-> fields [f].max)
#define _3815(b) (_3655-> data + \
_3655-> defn-> fields_size + _3805 (b))
#define _3816 1
typedef struct {
char *input;
char *output;
int _3817;
int _3818;
} _3819;
static _3819 _3820 [] = {
{ "TEXT", "%s",                 0, 0 },
{ "TEXT", "%s",                 1, 0 },
{ "PASSWORD", "",               0, 0 },
{  NULL,  "%s",                 0, 0 },
{ "HIDDEN", "",                 0, 1 },
{  NULL,  "",                   0, 1 },
{  NULL, "%s",                  0, 0 },
{  NULL, "<EM>%s</EM>",         0, 0 },
{  NULL, "<STRONG>%s</STRONG>", 0, 0 },
{  NULL, "<BIG>%s</BIG>",       0, 0 },
{  NULL, "%s",                  0, 0 }
};
FORM_ITEM *
form_init (
FORM_DEFN *defn,
Bool values)
{
FORM_ITEM
*form;
ASSERT (defn);
if ((form = _3662 (defn)) == NULL)
return (NULL);
if (values)
{
form-> language = FLANG_ENGLISH;
form-> date_order = DATE_ORDER_DMY;
form-> date_sep = '/';
form-> dec_point = '.';
form-> input_range = range_all;
form-> blank_range = range_none;
form-> JavaScript = 1;
form-> focus_field = 0;
form-> focus_index = 0;
form-> click_field = 0;
form-> click_index = 0;
form_use (form);
form_exec (form, _3706);
}
return (form);
}
static FORM_ITEM *
_3662 (
FORM_DEFN *defn)
{
FORM_ITEM
*form;
MEMTRN
*_3821;
ASSERT (defn);
_3821 = mem_new_trans ();
if ((form = mem_alloc (sizeof (FORM_ITEM))) == NULL)
return (NULL);
memset (form, 0, sizeof (FORM_ITEM));
form-> defn = defn;
form-> data_size = defn-> fields_size + defn-> action_count;
form-> data = mem_alloc (form-> data_size);
if (form-> data == NULL)
{
mem_rollback (_3821);
return (NULL);
}
memset (form-> data, 0, form-> data_size);
mem_commit (_3821);
return (form);
}
static Bool
_3706 (
FORM_ITEM *form,
byte *_3664,
int _3707,
va_list _3708)
{
byte
_3822,
_3823;
char
*_3824,
*_3825;
int
_3826;
if (_3811 (_3715 (_3664)))
{
_3822 = _3717 (_3664);
_3823 = _3716 (_3664);
_3825 = _3663 (_3664);
_3824 = _3812 (_3707);
for (_3826 = 0; _3826 < _3822; _3826++)
*_3824++ = _3823;
ASSERT (strlen (_3825) <= _3814 (_3707));
for (_3826 = 0; _3826 < _3822; _3826++)
{
strcpy ((char *) _3824, _3825);
_3824 += _3814 (_3707) + 1;
}
}
else
if (_3715 (_3664) == BLOCK_ACTION)
*_3815 (_3664) = _3806 (_3664);
return (TRUE);
}
static char *
_3663 (byte *_3664)
{
switch (_3715 (_3664))
{
case BLOCK_TEXTUAL: return (_3735 (_3664));
case BLOCK_FILE: return (_3741 (_3664));
case BLOCK_NUMERIC: return (_3753 (_3664));
case BLOCK_DATE: return (_3763 (_3664));
case BLOCK_TIME: return (_3769 (_3664));
case BLOCK_TEXTBOX: return (_3778 (_3664));
case BLOCK_BOOLEAN: return (_3782 (_3664));
case BLOCK_SELECT: return (_3790 (_3664));
case BLOCK_RADIO: return (_3798 (_3664));
}
return (NULL);
}
void
form_term (
FORM_ITEM *form)
{
if (form)
{
if (form-> list_values)
sym_delete_table (form-> list_values);
mem_free (form-> data);
mem_free (form);
}
}
void
form_use (
FORM_ITEM *form)
{
ASSERT (form);
_3655 = form;
}
size_t
form_put (
FORM_ITEM *form,
VDESCR *stream,
SYMTAB *symtab)
{
byte
*_3664,
_3827,
*_3828;
int
_3707,
_3829,
_3830,
_3831,
_3832,
_3833,
_3834;
ASSERT (form);
ASSERT (stream);
ASSERT (symtab);
stream-> cur_size = 0;
stream-> data = stream-> data;
form-> status = FSTATUS_OK;
_3707 = -1;
_3830 = 0;
_3829 = 0;
_3664 = form-> defn-> blocks;
_3655 = form;
_3656 = symtab;
_3657 = 0;
sym_assume_symbol (symtab, "_focus", "jsaction");
while (_3829 < form-> defn-> block_count)
{
_3827 = _3715 (_3664);
if (_3811 (_3827))
_3707++;
if (_3830 > 0)
_3830--;
else
if (_3827 == BLOCK_IF)
{
if (_3702 (_3689 (_3722 (_3664), 0)))
_3830 = _3723 (_3664);
}
else
if (_3827 == BLOCK_UNLESS)
{
if (!_3702 (_3689 (_3724 (_3664), 0)))
_3830 = _3725 (_3664);
}
else
if (_3827 == BLOCK_REPEAT)
{
_3831 = atoi (_3689 (_3726 (_3664), 0));
for (_3832 = 0; _3832 < _3831; _3832++)
{
_3833 = _3707;
_3828 = _3664;
for (_3834 = 0;
_3834 < _3727 (_3664);
_3834++)
{
_3828 += _3714 (_3828) + 2;
if (_3811 (_3715 (_3828)))
_3833++;
_3665 (stream, _3828, _3833,
_3832);
}
}
_3830 = _3727 (_3664);
}
else
if (!_3685 (_3707))
_3665 (stream, _3664, _3707, 0);
_3664 += _3714 (_3664) + 2;
_3829++;
}
form-> focus_field = 0;
form-> focus_index = 0;
if (stream-> cur_size >= stream-> max_size)
stream-> cur_size = stream-> max_size - 1;
stream-> data [stream-> cur_size] = '\0';
return (stream-> cur_size);
}
static Bool
_3685 (int _3707)
{
return (_3687 (&_3655-> blank_range, _3707));
}
static Bool
_3687 (RANGE *range, int _3707)
{
if (range-> first == -1)
return (FALSE);
else
if (range-> last == -1)
return (TRUE);
else
return (range-> first <= _3707 &&
_3707 <= range-> last);
}
static void
_3665 (
VDESCR *stream,
byte *_3664,
int _3707,
int index)
{
switch (_3715 (_3664))
{
case BLOCK_PLAIN:
_3670 (stream, _3664);
break;
case BLOCK_COMPRESSED:
_3671 (stream, _3664);
break;
case BLOCK_TEXTUAL:
_3672 (stream, _3664, _3707, index);
break;
case BLOCK_FILE:
_3673 (stream, _3664, _3707, index);
break;
case BLOCK_NUMERIC:
_3674 (stream, _3664, _3707, index);
break;
case BLOCK_DATE:
_3675 (stream, _3664, _3707, index);
break;
case BLOCK_TIME:
_3676 (stream, _3664, _3707, index);
break;
case BLOCK_TEXTBOX:
_3677 (stream, _3664, _3707, index);
break;
case BLOCK_BOOLEAN:
_3678 (stream, _3664, _3707, index);
break;
case BLOCK_SELECT:
_3679 (stream, _3664, _3707, index);
break;
case BLOCK_RLABEL:
_3680 (stream, _3664, _3707, index);
break;
case BLOCK_ACTION:
_3681 (stream, _3664, index);
break;
}
}
static void
_3670 (VDESCR *stream, byte *_3664)
{
_3667 (stream, _3718 (_3664), _3714 (_3664) - 1);
}
static void
_3667 (VDESCR *stream, char *source, int size)
{
static char
_3835 [FORMIO_SYMNAME_MAX + 1];
char
*_3836,
*_3837,
*_3838;
int
_3839;
while (size > 0 && (_3836 = memchr (source, '#', size)) != NULL)
{
if (_3836 > source)
{
_3667 (stream, source, (int) (_3836 - source));
size -= (int) (_3836 - source);
source = _3836;
}
_3837 = memchr (source, ')', size);
if (source [1] == '(' && _3837)
{
_3839 = (int) (_3837 - source - 2);
if (_3839 <= FORMIO_SYMNAME_MAX)
{
memcpy (_3835, source + 2, _3839);
_3835 [_3839] = '\0';
_3838 = sym_get_value (_3656, _3835, "(?)");
_3667 (stream, _3838, strlen (_3838));
}
else
_3667 (stream, source, (int) (_3837 - source) + 1);
size -= (int) (_3837 - source) + 1;
source = _3837 + 1;
}
else
{
if ((stream-> cur_size + 1) < stream-> max_size)
{
memcpy (stream-> data + stream-> cur_size, source, 1);
stream-> cur_size += 1;
}
size--;
source++;
}
}
if ((stream-> cur_size + size) < stream-> max_size)
{
memcpy (stream-> data + stream-> cur_size, source, size);
stream-> cur_size += size;
}
}
static void
_3668 (VDESCR *stream, char *source)
{
_3667 (stream, source, strlen (source));
}
static void
_3671 (VDESCR *stream, byte *_3664)
{
byte
*_3840;
word
block_size;
_3840 = _3720 (_3664) + _3655-> defn-> blocks;
if (_3719 (_3664) == COMPR_WHOLEDICT)
block_size = _3714 (_3840) - 1;
else
if (_3719 (_3664) == COMPR_PARTDICT)
block_size = _3721 (_3664);
else
abort ();
_3667 (stream, _3718 (_3840), block_size);
}
static void
_3672 (VDESCR *stream, byte *_3664, int _3707, int index)
{
char
*value;
_3819
*_3841;
byte
attr;
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
value = _3689 (_3707, index);
if (_3731 (_3664) & _3816)
strupc (value);
if (_3841-> input && _3686 (_3707, index))
{
_3684 (_3664, _3707, index, attr);
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3841-> input,
_3690 (_3664, index),
_3732 (_3664),
_3733 (_3664),
attr == FATTR_SECURE? "": value);
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
if (!_3841-> _3818)
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
static void
_3684 (byte *block, int field, int index, byte attr)
{
char
*name;
if ((name = _3690 (block, index)) == NULL)
return;
if (attr == FATTR_ERROR
&& _3657 < _3659)
{
_3657 = _3659;
sym_assume_symbol (_3656, "_focus", name);
}
else
if (field == _3655-> focus_field
&& index == _3655-> focus_index
&& _3657 < focus_field)
{
_3657 = focus_field;
sym_assume_symbol (_3656, "_focus", name);
}
else
if (attr != FATTR_HIDDEN
&& _3657 < _3658)
{
_3657 = _3658;
sym_assume_symbol (_3656, "_focus", name);
}
}
static void
_3673 (VDESCR *stream, byte *_3664, int _3707, int index)
{
char
*_3842,
*value,
*_3843;
_3819
*_3841;
byte
attr;
value = _3689 (_3707, index);
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> input && _3686 (_3707, index))
{
_3684 (_3664, _3707, index, attr);
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<INPUT TYPE=FILE NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3690 (_3664, index),
_3738 (_3664),
_3739 (_3664),
attr == FATTR_SECURE? "": value);
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (attr == FATTR_OPTION
|| attr == FATTR_LABEL
|| attr == FATTR_HILITE)
{
_3842 = strrchr (value, '/');
if (_3842 == NULL)
_3842 = strrchr (value, '\\');
if (_3842 == NULL)
_3842 = value;
else
_3842++;
_3843 = _3689 (_3707 - 1, index);
_3669 (stream,
"<A HREF=\"/%s\">%s</A>", _3843, _3842);
}
else
if (!_3841-> _3818)
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
static Bool
_3686 (int _3707, int index)
{
if (*_3688 (_3707, index) == FATTR_HIDDEN
|| _3687 (&_3655-> input_range, _3707))
return (TRUE);
else
return (FALSE);
}
static char *
_3690 (byte *_3664, int index)
{
static
char _3844 [LINE_MAX + 8];
switch (_3715 (_3664))
{
case BLOCK_TEXTUAL:
strncpy (_3844, _3734 (_3664), LINE_MAX);
break;
case BLOCK_FILE:
strncpy (_3844, _3740 (_3664), LINE_MAX);
break;
case BLOCK_NUMERIC:
strncpy (_3844, _3752 (_3664), LINE_MAX);
break;
case BLOCK_DATE:
strncpy (_3844, _3762 (_3664), LINE_MAX);
break;
case BLOCK_TIME:
strncpy (_3844, _3768 (_3664), LINE_MAX);
break;
case BLOCK_TEXTBOX:
strncpy (_3844, _3777 (_3664), LINE_MAX);
break;
case BLOCK_BOOLEAN:
strncpy (_3844, _3781 (_3664), LINE_MAX);
break;
case BLOCK_SELECT:
strncpy (_3844, _3789 (_3664), LINE_MAX);
break;
case BLOCK_RADIO:
strncpy (_3844, _3797 (_3664), LINE_MAX);
break;
default:
return (NULL);
}
if (index)
sprintf (_3844 + strlen (_3844), "_%d", index);
return (_3844);
}
static void
_3683 (VDESCR *stream, char *value, int _3707, int index)
{
if (strnull (value))
value = "&lt;Empty&gt;";
if (_3655-> JavaScript)
_3669 (stream,
"<A HREF=\"javascript:submit('~C%d.%d')\">%s</A>\n",
_3707, index, value);
else
_3669 (stream,
"<A HREF=\"#(uri)&~C%d.%d=1\">%s</A>\n",
_3707, index, value);
}
static byte *
_3688 (int _3707, int index)
{
ASSERT (_3707 < _3655-> defn-> field_count);
return (_3655-> data +
_3655-> defn-> fields [_3707].data + index);
}
static char *
_3689 (int _3707, int index)
{
ASSERT (_3707 < _3655-> defn-> field_count);
ASSERT (index < _3717 (_3813 (_3707)));
return (_3812 (_3707)
+ _3717 (_3813 (_3707))
+ (_3814 (_3707) + 1) * index);
}
static Bool
_3702 (char *value)
{
while (*value == '0')
value++;
return (*value == '\0');
}
static void
_3669 (VDESCR *stream, char *format, ...)
{
static char
_3845 [LINE_MAX];
va_list
_3708;
va_start (_3708, format);
#if (defined (DOES_SNPRINTF))
vsnprintf (_3845, LINE_MAX, format, _3708);
#else
vsprintf (_3845, format, _3708);
#endif
va_end (_3708);
_3667 (stream, _3845, strlen (_3845));
}
static void
_3674 (VDESCR *stream, byte *_3664, int _3707, int index)
{
_3819
*_3841;
char
*value;
byte
attr;
int
_3846,
sign_format,
_3847,
_3848;
_3691 (
_3664,
&_3846,
&sign_format,
&_3847,
&_3848);
value = conv_number_str (
_3689 (_3707, index),
_3846,
_3655-> dec_point,
_3746 (_3664),
_3847,
_3848,
sign_format);
if (value == NULL)
value = conv_reason_text [conv_reason];
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> input && _3686 (_3707, index))
{
_3684 (_3664, _3707, index, attr);
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3841-> input,
_3690 (_3664, index),
_3744 (_3664),
_3745 (_3664),
attr == FATTR_SECURE? "": value);
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
if (!_3841-> _3818)
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
static void
_3691 (byte *_3664, int *flags, int *_3692, int *_3693, int *width)
{
*flags = 0;
switch (_3747 (_3664))
{
case FSIGN_NONE:
*_3692 = 0;
break;
case FSIGN_POST:
*flags += FLAG_N_SIGNED;
*_3692 = SIGN_NEG_TRAIL;
break;
case FSIGN_PRE:
*flags += FLAG_N_SIGNED;
*_3692 = SIGN_NEG_LEAD;
break;
case FSIGN_POSTPLUS:
*flags += FLAG_N_SIGNED;
*_3692 = SIGN_ALL_TRAIL;
break;
case FSIGN_PREPLUS:
*flags += FLAG_N_SIGNED;
*_3692 = SIGN_ALL_LEAD;
break;
case FSIGN_FINANCIAL:
*flags += FLAG_N_SIGNED;
*_3692 = SIGN_FINANCIAL;
break;
}
switch (_3748 (_3664))
{
case FDECFMT_NONE:
*_3693 = 0;
break;
case FDECFMT_ALL:
*flags += FLAG_N_DECIMALS;
*_3693 = DECS_SHOW_ALL;
break;
case FDECFMT_DROP:
*flags += FLAG_N_DECIMALS;
*_3693 = DECS_DROP_ZEROS;
break;
}
switch (_3749 (_3664))
{
case FFILL_NONE:
*width = 0;
break;
case FFILL_SPACE:
*width = _3744 (_3664);
break;
case FFILL_ZERO:
*width = _3744 (_3664);
*flags += FLAG_N_ZERO_FILL;
break;
}
if (_3750 (_3664))
*flags += FLAG_N_ZERO_BLANK;
if (_3751 (_3664))
*flags += FLAG_N_THOUSANDS;
}
static void
_3675 (VDESCR *stream, byte *_3664, int _3707, int index)
{
char
*picture;
int
flags,
format;
long
_3849;
char
*value;
_3819
*_3841;
byte
attr;
_3849 = atol (_3689 (_3707, index));
picture = _3764 (_3664);
if (strused (picture))
value = conv_date_pict (_3849, picture);
else
{
if (_3757 (_3664) == FSHOW_YMD)
if (_3758 (_3664) == FFORMAT_COMPACT)
format = DATE_YMD_COMPACT;
else
if (_3758 (_3664) == FFORMAT_SLASH)
format = DATE_YMD_DELIM;
else
if (_3758 (_3664) == FFORMAT_SPACE)
format = DATE_YMD_SPACE;
else
if (_3758 (_3664) == FFORMAT_COMMA)
format = DATE_YMD_COMMA;
else
format = DATE_YMD_COMPACT;
else
if (_3757 (_3664) == FSHOW_YM)
if (_3758 (_3664) == FFORMAT_COMPACT)
format = DATE_YM_COMPACT;
else
if (_3758 (_3664) == FFORMAT_SLASH)
format = DATE_YM_DELIM;
else
if (_3758 (_3664) == FFORMAT_SPACE)
format = DATE_YM_SPACE;
else
format = DATE_YM_COMPACT;
else
if (_3757 (_3664) == FSHOW_MD)
if (_3758 (_3664) == FFORMAT_COMPACT)
format = DATE_MD_COMPACT;
else
if (_3758 (_3664) == FFORMAT_SLASH)
format = DATE_MD_DELIM;
else
if (_3758 (_3664) == FFORMAT_SPACE)
format = DATE_MD_SPACE;
else
format = DATE_MD_COMPACT;
else
format = DATE_YMD_COMPACT;
flags = 0;
if (_3759(_3664) == FYEAR_FULL)
flags += FLAG_D_CENTURY;
if (_3760 (_3664) == FMONTH_COUNTER)
flags += FLAG_D_MM_AS_M;
else
if (_3760 (_3664) == FMONTH_ALPHA)
flags += FLAG_D_MONTH_ABC;
else
if (_3760 (_3664) == FMONTH_UPPER)
flags += FLAG_D_UPPER;
if (_3761 (_3664) == FDAY_COUNTER)
flags += FLAG_D_DD_AS_D;
value = conv_date_str (_3849, flags, format,
_3655-> date_order,
_3655-> date_sep,
_3756 (_3664));
}
if (value == NULL)
value = conv_reason_text [conv_reason];
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> input && _3686 (_3707, index))
{
_3684 (_3664, _3707, index, attr);
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3841-> input,
_3690 (_3664, index),
_3756 (_3664),
_3756 (_3664),
attr == FATTR_SECURE? "": value);
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
if (!_3841-> _3818)
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
static void
_3676 (VDESCR *stream, byte *_3664, int _3707, int index)
{
long
_3850;
char
*value;
_3819
*_3841;
byte
attr;
_3850 = atol (_3689 (_3707, index));
value = conv_time_pict (_3850, _3770 (_3664));
if (value == NULL)
value = conv_reason_text [conv_reason];
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> input && _3686 (_3707, index))
{
_3684 (_3664, _3707, index, attr);
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3841-> input,
_3690 (_3664, index),
_3767 (_3664),
_3767 (_3664),
attr == FATTR_SECURE? "": value);
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
if (!_3841-> _3818)
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
static void
_3677 (VDESCR *stream, byte *_3664, int _3707, int index)
{
_3819
*_3841;
char
*_3851,
*value;
byte
attr;
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
value = (attr == FATTR_SECURE? "": _3689 (_3707, index));
if (_3775 (_3664) & _3816)
strupc (value);
if (_3841-> _3818)
;
else
if (_3841-> input && _3686 (_3707, index))
{
_3684 (_3664, _3707, index, attr);
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<TEXTAREA NAME=\"%s\" ROWS=%d COLS=%d MAXLENGTH=%d WRAP=\"%s\">",
_3690 (_3664, index),
_3773 (_3664),
_3774 (_3664),
_3776 (_3664),
"VIRTUAL");
while (*value)
{
if (*value == '<')
_3668 (stream, "&lt;");
else
if (*value == '>')
_3668 (stream, "&gt;");
else
_3667 (stream, value, 1);
value++;
}
_3668 (stream, "</TEXTAREA>\n");
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
{
_3851 = _3841-> output;
while (*_3851)
{
if (*_3851 == '%')
{
_3851 += 2;
break;
}
_3667 (stream, _3851, 1);
_3851++;
}
if (*value)
while (*value)
{
if (*value == '\n')
_3668 (stream, "<BR>");
else
_3667 (stream, value, 1);
value++;
}
else
_3668 (stream, "&nbsp;");
while (*_3851)
_3667 (stream, _3851++, 1);
}
}
static void
_3678 (VDESCR *stream, byte *_3664, int _3707, int index)
{
_3819
*_3841;
char
*value;
byte
attr;
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> _3818)
;
else
if (_3841-> input && _3686 (_3707, index))
{
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream,
"<INPUT TYPE=CHECKBOX %sNAME=\"%s\">\n",
_3689 (_3707, index) [0] == '1'? "CHECKED ": "",
_3690 (_3664, index));
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
{
value = _3689 (_3707, index) [0] == '1'?
_3783 (_3664): _3784 (_3664);
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
}
static void
_3679 (VDESCR *stream, byte *_3664, int _3707, int index)
{
_3819
*_3841;
int
_3852,
_3853,
_3854;
char
*value,
*_3855;
byte
attr;
_3854 = atoi (_3689 (_3707, index));
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> _3818)
;
else
if (_3841-> input && _3686 (_3707, index))
{
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream, "<SELECT NAME=\"%s\" SIZE=%d>\n",
_3690 (_3664, index),
_3787 (_3664));
if (_3788 (_3664) == 0)
{
_3853 = fxlist_size (_3707, index);
for (_3852 = 1; _3852 <= _3853; _3852++)
_3669 (stream, "<OPTION VALUE=\"%d\"%s>%s\n", _3852,
_3852 == _3854? " SELECTED": "",
_3703 (_3707, index, _3852, 'v'));
}
else
{
_3669 (stream, "<OPTION VALUE=\"0\"%s>%s\n",
_3854 == 0? " SELECTED": "",
_3791 (_3664));
_3855 = _3792 (_3664);
for (_3852 = 1; _3852 <= _3788 (_3664); _3852++)
{
_3669 (stream, "<OPTION VALUE=\"%d\"%s>%s\n", _3852,
_3852 == _3854? " SELECTED": "",
_3855);
_3855 += strlen (_3855) + 1;
}
}
_3668 (stream, "</SELECT>\n");
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (_3854 == 0)
_3669 (stream, _3841-> output, _3791 (_3664));
else
{
if (_3788 (_3664) == 0)
value = _3703 (_3707, index, _3854, 'v');
else
{
_3855 = _3791 (_3664);
for (_3852 = 0; _3852 < _3854; _3852++)
_3855 += strlen (_3855) + 1;
value = _3855;
}
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
_3669 (stream, _3841-> output, *value? value: "&nbsp;");
}
}
static void
_3680 (VDESCR *stream, byte *_3664, int _3707, int index)
{
_3819
*_3841;
int
_3856;
byte
*_3857;
char
*value;
byte
attr;
_3856 = atoi (_3689 (_3707, index));
_3857 = _3655-> defn-> blocks + _3800 (_3664);
attr = *_3688 (_3707, index);
_3841 = &_3820 [attr];
if (_3841-> _3818)
;
else
if (_3841-> input && _3686 (_3707, index))
{
if (_3801 (_3664) > 1 && _3796 (_3857))
_3668 (stream, "<BR>");
if (_3841-> _3817)
_3668 (stream, _3660);
_3669 (stream, "<INPUT TYPE=RADIO VALUE=\"%d\" NAME=\"%s\"%s>%s\n",
_3801 (_3664),
_3690 (_3857, index),
_3801 (_3664) == _3856? " CHECKED": "",
_3802 (_3664));
if (_3841-> _3817)
_3668 (stream, _3661);
}
else
if (_3795 (_3857))
{
if (_3801 (_3664) > 1 && _3796 (_3857))
_3668 (stream, "<BR>");
value = xstrcpy (NULL,
_3801 (_3664) == _3856?
" (*) ": " (&nbsp;) ",
_3802 (_3664),
NULL);
if (attr == FATTR_OPTION)
_3683 (stream, value, _3707, index);
else
_3669 (stream, _3841-> output, value);
mem_free (value);
}
else
if (_3856 == 0 && _3801 (_3664) == 1)
{
if (attr == FATTR_OPTION)
_3683 (stream, _3799 (_3857), _3707, index);
else
_3669 (stream, _3841-> output, _3799 (_3857));
}
else
if (_3801 (_3664) == _3856)
{
if (attr == FATTR_OPTION)
_3683 (stream, _3802 (_3664), _3707, index);
else
_3669 (stream, _3841-> output, _3802 (_3664));
}
}
static void
_3681 (VDESCR *stream, byte *_3664, int index)
{
char
*_3858;
if (*_3815 (_3664) == FACTION_ENABLED)
{
if (_3803 (_3664) == FTYPE_BUTTON)
_3669 (stream, "<INPUT TYPE=SUBMIT VALUE=\"%s\" NAME=\"%s\">\n",
_3810 (_3664), _3809 (_3664));
else
if (_3803 (_3664) == FTYPE_PLAIN)
{
if (_3655-> JavaScript)
_3669 (stream,
"<A HREF=\"javascript:submit('~A%d.%d')\">%s</A>\n",
_3804 (_3664), index,
_3810 (_3664));
else
_3669 (stream, "<A HREF=\"#(uri)&~A%d.%d=1\">%s</A>\n",
_3804 (_3664), index,
_3810 (_3664));
}
else
if (_3803 (_3664) == FTYPE_IMAGE)
{
if (_3655-> JavaScript)
{
_3858 = mem_strdup (_3809 (_3664));
_3858 [0] = toupper (_3858 [0]);
_3669   (stream, "<A HREF=\"javascript:submit('~A%d.%d')\"",
_3804 (_3664), index);
_3669   (stream, " TITLE=\"%s\">", _3858);
_3682 (stream, _3664);
_3669   (stream, "</A>");
mem_free (_3858);
}
else
{
_3669 (stream,
"<INPUT TYPE=IMAGE BORDER=0 SRC=\"%s\" NAME=\"%s\"",
_3810 (_3664), _3809 (_3664));
if (_3807 (_3664))
_3669 (stream, " HEIGHT=%d WIDTH=%d",
_3807 (_3664),
_3808 (_3664));
_3669 (stream, ">");
}
}
}
else
if (*_3815 (_3664) == FACTION_DISABLED)
{
if (_3803 (_3664) == FTYPE_BUTTON)
_3669 (stream, "&nbsp;[ %s ]&nbsp;\n", _3810 (_3664));
else
if (_3803 (_3664) == FTYPE_PLAIN)
_3669 (stream, "%s\n", _3810 (_3664));
else
if (_3803 (_3664) == FTYPE_IMAGE)
_3682 (stream, _3664);
}
}
static void
_3682 (VDESCR *stream, byte *_3664)
{
char
*_3858;
_3858 = mem_strdup (_3809 (_3664));
_3858 [0] = toupper (_3858 [0]);
_3669 (stream, "<IMG BORDER=0 SRC=\"%s\" ALT=\"%s\"",
_3810 (_3664), _3858);
if (_3807 (_3664))
_3669 (stream, " HEIGHT=%d WIDTH=%d",
_3807 (_3664), _3808 (_3664));
_3669 (stream, ">");
mem_free (_3858);
}
int
form_get (
FORM_ITEM *form,
const char *query)
{
SYMTAB
*symtab;
int
_3859 = 0;
ASSERT (form);
ASSERT (query);
if ((symtab = http_query2symb (query)) == NULL)
return 0;
form-> status = FSTATUS_OK;
form-> image_x = 0;
form-> image_y = 0;
form-> click_field = 0;
form-> click_index = 0;
strclr (form-> livelink);
form-> event = form-> click_event;
mem_check (form-> data);
form_use (form);
if (*query == '&' || *query == '~')
sym_exec_all (symtab, _3712);
else
{
form_exec (form, _3709, symtab, &_3859);
_3713 (symtab);
}
sym_delete_table (symtab);
return (form-> status == FSTATUS_OK? _3859: -1);
}
static Bool
_3709 (
FORM_ITEM *form,
byte *_3664,
int _3707,
va_list _3708)
{
static int
_3860,
_3861 = 0;
SYMTAB
*symtab;
SYMBOL
*symbol;
byte
_3827;
int
_3862,
*_3863,
_3864,
index;
symtab = va_arg (_3708, SYMTAB *);
_3863 = va_arg (_3708, int *);
if (_3707 == -1)
_3860 = 0;
mem_check (form-> data);
_3827 = _3715 (_3664);
if (_3811 (_3827))
{
_3864 = _3860? _3861: 1;
for (index = 0; index < _3864; index++)
{
if (_3827 == BLOCK_BOOLEAN)
strcpy (_3689 (_3707, index), "0");
_3695 (_3707, index);
symbol = sym_lookup_symbol (symtab, _3690 (_3664, index));
if (symbol)
{
_3862 = _3694 (_3664, _3707, index,
symbol-> value);
if (_3862 == -1)
form-> status = FSTATUS_FIELD;
else
*_3863 += _3862;
}
}
}
else
if (_3827 == BLOCK_ACTION)
_3701 (symtab, _3664);
else
if (_3827 == BLOCK_REPEAT)
{
_3860 = _3727 (_3664) + 1;
_3861 = atoi (_3689 (_3726 (_3664), 0));
}
if (_3860)
_3860--;
return (TRUE);
}
static int
_3694 (byte *_3664, int _3707, int index, char *value)
{
switch (_3715 (_3664))
{
case BLOCK_TEXTUAL:
return (_3696 (_3664, _3707, index, value));
case BLOCK_TEXTBOX:
return (_3697 (_3664, _3707, index, value));
case BLOCK_SELECT:
case BLOCK_RADIO:
case BLOCK_FILE:
return (fxputn_text (_3707, index, value));
case BLOCK_NUMERIC:
return (_3698 (_3664, _3707, index, value));
case BLOCK_DATE:
return (_3699 (_3664, _3707, index, value));
case BLOCK_TIME:
return (_3700 (_3664, _3707, index, value));
case BLOCK_BOOLEAN:
return (fxputn_text (_3707, index, "1"));
}
return (0);
}
static int
_3696 (byte *_3664, int _3707, int index, char *value)
{
if (_3731 (_3664) & _3816)
strupc (value);
return (fxputn_text (_3707, index, value));
}
static int
_3697 (byte *_3664, int _3707, int index, char *value)
{
if (_3775 (_3664) & _3816)
strupc (value);
return (fxputn_text (_3707, index, value));
}
static int
_3698 (byte *_3664, int _3707, int index, char *value)
{
static char
_3865 [LINE_MAX];
int
_3846,
sign_format,
_3847,
_3866;
char
*_3867;
byte
*attr;
_3691 (
_3664,
&_3846,
&sign_format,
&_3847,
&_3866);
_3866 = _3744 (_3664);
_3867 = conv_str_number
(
value,
_3846,
_3655-> dec_point,
_3746 (_3664),
_3847,
_3866
);
if (_3867 == NULL)
{
xstrcpy (_3865, "Invalid number (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _3865;
attr = _3688 (_3707, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_text (_3707, index, _3867));
}
static int
_3699 (byte *_3664, int _3707, int index, char *value)
{
static char
_3868 [LINE_MAX];
int
format;
long
_3849 = -1;
byte
*attr;
if (_3757 (_3664) == FSHOW_YMD)
format = DATE_YMD_DELIM;
else
if (_3757 (_3664) == FSHOW_YM)
format = DATE_YM_DELIM;
else
format = DATE_MD_DELIM;
_3849 = conv_str_date (value, 0, format, _3655-> date_order);
if (_3849 == -1)
{
xstrcpy (_3868, "Invalid date (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _3868;
attr = _3688 (_3707, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_date (_3707, index, _3849));
}
static int
_3700 (byte *_3664, int _3707, int index, char *value)
{
static char
_3869 [LINE_MAX];
long
_3850 = -1;
byte
*attr;
_3850 = conv_str_time (value);
if (_3850 == -1)
{
xstrcpy (_3869, "Invalid time (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _3869;
attr = _3688 (_3707, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_time (_3707, index, _3850));
}
static void
_3695 (int _3707, int index)
{
byte
*attr;
attr = _3688 (_3707, index);
if (*attr == FATTR_ERROR)
*attr = FATTR_INPUT;
}
static void
_3701 (SYMTAB *symtab, byte *_3664)
{
SYMBOL
*symbol;
char
*_3870;
if (_3803 (_3664) == FTYPE_IMAGE)
{
_3870 = xstrcpy (NULL, _3809 (_3664), ".x", NULL);
symbol = sym_lookup_symbol (symtab, _3870);
if (symbol)
{
_3655-> event = _3804 (_3664);
_3655-> image_x = atoi (symbol-> value);
strlast (_3870) = 'y';
symbol = sym_lookup_symbol (symtab, _3870);
if (symbol)
_3655-> image_y = atoi (symbol-> value);
}
mem_free (_3870);
}
else
{
symbol = sym_lookup_symbol (symtab, _3809 (_3664));
if (symbol)
_3655-> event = _3804 (_3664);
}
}
static Bool
_3712 (SYMBOL *symbol, ...)
{
char
*_3871;
if (symbol-> name [0] == '~')
{
_3871 = strchr (symbol-> name + 2, '.');
if (_3871)
_3655-> click_index = atoi (_3871 + 1);
if (symbol-> name [1] == 'C')
{
_3655-> click_field = atoi (symbol-> name + 2);
_3655-> event = _3655-> click_event;
return (FALSE);
}
else
if (symbol-> name [1] == 'A')
{
_3655-> event = atoi (symbol-> name + 2);
return (FALSE);
}
else
if (symbol-> name [1] == 'L')
{
strncpy (_3655-> livelink, symbol-> name + 2,
FORMIO_LIVELINK_MAX);
_3655-> livelink [FORMIO_LIVELINK_MAX] = '\0';
_3655-> event = _3655-> click_event;
return (FALSE);
}
}
return (TRUE);
}
static void
_3713 (SYMTAB *symtab)
{
SYMBOL
*symbol;
char
*_3871;
symbol = sym_lookup_symbol (symtab, "jsaction");
if (symbol && symbol-> value [0] == '~')
{
_3871 = strchr (symbol-> value + 2, '.');
if (_3871)
_3655-> click_index = atoi (_3871 + 1);
if (symbol-> value [1] == 'C')
{
_3655-> click_field = atoi (symbol-> value + 2);
_3655-> event = _3655-> click_event;
}
else
if (symbol-> value [1] == 'A')
_3655-> event = atoi (symbol-> value + 2);
else
if (symbol-> value [1] == 'L')
{
strncpy (_3655-> livelink, symbol-> value + 2,
FORMIO_LIVELINK_MAX);
_3655-> livelink [FORMIO_LIVELINK_MAX] = '\0';
_3655-> event = _3655-> click_event;
}
}
}
int
fxputn_text (int field, int index, const char *new_value)
{
char
*value;
ASSERT (new_value);
ASSERT (index < _3717 (_3813 (field)));
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
value = _3689 (field, index);
if (streq (value, new_value))
return (0);
else
{
strncpy (value, new_value, _3814 (field));
value [_3814 (field)] = '\0';
strcrop (value);
return (1);
}
}
int
fxputn_char (int field, int index, char new_value)
{
char
_3872 [2] = {0, 0};
ASSERT (index < _3717 (_3813 (field)));
_3872 [0] = new_value;
return (fxputn_text (field, index, _3872));
}
int
fxputn_date (int field, int index, long new_value)
{
ASSERT (index < _3717 (_3813 (field)));
return (fxputn_long (field, index, new_value));
}
int
fxputn_time (int field, int index, long new_value)
{
ASSERT (index < _3717 (_3813 (field)));
return (fxputn_long (field, index, new_value));
}
int
fxputn_int (int field, int index, int new_value)
{
ASSERT (index < _3717 (_3813 (field)));
return (fxputn_long (field, index, (long) new_value));
}
int
fxputn_long (int field, int index, long new_value)
{
static char
_3845 [20];
ASSERT (index < _3717 (_3813 (field)));
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
sprintf (_3845, "%ld", new_value);
return (fxputn_text (field, index, _3845));
}
int
fxputn_double (int field, int index, double new_value)
{
static char
_3845 [40],
format [10];
ASSERT (index < _3717 (_3813 (field)));
sprintf (format, "%%.%df", _3746 (_3813 (field)));
sprintf (_3845, format, new_value);
return (fxputn_text (field, index, _3845));
}
int
fxputn_bool (int field, int index, Bool new_value)
{
ASSERT (index < _3717 (_3813 (field)));
return (fxputn_text (field, index, new_value? "1": "0"));
}
char *
fxgetn_text (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (NULL);
ASSERT (index < _3717 (_3813 (field)));
return (_3689 (field, index));
}
char
fxgetn_char (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
ASSERT (index < _3717 (_3813 (field)));
return (*_3689 (field, index));
}
long
fxgetn_date (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
ASSERT (index < _3717 (_3813 (field)));
ASSERT (_3715 (_3813 (field)) == BLOCK_DATE);
return (atol (_3689 (field, index)));
}
long
fxgetn_time (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
ASSERT (index < _3717 (_3813 (field)));
ASSERT (_3715 (_3813 (field)) == BLOCK_TIME);
return (atol (_3689 (field, index)));
}
int
fxgetn_int (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
ASSERT (index < _3717 (_3813 (field)));
return (atoi (_3689 (field, index)));
}
long
fxgetn_long (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
ASSERT (index < _3717 (_3813 (field)));
return (atol (_3689 (field, index)));
}
double
fxgetn_double (int field, int index)
{
if (field < 0 || field >= _3655-> defn-> field_count)
return (0);
ASSERT (index < _3717 (_3813 (field)));
return (atof (_3689 (field, index)));
}
Bool
fxgetn_bool (int field, int index)
{
ASSERT (index < _3717 (_3813 (field)));
return (fxgetn_long (field, index)? TRUE: FALSE);
}
byte
fxattr_get (
int _3707,
int index)
{
FORM_DEFN
*defn;
defn = _3655-> defn;
ASSERT (_3707 >= 0 && _3707 < defn-> field_count);
return (*_3688 (_3707, index));
}
void
fxattr_put (
int _3707,
int index,
byte attr)
{
FORM_DEFN
*defn;
defn = _3655-> defn;
ASSERT (_3707 >= 0 && _3707 < defn-> field_count);
*_3688 (_3707, index) = attr;
}
size_t
fxlist_size (int field, int index)
{
return (atoi (_3703 (field, index, 0, 'h')));
}
static char *
_3705 (int field, int index, int item, char _3704)
{
static char
key [11];
sprintf (key, "%02x.%02x.%02x.%c",
(byte) field, (byte) index, (byte) item, _3704);
return (key);
}
static char *
_3703 (int field, int index, int item, char _3704)
{
SYMBOL
*symbol;
if (_3655-> list_values)
{
symbol = sym_lookup_symbol (_3655-> list_values,
_3705 (field, index, item, _3704));
if (symbol)
return (symbol-> value);
}
return ("");
}
void
fxlist_reset (int field, int index)
{
SYMBOL
*symbol;
int
item;
if (_3655-> list_values == NULL)
_3655-> list_values = sym_create_table ();
item = fxlist_size (field, index);
while (item > 0)
{
symbol = sym_lookup_symbol (_3655-> list_values,
_3705 (field, index, item, 'k'));
if (symbol)
sym_delete_symbol (_3655-> list_values, symbol);
symbol = sym_lookup_symbol (_3655-> list_values,
_3705 (field, index, item, 'v'));
if (symbol)
sym_delete_symbol (_3655-> list_values, symbol);
item--;
}
sym_create_symbol (_3655-> list_values,
_3705 (field, index, 0, 'h'), "000");
}
int
fxlist_append (int field, int index, char *key, char *value)
{
SYMBOL
*symbol;
int
_3873;
ASSERT (_3655-> list_values);
symbol = sym_lookup_symbol (_3655-> list_values,
_3705 (field, index, 0, 'h'));
if (symbol == NULL)
return (0);
_3873 = fxlist_size (field, index);
if (_3873 == 999)
return (_3873);
_3873++;
sym_assume_symbol (_3655-> list_values,
_3705 (field, index, _3873, 'k'), key);
sym_assume_symbol (_3655-> list_values,
_3705 (field, index, _3873, 'v'), value);
sprintf (symbol-> value, "%d", _3873);
return (_3873);
}
char *
fxlist_key (int field, int index)
{
return (_3703 (field, index, fxgetn_int (field, index), 'k'));
}
char *
fxlist_value (int field, int index)
{
return (_3703 (field, index, fxgetn_int (field, index), 'v'));
}
void
fxlist_set (int field, int index, char *key)
{
int
item;
ASSERT (_3655-> list_values);
item = fxlist_size (field, index);
while (item > 0)
{
if (streq (_3703 (field, index, item, 'k'), key))
break;
item--;
}
fxputn_int (field, index, item);
}
int
form_exec (
FORM_ITEM *form,
blockfunc _3874,
...)
{
va_list
_3708;
byte
*_3664;
word
block_size;
int
_3707,
_3829,
count = 0;
ASSERT (form);
va_start (_3708, _3874);
_3707 = -1;
_3664 = form-> defn-> blocks;
for (_3829 = 0; _3829 < form-> defn-> block_count; _3829++)
{
block_size = _3714 (_3664);
ASSERT (block_size > 0);
if (_3811 (_3715 (_3664)))
_3707++;
if ((*_3874) (form, _3664, _3707, _3708))
count++;
else
break;
_3664 += block_size + 2;
}
va_end (_3708);
return (count);
}
void
action_enable (FORM_ITEM *form, int event)
{
form_exec (form, _3711, event, FACTION_ENABLED);
}
static Bool
_3711 (
FORM_ITEM *form,
byte *_3664,
int _3707,
va_list _3708)
{
int
event,
attr;
event = va_arg (_3708, int);
attr = va_arg (_3708, int);
_3655 = form;
if (_3715 (_3664) == BLOCK_ACTION)
{
if (event == -1
|| event == _3804 (_3664))
*_3815 (_3664) = attr;
}
return (TRUE);
}
void
action_disable (FORM_ITEM *form, int event)
{
form_exec (form, _3711, event, FACTION_DISABLED);
}
void
action_hide (FORM_ITEM *form, int event)
{
form_exec (form, _3711, event, FACTION_HIDDEN);
}
int
form_save (
const char *filename,
FORM_ITEM *form)
{
FILE
*stream;
stream = fopen (filename, FOPEN_WRITE_BINARY);
if (stream)
{
fwrite (form, sizeof (FORM_ITEM), 1, stream);
fwrite (form-> data, form-> data_size, 1, stream);
fclose (stream);
return (0);
}
else
return (-1);
}
FORM_ITEM *
form_load (
const char *filename,
FORM_DEFN *defn)
{
FILE
*stream;
FORM_ITEM
*form;
byte
*data;
stream = fopen (filename, FOPEN_READ_BINARY);
if (!stream)
return (NULL);
if ((form = _3662 (defn)) == NULL)
return (NULL);
data = form-> data;
fread (form, sizeof (FORM_ITEM), 1, stream);
form-> data = data;
form-> defn = defn;
fread (form-> data, form-> data_size, 1, stream);
mem_check (form-> data);
fclose (stream);
return (form);
}
void
form_dump (FORM_ITEM *form)
{
int
_3829 = 0;
ASSERT (form);
printf ("Dumping contents of form %s\n", form-> defn-> form_name);
printf ("Block: Size:  Type:      Details:\n");
form_exec (form, _3710, &_3829);
}
static Bool
_3710 (
FORM_ITEM *form,
byte *_3664,
int _3707,
va_list _3708)
{
byte
*_3840;
word
block_size;
int
*_3829;
_3829 = va_arg (_3708, int *);
block_size = _3714 (_3664);
printf ("%p %-6d %-6d ", _3664, *_3829, block_size);
(*_3829)++;
switch (_3715 (_3664))
{
case BLOCK_PLAIN:
printf ("plain      ");
_3664 += 2;
block_size--;
if (block_size > 50)
block_size = 50;
while (block_size-- > 0)
printf ("%c", *++_3664);
printf ("\n");
break;
case BLOCK_COMPRESSED:
printf ("compressed ");
_3840 = _3720 (_3664) + form-> defn-> blocks;
if (_3719 (_3664) == COMPR_WHOLEDICT)
block_size = _3714 (_3840) - 1;
else
if (_3719 (_3664) == COMPR_PARTDICT)
block_size = _3721 (_3664);
else
abort ();
_3840 += 2;
if (block_size > 50)
block_size = 50;
while (block_size-- > 0)
printf ("%c", *++_3840);
printf ("\n");
break;
case BLOCK_IF:
printf ("if         ");
printf ("field=%d scope=%d\n",
_3722 (_3664),
_3723 (_3664));
break;
case BLOCK_UNLESS:
printf ("unless     ");
printf ("field=%d scope=%d\n",
_3724 (_3664),
_3725 (_3664));
break;
case BLOCK_REPEAT:
printf ("repeat     ");
printf ("field=%d scope=%d occurs=%d\n",
_3726 (_3664),
_3727 (_3664),
_3728 (_3664));
break;
case BLOCK_TEXTUAL:
printf ("textual    ");
printf ("x%d attr=%d size=%d max=%d name=%s value=%s\n",
_3730 (_3664),
_3729 (_3664),
_3732 (_3664),
_3733 (_3664),
_3734 (_3664),
_3735 (_3664));
break;
case BLOCK_FILE:
printf ("file       ");
printf ("x%d attr=%d size=%d max=%d name=%s value=%s\n",
_3737 (_3664),
_3736 (_3664),
_3738 (_3664),
_3739 (_3664),
_3740 (_3664),
_3741 (_3664));
break;
case BLOCK_NUMERIC:
printf ("numeric    ");
printf ("x%d attr=%d size=%d max=%d sign=%d decs=%d ",
_3743 (_3664),
_3742 (_3664),
_3744 (_3664),
_3745 (_3664),
_3747 (_3664),
_3746 (_3664));
printf ("fill=%d blank=%d comma=%d name=%s value=%s\n",
_3749 (_3664),
_3750 (_3664),
_3751 (_3664),
_3752 (_3664),
_3753 (_3664));
break;
case BLOCK_DATE:
printf ("date       ");
printf ("x%d attr=%d size=%d show=%d format=%d year=%d ",
_3755 (_3664),
_3754 (_3664),
_3756 (_3664),
_3757 (_3664),
_3758 (_3664),
_3759 (_3664));
printf ("month=%d day=%d name=%s value=%s picture=%s\n",
_3760 (_3664),
_3761 (_3664),
_3762 (_3664),
_3763 (_3664),
_3764 (_3664));
break;
case BLOCK_TIME:
printf ("time       ");
printf ("x%d attr=%d size=%d name=%s value=%s picture=%s\n",
_3766 (_3664),
_3765 (_3664),
_3767 (_3664),
_3768 (_3664),
_3769 (_3664),
_3770 (_3664));
break;
case BLOCK_TEXTBOX:
printf ("textbox    ");
printf ("x%d attr=%d rows=%d cols=%d max=%d name=%s value=%s\n",
_3772 (_3664),
_3771 (_3664),
_3773 (_3664),
_3774 (_3664),
_3776 (_3664),
_3777 (_3664),
_3778 (_3664));
break;
case BLOCK_BOOLEAN:
printf ("boolean    ");
printf ("x%d attr=%d name=%s value=%s\n",
_3780 (_3664),
_3779 (_3664),
_3781 (_3664),
_3782 (_3664));
break;
case BLOCK_SELECT:
printf ("select     ");
printf ("x%d attr=%d size=%d opts=%d name=%s value=%s first=%s\n",
_3786 (_3664),
_3785 (_3664),
_3787 (_3664),
_3788 (_3664),
_3789 (_3664),
_3790 (_3664),
_3792 (_3664));
break;
case BLOCK_RADIO:
printf ("radio      ");
printf ("x%d attr=%d detail=%d column=%d name=%s value=%s\n",
_3794 (_3664),
_3793 (_3664),
_3795 (_3664),
_3796 (_3664),
_3797 (_3664),
_3798 (_3664));
break;
case BLOCK_RLABEL:
printf ("rlabel     ");
printf ("data=%d index=%d value=%s\n",
_3800 (_3664),
_3801 (_3664),
_3802 (_3664));
break;
case BLOCK_ACTION:
printf ("action     ");
printf ("type=%d event=%d show=%d height=%d width=%d label=%s\n",
_3803 (_3664),
_3804 (_3664),
_3806 (_3664),
_3807 (_3664),
_3808 (_3664),
_3810 (_3664));
break;
default:
printf ("ERROR!\n");
abort ();
}
return (TRUE);
}
int
form_ftype (
FORM_ITEM *form,
int _3707)
{
FORM_DEFN
*defn;
ASSERT (form);
defn = form-> defn;
if (_3707 < 0 || _3707 >= defn-> field_count)
return (0);
else
return (_3715 (defn-> blocks + defn-> fields [_3707].block));
}
