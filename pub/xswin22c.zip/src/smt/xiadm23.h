/*---------------------------------------------------------------------------
 *  xiadm23.h - HTML form definition
 *
 *  Generated 1998/01/31, 22:00:52 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM23__
#define __FORM_XIADM23__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM23_MESSAGE_TO_USER             0
#define XIADM23_L_STARTUP                   1
#define XIADM23_STARTUP                     2
#define XIADM23_L_REFRESH                   3
#define XIADM23_REFRESH                     4
#define XIADM23_L_RATE                      5
#define XIADM23_RATE                        6
#define XIADM23_L_CAPTURE                   7
#define XIADM23_CAPTURE                     8
#define XIADM23_L_FILENAME                  9
#define XIADM23_FILENAME                    10
#define XIADM23_L_APPEND                    11
#define XIADM23_APPEND                      12
#define XIADM23_L_NONAME19                  13

/*  This table contains each block in the form                               */

static byte xiadm23_blocks [] = {
    /*  <HTML><HEAD><TITLE>Console Properties</TITLE>                        */
    0, 46, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'C', 'o', 'n', 's', 'o',
    'l', 'e', 32, 'P', 'r', 'o', 'p', 'e', 'r', 't', 'i', 'e', 's', '<',
    '/', 'T', 'I', 'T', 'L', 'E', '>',
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 31, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 133, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  Console Properties                                                   */
    0, 19, 0, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'P', 'r', 'o', 'p',
    'e', 'r', 't', 'i', 'e', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 43, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE WIDTH=100%>                                                   */
    0, 6, 1, 1, 0, 140, 0, 18,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL f309 NAME=L_startup VALUE="Start-up page:"          */
    0, 27, 10, 6, 1, 0, 14, 0, 14, 'f', '3', '0', '9', 0, 'S', 't', 'a',
    'r', 't', 45, 'u', 'p', 32, 'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--FIELD RADIO f310 NAME=sta ... 0 DETAIL=0 VALUE=0 NULL="?"         */
    0, 25, 16, 0, 1, 0, 0, 'f', '3', '1', '0', 0, '0', 0, 'N', 'o', 32,
    's', 'e', 'l', 'e', 'c', 't', 'i', 'o', 'n', 0,
    /*  !--FIELD RADIO f310 OPTION="Main menu"                               */
    0, 14, 17, 2, 176, 1, 'M', 'a', 'i', 'n', 32, 'm', 'e', 'n', 'u', 0,
    /*  !--FIELD RADIO f310 OPTION="Basic config"                            */
    0, 17, 17, 2, 176, 2, 'B', 'a', 's', 'i', 'c', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 0,
    /*  !--FIELD RADIO f310 OPTION="VHost config"                            */
    0, 17, 17, 2, 176, 3, 'V', 'H', 'o', 's', 't', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 0,
    /*  !--FIELD RADIO f310 OPTION="Console page"                            */
    0, 17, 17, 2, 176, 4, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'p',
    'a', 'g', 'e', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'A',
    /*  !--FIELD TEXTUAL f311 NAME=L ...  VALUE="Automatic refresh?"         */
    0, 31, 10, 6, 1, 0, 18, 0, 18, 'f', '3', '1', '1', 0, 'A', 'u', 't',
    'o', 'm', 'a', 't', 'i', 'c', 32, 'r', 'e', 'f', 'r', 'e', 's', 'h',
    '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 134,
    /*  !--FIELD BOOLEAN f312 NAME=refresh TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '1', '2', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 20,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'A',
    /*  !--FIELD TEXTUAL f313 NAME=L_rate VALUE=" - refresh every:"          */
    0, 30, 10, 6, 1, 0, 17, 0, 17, 'f', '3', '1', '3', 0, 32, 45, 32,
    'r', 'e', 'f', 'r', 'e', 's', 'h', 32, 'e', 'v', 'e', 'r', 'y', ':',
    0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 134,
    /*  !--FIELD NUMERIC f314 NAME=r ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, 'f', '3', '1', '4',
    0, 0,
    /*  seconds                                                              */
    0, 8, 0, 's', 'e', 'c', 'o', 'n', 'd', 's',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 20,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'A',
    /*  !--FIELD TEXTUAL f315 NAME=L_capture VALUE="Capture console?"        */
    0, 29, 10, 6, 1, 0, 16, 0, 16, 'f', '3', '1', '5', 0, 'C', 'a', 'p',
    't', 'u', 'r', 'e', 32, 'c', 'o', 'n', 's', 'o', 'l', 'e', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 134,
    /*  !--FIELD BOOLEAN f316 NAME=capture TRUE=yes FALSE=no VALUE=0         */
    0, 17, 14, 0, 1, 'f', '3', '1', '6', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 20,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'A',
    /*  !--FIELD TEXTUAL f317 NAME=L ... VALUE=" - capture to file:"         */
    0, 32, 10, 6, 1, 0, 19, 0, 19, 'f', '3', '1', '7', 0, 32, 45, 32,
    'c', 'a', 'p', 't', 'u', 'r', 'e', 32, 't', 'o', 32, 'f', 'i', 'l',
    'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 134,
    /*  !--FIELD TEXTUAL f318 NAME=filename SIZE=15 MAX=40 VALUE=""          */
    0, 13, 10, 0, 1, 0, 15, 0, '(', 'f', '3', '1', '8', 0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 20,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'A',
    /*  !--FIELD TEXTUAL f319 NAME=L_append VALUE=" - append data?"          */
    0, 28, 10, 6, 1, 0, 15, 0, 15, 'f', '3', '1', '9', 0, 32, 45, 32,
    'a', 'p', 'p', 'e', 'n', 'd', 32, 'd', 'a', 't', 'a', '?', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 134,
    /*  !--FIELD BOOLEAN f320 NAME=append TRUE=yes FALSE=no VALUE=0          */
    0, 17, 14, 0, 1, 'f', '3', '2', '0', 0, '0', 0, 'y', 'e', 's', 0,
    'n', 'o', 0,
    /*  <TR><TD></TD><TD>                                                    */
    0, 18, 0, '<', 'T', 'R', '>', '<', 'T', 'D', '>', '<', '/', 'T',
    'D', '>', '<', 'T', 'D', '>',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 20,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'A',
    /*  !--FIELD TEXTUAL f321 NAME=L ... UE="Actions for this page:"         */
    0, 35, 10, 6, 1, 0, 22, 0, 22, 'f', '3', '2', '1', 0, 'A', 'c', 't',
    'i', 'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32,
    'p', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 134,
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 2, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 3, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 3, 20,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'X',
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <SCRIPT>                                                             */
    0, 9, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 194, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', '.',
    'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32, 'a',
    'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 'd', 'o', 'c', 'u',
    'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']',
    '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, '}', 10, 'f',
    'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o', 'c', 'u', 's', '(',
    ')', 32, '{', 10, 'i', 'f', 32, '(', '"', '#', '(', '_', 'f', 'o',
    'c', 'u', 's', ')', '"', 32, '!', '=', 32, '"', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '"', ')', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n',
    't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', '#', '(',
    '_', 'f', 'o', 'c', 'u', 's', ')', '.', 'f', 'o', 'c', 'u', 's',
    '(', ')', ';', 10, '}',
    /*  </SCRIPT>                                                            */
    0, 10, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 169, 0, 13,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 63, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'X',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm23_fields [] = {
    { 0, 107, 80 },                     /*  message_to_user                 */
    { 82, 617, 14 },                    /*  l_startup                       */
    { 98, 688, 3 },                     /*  startup                         */
    { 103, 807, 18 },                   /*  l_refresh                       */
    { 123, 846, 1 },                    /*  refresh                         */
    { 126, 877, 17 },                   /*  l_rate                          */
    { 145, 915, 5 },                    /*  rate                            */
    { 152, 958, 16 },                   /*  l_capture                       */
    { 170, 995, 1 },                    /*  capture                         */
    { 173, 1026, 19 },                  /*  l_filename                      */
    { 194, 1066, 40 },                  /*  filename                        */
    { 236, 1093, 15 },                  /*  l_append                        */
    { 253, 1129, 1 },                   /*  append                          */
    { 256, 1186, 22 },                  /*  l_noname19                      */
    { 280, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_startup_a          ;
    char   l_startup            [14 + 1];
    byte   startup_a            ;
    char   startup              [3 + 1];
    byte   l_refresh_a          ;
    char   l_refresh            [18 + 1];
    byte   refresh_a            ;
    char   refresh              [1 + 1];
    byte   l_rate_a             ;
    char   l_rate               [17 + 1];
    byte   rate_a               ;
    char   rate                 [5 + 1];
    byte   l_capture_a          ;
    char   l_capture            [16 + 1];
    byte   capture_a            ;
    char   capture              [1 + 1];
    byte   l_filename_a         ;
    char   l_filename           [19 + 1];
    byte   filename_a           ;
    char   filename             [40 + 1];
    byte   l_append_a           ;
    char   l_append             [15 + 1];
    byte   append_a             ;
    char   append               [1 + 1];
    byte   l_noname19_a         ;
    char   l_noname19           [22 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   defaults_a;
    byte   undo_a;
    } XIADM23_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm23 = {
    xiadm23_blocks,
    xiadm23_fields,
    71,                                 /*  Number of blocks in form        */
    14,                                 /*  Number of fields in form        */
    4,                                  /*  Number of actions in form       */
    280,                                /*  Size of fields                  */
    "xiadm23",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
