/*---------------------------------------------------------------------------
 *  xiadm05.h - HTML form definition
 *
 *  Generated 1998/01/31, 22:00:52 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM05__
#define __FORM_XIADM05__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define VHOST_LIST_MAX                      10
#define XIADM05_MESSAGE_TO_USER             0
#define XIADM05_L_VHOST_NAME                1
#define XIADM05_L_VHOST_FILE                2
#define XIADM05_KEY                         3
#define XIADM05_VHOST_NAME                  4
#define XIADM05_VHOST_FILE                  5
#define XIADM05_L_NONAME4                   6
#define XIADM05_VHOST_LIST                  7

/*  This table contains each block in the form                               */

static byte xiadm05_blocks [] = {
    /*  <HTML><HEAD><TITLE>#(config) - Virtual Hosts</TITLE>                 */
    0, 53, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', '#', '(', 'c', 'o', 'n',
    'f', 'i', 'g', ')', 32, 45, 32, 'V', 'i', 'r', 't', 'u', 'a', 'l',
    32, 'H', 'o', 's', 't', 's', '<', '/', 'T', 'I', 'T', 'L', 'E', '>',
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 31, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>',
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 3,
    /*  <P><FONT SIZE=5>                                                     */
    0, 17, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>',
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 24, 10, 9, 1, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g', 'e',
    '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <HR>                                                                 */
    0, 5, 0, '<', 'H', 'R', '>',
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 27, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>',
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 157, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>',
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 17, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>',
    /*  #(config) - Virtual Hosts                                            */
    0, 26, 0, '#', '(', 'c', 'o', 'n', 'f', 'i', 'g', ')', 32, 45, 32,
    'V', 'i', 'r', 't', 'u', 'a', 'l', 32, 'H', 'o', 's', 't', 's',
    /*  </TABLE>                                                             */
    0, 9, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>',
    /*  <TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=100%><TR>                   */
    0, 51, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'C', 'E', 'L', 'L', 'S',
    'P', 'A', 'C', 'I', 'N', 'G', '=', '0', 32, 'C', 'E', 'L', 'L', 'P',
    'A', 'D', 'D', 'I', 'N', 'G', '=', '0', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>',
    /*  <TD ALIGN=LEFT>                                                      */
    0, 16, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', '>',
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 35, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>',
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 43, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>',
    /*  !--ACTION ok  LABEL="Ok" EVENT=ok_event TYPE=BUTTON                  */
    0, 17, 20, 0, (byte) ((word) ok_event / 256), (byte) ((word)
    ok_event & 255), 0, 0, 0, 0, 0, 0, 0, 'o', 'k', 0, 'O', 'k', 0,
    /*  !--ACTION cancel  LABEL="Can ... NT=cancel_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) cancel_event / 256), (byte) ((word)
    cancel_event & 255), 0, 1, 0, 0, 0, 0, 0, 'c', 'a', 'n', 'c', 'e',
    'l', 0, 'C', 'a', 'n', 'c', 'e', 'l', 0,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 4, 1, 0, 1, 'O',
    /*  !--ACTION server  LABEL="Ser ... NT=server_event TYPE=BUTTON         */
    0, 25, 20, 0, (byte) ((word) server_event / 256), (byte) ((word)
    server_event & 255), 0, 2, 0, 0, 0, 0, 0, 's', 'e', 'r', 'v', 'e',
    'r', 0, 'S', 'e', 'r', 'v', 'e', 'r', 0,
    /*  !--ACTION aliases  LABEL="Al ... T=aliases_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) aliases_event / 256), (byte) ((word)
    aliases_event & 255), 0, 3, 0, 0, 0, 0, 0, 'a', 'l', 'i', 'a', 's',
    'e', 's', 0, 'A', 'l', 'i', 'a', 's', 'e', 's', 0,
    /*  <EM>Vhosts</EM>                                                      */
    0, 16, 0, '<', 'E', 'M', '>', 'V', 'h', 'o', 's', 't', 's', '<',
    '/', 'E', 'M', '>',
    /*  !--ACTION cgi  LABEL="CGI" EVENT=cgi_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) cgi_event / 256), (byte) ((word)
    cgi_event & 255), 0, 4, 0, 0, 0, 0, 0, 'c', 'g', 'i', 0, 'C', 'G',
    'I', 0,
    /*  !--ACTION security  LABEL="S ... =security_event TYPE=BUTTON         */
    0, 29, 20, 0, (byte) ((word) security_event / 256), (byte) ((word)
    security_event & 255), 0, 5, 0, 0, 0, 0, 0, 's', 'e', 'c', 'u', 'r',
    'i', 't', 'y', 0, 'S', 'e', 'c', 'u', 'r', 'i', 't', 'y', 0,
    /*  !--ACTION logging  LABEL="Lo ... T=logging_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) logging_event / 256), (byte) ((word)
    logging_event & 255), 0, 6, 0, 0, 0, 0, 0, 'l', 'o', 'g', 'g', 'i',
    'n', 'g', 0, 'L', 'o', 'g', 'g', 'i', 'n', 'g', 0,
    /*  !--ACTION ftp  LABEL="FTP" EVENT=ftp_event TYPE=BUTTON               */
    0, 19, 20, 0, (byte) ((word) ftp_event / 256), (byte) ((word)
    ftp_event & 255), 0, 7, 0, 0, 0, 0, 0, 'f', 't', 'p', 0, 'F', 'T',
    'P', 0,
    /*  !--ACTION mime  LABEL="MIME" EVENT=mimes_event TYPE=BUTTON           */
    0, 21, 20, 0, (byte) ((word) mimes_event / 256), (byte) ((word)
    mimes_event & 255), 0, 8, 0, 0, 0, 0, 0, 'm', 'i', 'm', 'e', 0, 'M',
    'I', 'M', 'E', 0,
    /*  </TABLE><HR>                                                         */
    0, 13, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', '<', 'H', 'R',
    '>',
    /*  <TABLE NOWRAP >                                                      */
    0, 16, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, '>',
    /*  <TR>                                                                 */
    0, 5, 0, '<', 'T', 'R', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP></TH>                                    */
    0, 34, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, 'E', 0, 28,
    /*  !--FIELD TEXTUAL f67 NAME=L_ ... ="IP address or host name:"         */
    0, 36, 10, 6, 1, 0, 24, 0, 24, 'f', '6', '7', 0, 'I', 'P', 32, 'a',
    'd', 'd', 'r', 'e', 's', 's', 32, 'o', 'r', 32, 'h', 'o', 's', 't',
    32, 'n', 'a', 'm', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 6, 0, '<', '/', 'T', 'H', '>',
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 6, 1, 1, 3, 'E', 0, 28,
    /*  !--FIELD TEXTUAL f68 NAME=L_vhost-file VALUE="Config file:"          */
    0, 24, 10, 6, 1, 0, 12, 0, 12, 'f', '6', '8', 0, 'C', 'o', 'n', 'f',
    'i', 'g', 32, 'f', 'i', 'l', 'e', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 3, 151,
    /*  !--REPEAT vhost_list  ROWS=10                                        */
    0, 7, 4, 0, 7, 0, 12, 0, 10,
    /*  </TR>                                                                */
    0, 6, 0, '<', '/', 'T', 'R', '>',
    /*  <TR>                                                                 */
    0, 4, 1, 0, 3, '>',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 29, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>',
    /*  !--FIELD TEXTUAL f69 NAME=key SIZE=50 MAX=? VALUE=""                 */
    0, 12, 10, 4, 10, 0, '2', 0, '2', 'f', '6', '9', 0, 0,
    /*  </TD>                                                                */
    0, 6, 0, '<', '/', 'T', 'D', '>',
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 27, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'L', 'E',
    'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O', 'P', '>',
    /*  !--FIELD TEXTUAL f70 NAME=vhost-name SIZE=40 MAX=50 VALUE=""         */
    0, 12, 10, 0, 10, 0, '(', 0, '2', 'f', '7', '0', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 11,
    /*  <TD ALIGN=LEFT VALIGN=TOP>                                           */
    0, 4, 1, 0, 4, 19,
    /*  !--FIELD TEXTUAL f71 NAME=vhost-file SIZE=40 MAX=? VALUE=""          */
    0, 12, 10, 0, 10, 0, '(', 0, '(', 'f', '7', '1', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 4, 11,
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 208,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '~',
    /*  <P>                                                                  */
    0, 4, 0, '<', 'P', '>',
    /*  <TABLE WIDTH=100%>                                                   */
    0, 6, 1, 1, 0, 147, 0, 18,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 38, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>',
    /*  !--FIELD TEXTUAL f72 NAME=L_ ... UE="Actions for this page:"         */
    0, 34, 10, 6, 1, 0, 22, 0, 22, 'f', '7', '2', 0, 'A', 'c', 't', 'i',
    'o', 'n', 's', 32, 'f', 'o', 'r', 32, 't', 'h', 'i', 's', 32, 'p',
    'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 40, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>',
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 9, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION undo  LABEL="Undo" EVENT=undo_event TYPE=BUTTON            */
    0, 21, 20, 0, (byte) ((word) undo_event / 256), (byte) ((word)
    undo_event & 255), 0, 10, 0, 0, 0, 0, 0, 'u', 'n', 'd', 'o', 0, 'U',
    'n', 'd', 'o', 0,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 11, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 12, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't',
    0, 'F', 'i', 'r', 's', 't', 0,
    /*  </TD></TR>                                                           */
    0, 11, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '~',
    /*  !--FIELD NUMERIC vhost_list SIZE=4 VALUE=10                          */
    0, 27, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'v', 'h', 'o', 's',
    't', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 8, 0, '<', '/', 'F', 'O', 'R', 'M', '>',
    /*  <SCRIPT>                                                             */
    0, 9, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 194, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', '.',
    'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32, 'a',
    'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 'd', 'o', 'c', 'u',
    'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']',
    '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, '}', 10, 'f',
    'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o', 'c', 'u', 's', '(',
    ')', 32, '{', 10, 'i', 'f', 32, '(', '"', '#', '(', '_', 'f', 'o',
    'c', 'u', 's', ')', '"', 32, '!', '=', 32, '"', 'j', 's', 'a', 'c',
    't', 'i', 'o', 'n', '"', ')', 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n',
    't', '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', '#', '(',
    '_', 'f', 'o', 'c', 'u', 's', ')', '.', 'f', 'o', 'c', 'u', 's',
    '(', ')', ';', 10, '}',
    /*  </SCRIPT>                                                            */
    0, 10, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>',
    /*  <FONT SIZE=2>                                                        */
    0, 6, 1, 1, 0, 176, 0, 13,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 63, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0',
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, '~',
    /*  </BODY></HTML>                                                       */
    0, 15, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>',
    0, 0, 0
    };

static FIELD_DEFN xiadm05_fields [] = {
    { 0, 114, 80 },                     /*  message_to_user                 */
    { 82, 881, 24 },                    /*  l_vhost_name                    */
    { 108, 935, 12 },                   /*  l_vhost_file                    */
    { 122, 1021, 50 },                  /*  key                             */
    { 642, 1072, 50 },                  /*  vhost_name                      */
    { 1162, 1098, 40 },                 /*  vhost_file                      */
    { 1582, 1184, 22 },                 /*  l_noname4                       */
    { 1606, 1380, 4 },                  /*  vhost_list                      */
    { 1612, 0, 0 },                     /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_vhost_name_a       ;
    char   l_vhost_name         [24 + 1];
    byte   l_vhost_file_a       ;
    char   l_vhost_file         [12 + 1];
    byte   key_a                [10] ;
    char   key                  [10] [50 + 1];
    byte   vhost_name_a         [10] ;
    char   vhost_name           [10] [50 + 1];
    byte   vhost_file_a         [10] ;
    char   vhost_file           [10] [40 + 1];
    byte   l_noname4_a          ;
    char   l_noname4            [22 + 1];
    byte   vhost_list_a         ;
    char   vhost_list           [4 + 1];
    byte   ok_a;
    byte   cancel_a;
    byte   server_a;
    byte   aliases_a;
    byte   cgi_a;
    byte   security_a;
    byte   logging_a;
    byte   ftp_a;
    byte   mime_a;
    byte   clear_a;
    byte   undo_a;
    byte   more_a;
    byte   first_a;
    } XIADM05_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm05 = {
    xiadm05_blocks,
    xiadm05_fields,
    70,                                 /*  Number of blocks in form        */
    8,                                  /*  Number of fields in form        */
    13,                                 /*  Number of actions in form       */
    1612,                               /*  Size of fields                  */
    "xiadm05",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
