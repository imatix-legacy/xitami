Other VB Addons that work with Xitami...

------------------------------------------------------------------------
LA CGI and Cookie VB Module v1.0

This module adds the ability to access CGI and Cookies with Visual Basic.
It is free to use non-commercially and commercially without any strings
attached. Features include:

� Reads both the GET and POST CGI methods.
� Automatically parses form and cookie input.
� Supports all facets of the Netscape HTTP Cookie specification.
� Works with any Web Server that supports CGI.
� Faster than using scripting languages like Perl.
� Can send redirect, no content, and binary data.
� and it's free!

You can view the documentation and download a copy at:
http://www.northcoast.com/~aran/resources/
